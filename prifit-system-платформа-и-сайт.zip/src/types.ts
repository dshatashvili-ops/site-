export type Marketplace = 'all' | 'wildberries' | 'ozon';

export type ProductLevelId = 'calc' | 'analysis' | 'promo' | 'tb';

export interface ProductLevel {
  id: ProductLevelId;
  number: string;
  levelCode?: string;
  title: string;
  subtitle: string;
  tagline: string;
  description: string;
  badge?: string;
  price: {
    wb: number;
    ozon: number;
    bundle?: number;
  };
  features: string[];
  whenToUse: string;
  whoIsItFor: string;
  color: string;
  accentBorder: string;
  glow: string;
}

export interface ComparisonRow {
  feature: string;
  calc: boolean;
  analysis: boolean;
  promo: boolean;
  tb: boolean;
  tooltip?: string;
}

export type FaqCategory = 
  | 'general' 
  | 'levels' 
  | 'excel' 
  | 'setup' 
  | 'tb' 
  | 'updates' 
  | 'license' 
  | 'calculator' 
  | 'wb' 
  | 'ozon' 
  | 'technical';

export interface FAQItem {
  id: string;
  category: FaqCategory;
  question: string;
  answer: string;
}

export interface QuizQuestion {
  id: number;
  title: string;
  options: {
    label: string;
    description: string;
    recommendedProduct: ProductLevelId;
  }[];
}

export interface Article {
  id: string;
  title: string;
  category: string;
  readTime: string;
  date: string;
  summary: string;
  marketplace?: Marketplace;
}

export type VideoTutorial = {
  id: string;
  title: string;
  duration: string;
  views: string;
  youtubeUrl: string;
};

// --- TB Calculator Types ---
export type ExpenseCategory =
  | 'rent_utilities'
  | 'payroll'
  | 'marketing'
  | 'transport'
  | 'subscriptions'
  | 'other';

export interface CategoryInfo {
  id: ExpenseCategory;
  label: string;
  color: string;
}

export interface ExpenseItem {
  id: string;
  number: number;
  name: string;
  amount: number;
  comment: string;
  category: ExpenseCategory;
}

export interface FinancialState {
  expenses: ExpenseItem[];
  desiredProfit: number;
  marginPercent: number;
  whatIfMarginPercent: number;
}

export type TbAccessMode = 'demo' | 'promo_24h' | 'paid_subscription';

