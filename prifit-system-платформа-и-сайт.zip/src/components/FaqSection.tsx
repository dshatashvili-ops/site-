import { useState } from 'react';
import { ChevronDown, Search, HelpCircle } from 'lucide-react';
import { FAQ_LIST, FAQ_CATEGORIES } from '../data/content';
import { AnimatedSection } from './AnimatedSection';

export function FaqSection() {
  const [openId, setOpenId] = useState<string | null>('faq-g1');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredFaqs = FAQ_LIST.filter((item) => {
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch =
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <section id="faq" className="py-24 bg-slate-950 relative border-t border-slate-900 transition-colors">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider font-semibold shadow-inner">
            <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
            <span>База знаний & FAQ</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-brand font-extrabold text-white tracking-tight mb-4">
            Часто задаваемые вопросы
          </h2>
          <p className="text-base sm:text-lg text-slate-300 font-sans">
            Ответы на ключевые вопросы по работе с PROFIT SYSTEM, выбору модуля, лицензированию и макросам Excel.
          </p>
        </AnimatedSection>

        {/* Search & Category Filter Controls */}
        <div className="mb-10 space-y-5">
          <div className="relative max-w-xl mx-auto">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Поиск по вопросам, понятиям и ответам..."
              className="w-full pl-12 pr-4 py-3.5 bg-slate-900 border border-slate-800 rounded-2xl text-white text-sm placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors shadow-lg"
            />
          </div>

          {/* 8 Category Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 text-xs font-mono">
            {FAQ_CATEGORIES.map((cat) => {
              const isActive = selectedCategory === cat.id;
              const count = cat.id === 'all' 
                ? FAQ_LIST.length 
                : FAQ_LIST.filter(f => f.category === cat.id).length;

              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3.5 py-2 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-blue-600 text-white border-blue-500 shadow-md font-semibold'
                      : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
                  }`}
                >
                  <span>{cat.name}</span>
                  <span className={`px-1.5 py-0.5 text-[10px] rounded-full ${isActive ? 'bg-blue-800 text-blue-100' : 'bg-slate-800 text-slate-400'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Accordion FAQ List */}
        <div className="space-y-3">
          {filteredFaqs.map((faq) => {
            const isOpen = openId === faq.id;
            const categoryObj = FAQ_CATEGORIES.find(c => c.id === faq.category);

            return (
              <div
                key={faq.id}
                className="rounded-2xl bg-slate-900/70 border border-slate-800/80 overflow-hidden transition-all duration-200 hover:border-slate-700"
              >
                <button
                  onClick={() => setOpenId(isOpen ? null : faq.id)}
                  className="w-full text-left p-5 sm:p-6 flex items-start justify-between gap-4 font-brand font-bold text-white hover:text-blue-300 transition-colors cursor-pointer"
                >
                  <div className="space-y-1">
                    {categoryObj && categoryObj.id !== 'all' && (
                      <span className="inline-block text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 uppercase">
                        {categoryObj.name}
                      </span>
                    )}
                    <div className="text-base sm:text-lg leading-snug">{faq.question}</div>
                  </div>
                  <div className={`w-8 h-8 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center shrink-0 transition-transform ${isOpen ? 'rotate-180 text-blue-400 border-blue-500/50 bg-blue-500/10' : 'text-slate-400'}`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-6 sm:px-6 sm:pb-6 text-sm text-slate-300 leading-relaxed border-t border-slate-800/50 pt-4 font-sans whitespace-pre-line">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}

          {filteredFaqs.length === 0 && (
            <div className="p-12 text-center text-slate-500 font-mono bg-slate-900/50 rounded-2xl border border-slate-800">
              По вашему запросу вопросов не найдено. Попробуйте изменить поисковый запрос или выбрать категорию «Все вопросы».
            </div>
          )}
        </div>

      </div>
    </section>
  );
}
