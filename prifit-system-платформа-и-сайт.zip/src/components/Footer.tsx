import { Activity, Download, ArrowRight, Send, Youtube, ShieldAlert } from 'lucide-react';
import { SITE_BRAND } from '../data/content';
import { Marketplace } from '../types';
import { Logo } from './Logo';

interface FooterProps {
  onSelectMarketplace: (m: Marketplace) => void;
  onOpenDemo: () => void;
  onOpenBuy: () => void;
  onNavigateToSection: (sectionId: string) => void;
}

export function Footer({ onSelectMarketplace, onOpenDemo, onOpenBuy, onNavigateToSection }: FooterProps) {
  return (
    <footer className="bg-slate-100 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-900 relative z-10 font-sans transition-colors">
      
      {/* FINAL CALL TO ACTION BLOCK */}
      <div className="py-20 border-b border-slate-200 dark:border-slate-900 bg-gradient-to-b from-slate-50 via-blue-50/50 to-slate-100 dark:from-slate-950 dark:via-blue-950/20 dark:to-slate-950">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center">
          
          <div className="flex justify-center mb-6">
            <Logo variant="icon" className="w-20 h-20 drop-shadow-xl" />
          </div>

          <h2 className="text-4xl sm:text-6xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
            Не угадывайте. <br />
            <span className="bg-gradient-to-r from-blue-600 to-emerald-600 dark:from-blue-400 dark:to-emerald-400 bg-clip-text text-transparent">
              Рассчитывайте.
            </span>
          </h2>

          <p className="text-lg sm:text-xl text-slate-700 dark:text-slate-300 max-w-2xl mx-auto mb-8 font-medium">
            {SITE_BRAND.subline}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onOpenBuy}
              className="px-8 py-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-base shadow-xl shadow-blue-600/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>Выбрать продукт</span>
              <ArrowRight className="w-5 h-5" />
            </button>

            <button
              onClick={onOpenDemo}
              className="px-7 py-4 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 font-semibold text-base border border-slate-300 dark:border-slate-800 transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Download className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <span>Попробовать бесплатно</span>
            </button>
          </div>

        </div>
      </div>

      {/* FOOTER LINKS NAV */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10">
          
          {/* Brand Info */}
          <div className="md:col-span-2">
            <div className="flex items-center mb-4">
              <Logo variant="full" className="h-9 w-auto" />
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-6 max-w-sm">
              Платформа расчёта unit-экономики и точной Точки Безубыточности бизнеса для продавцов Wildberries и Ozon.
            </p>

            <div className="flex items-center gap-3">
              <a
                href="https://t.me"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-800 text-sky-600 dark:text-sky-400 flex items-center justify-center transition-colors shadow-xs"
              >
                <Send className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-xl bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-800 text-red-600 dark:text-red-500 flex items-center justify-center transition-colors shadow-xs"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 1: Products */}
          <div>
            <h4 className="text-xs font-mono uppercase text-slate-900 dark:text-slate-300 tracking-wider mb-4 font-bold">
              Продукты
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
              <li>
                <button
                  onClick={() => { onSelectMarketplace('wildberries'); onNavigateToSection('marketplaces'); }}
                  className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                >
                  Wildberries (WB)
                </button>
              </li>
              <li>
                <button
                  onClick={() => { onSelectMarketplace('ozon'); onNavigateToSection('marketplaces'); }}
                  className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                >
                  Ozon
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateToSection('comparison')} className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                  Сравнение версий
                </button>
              </li>
              <li>
                <button onClick={onOpenDemo} className="hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors cursor-pointer">
                  Скачать Демо
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Knowledge Base */}
          <div>
            <h4 className="text-xs font-mono uppercase text-slate-900 dark:text-slate-300 tracking-wider mb-4 font-bold">
              База знаний
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
              <li>
                <button onClick={() => onNavigateToSection('media')} className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                  Блог и гайды
                </button>
              </li>
              <li>
                <a href="https://youtube.com" target="_blank" rel="noreferrer" className="hover:text-slate-900 dark:hover:text-white transition-colors">
                  Видео на YouTube
                </a>
              </li>
              <li>
                <a href="https://t.me" target="_blank" rel="noreferrer" className="hover:text-slate-900 dark:hover:text-white transition-colors">
                  Telegram-канал
                </a>
              </li>
              <li>
                <button onClick={() => onNavigateToSection('faq')} className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer">
                  Вопросы и ответы (FAQ)
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Legal & Support */}
          <div>
            <h4 className="text-xs font-mono uppercase text-slate-900 dark:text-slate-300 tracking-wider mb-4 font-bold">
              Поддержка & Инфо
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
              <li><span className="hover:text-slate-900 dark:hover:text-white cursor-pointer">Лицензия и Активация</span></li>
              <li><span className="hover:text-slate-900 dark:hover:text-white cursor-pointer">Политика конфиденциальности</span></li>
              <li><span className="hover:text-slate-900 dark:hover:text-white cursor-pointer">Публичная оферта</span></li>
              <li><span className="hover:text-slate-900 dark:hover:text-white cursor-pointer">Контакты техподдержки</span></li>
            </ul>
          </div>

        </div>

        {/* Bottom copyright line */}
        <div className="pt-12 mt-12 border-t border-slate-200 dark:border-slate-900/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 font-mono gap-4">
          <div>
            &copy; {new Date().getFullYear()} {SITE_BRAND.name} &bull; {SITE_BRAND.domain}
          </div>
          <div>
            Все права защищены.
          </div>
        </div>
      </div>

    </footer>
  );
}
