import React, { useState, FormEvent, useEffect } from 'react';
import { X, Download, FileSpreadsheet, CheckCircle2, Mail } from 'lucide-react';

interface DemoDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DemoDownloadModal({ isOpen, onClose }: DemoDownloadModalProps) {
  const [email, setEmail] = useState('');
  const [marketplace, setMarketplace] = useState<'wb' | 'ozon' | 'both'>('both');
  const [downloaded, setDownloaded] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleDownload = (e: FormEvent) => {
    e.preventDefault();
    setDownloaded(true);
    // Simulate instant download trigger
    setTimeout(() => {
      const element = document.createElement('a');
      const file = new Blob([`PROFIT SYSTEM DEMO FILE\nMarketplace: ${marketplace}\nEmail: ${email || 'guest'}`], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = `PROFIT_SYSTEM_DEMO_${marketplace.toUpperCase()}.xlsx`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }, 400);
  };

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 md:p-8 bg-slate-950/85 backdrop-blur-md overflow-y-auto overscroll-contain animate-in fade-in duration-150"
    >
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl shadow-2xl my-auto flex flex-col max-h-[calc(100vh-1.5rem)] sm:max-h-[calc(100vh-3rem)] overflow-hidden">
        
        {/* Sticky/Fixed Modal Header with Close Button */}
        <div className="p-4 sm:p-6 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 flex items-center justify-between gap-4 z-20 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[11px] font-mono font-bold text-emerald-400 uppercase tracking-wider">
                БЕСПЛАТНЫЙ ДЕМО-ФАЙЛ
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white leading-tight">
                PROFIT SYSTEM .XLSX
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 cursor-pointer transition-colors shrink-0"
            title="Закрыть (Esc)"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-5 sm:p-8 flex-1">
          <p className="text-xs sm:text-sm text-slate-400 mb-6">
            Таблица в формате Excel с 3 предзагруженными товарами для тестирования сквозной логики расчёта.
          </p>

          {downloaded ? (
            <div className="p-6 rounded-2xl bg-emerald-950/60 border border-emerald-800 text-center">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-3" />
              <h4 className="font-bold text-emerald-200 text-base mb-1">Скачивание началось!</h4>
              <p className="text-xs text-emerald-400/90 mb-4">
                Файл `PROFIT_SYSTEM_DEMO_{marketplace.toUpperCase()}.xlsx` сохранён на вашем устройстве.
              </p>
              <button
                onClick={onClose}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer"
              >
                Отлично, закрыть
              </button>
            </div>
          ) : (
            <form onSubmit={handleDownload} className="space-y-5">
              <div>
                <label className="text-xs font-mono uppercase text-slate-400 block mb-2">
                  Выберите маркетплейс:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setMarketplace('wb')}
                    className={`p-3 rounded-xl border text-xs font-semibold font-mono transition-all cursor-pointer ${
                      marketplace === 'wb'
                        ? 'bg-purple-950/60 border-purple-500 text-purple-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    Wildberries
                  </button>
                  <button
                    type="button"
                    onClick={() => setMarketplace('ozon')}
                    className={`p-3 rounded-xl border text-xs font-semibold font-mono transition-all cursor-pointer ${
                      marketplace === 'ozon'
                        ? 'bg-blue-950/60 border-blue-500 text-blue-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    Ozon
                  </button>
                  <button
                    type="button"
                    onClick={() => setMarketplace('both')}
                    className={`p-3 rounded-xl border text-xs font-semibold font-mono transition-all cursor-pointer ${
                      marketplace === 'both'
                        ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    Оба (WB+Ozon)
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-mono uppercase text-slate-400 block mb-2">
                  Ваш Email (необязательно, для копии):
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seller@example.com"
                    className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer mt-6"
              >
                <Download className="w-4 h-4" />
                <span>Скачать демо-файл прямо сейчас</span>
              </button>

              <p className="text-[10px] text-slate-500 text-center font-mono">
                Без скрытых платежей &bull; Мгновенная загрузка .XLSX
              </p>
            </form>
          )}
        </div>

      </div>
    </div>
  );
}
