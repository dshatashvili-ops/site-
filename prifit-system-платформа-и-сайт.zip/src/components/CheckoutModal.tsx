import React, { useState, FormEvent, useEffect } from 'react';
import { X, CreditCard, ArrowRight, CheckCircle2 } from 'lucide-react';
import { PRODUCT_LEVELS } from '../data/content';
import { ProductLevelId } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  initialProductId?: string;
  onClose: () => void;
}

export function CheckoutModal({ isOpen, initialProductId = 'calc', onClose }: CheckoutModalProps) {
  const [selectedProductId, setSelectedProductId] = useState<ProductLevelId>(
    (initialProductId as ProductLevelId) || 'calc'
  );
  const [selectedMarketplace, setSelectedMarketplace] = useState<'wb' | 'ozon' | 'bundle'>('bundle');
  const [email, setEmail] = useState('');
  const [isPaid, setIsPaid] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const currentProduct = PRODUCT_LEVELS.find((p) => p.id === selectedProductId) || PRODUCT_LEVELS[0];

  const getPrice = () => {
    if (selectedMarketplace === 'wb') return currentProduct.price.wb;
    if (selectedMarketplace === 'ozon') return currentProduct.price.ozon;
    return currentProduct.price.bundle || currentProduct.price.wb * 1.5;
  };

  const handlePay = (e: FormEvent) => {
    e.preventDefault();
    setIsPaid(true);
  };

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 md:p-8 bg-slate-950/85 backdrop-blur-md overflow-y-auto overscroll-contain animate-in fade-in duration-150"
    >
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl shadow-2xl my-auto flex flex-col max-h-[calc(100vh-1.5rem)] sm:max-h-[calc(100vh-3rem)] overflow-hidden">
        
        {/* Sticky/Fixed Modal Header with Close Button */}
        <div className="p-4 sm:p-6 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 flex items-center justify-between gap-4 z-20 shrink-0">
          <div>
            <div className="flex items-center gap-2 text-blue-400 font-mono text-[11px] sm:text-xs uppercase font-semibold">
              <CreditCard className="w-4 h-4" />
              <span>Оформление бессрочной лицензии</span>
            </div>
            <h3 className="text-lg sm:text-2xl font-bold text-white mt-0.5">
              Приобрести PROFIT SYSTEM
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 cursor-pointer transition-colors shrink-0"
            title="Закрыть (Esc)"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="overflow-y-auto p-5 sm:p-8 flex-1">
          {isPaid ? (
            <div className="p-6 sm:p-8 rounded-2xl bg-emerald-950/60 border border-emerald-800 text-center">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
              <h4 className="text-xl font-bold text-white mb-2">Лицензия успешно сформирована!</h4>
              <p className="text-xs sm:text-sm text-slate-300 mb-6 max-w-md mx-auto">
                Ссылка на скачивание модуля <strong className="text-emerald-300">{currentProduct.title}</strong> и ваш индивидуальный ключ активированы.
              </p>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-left mb-6 font-mono text-xs text-slate-300">
                <p className="text-slate-500 mb-1">Ключ лицензии:</p>
                <p className="text-emerald-400 font-bold select-all">PS-2026-PRO-9842-X190</p>
              </div>
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-8 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer"
              >
                Закрыть окно
              </button>
            </div>
          ) : (
            <form onSubmit={handlePay} className="space-y-5 sm:space-y-6">
              {/* Step 1: Select Level */}
              <div>
                <label className="text-xs font-mono uppercase text-slate-400 block mb-2.5">
                  1. Выберите уровень продукта:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {PRODUCT_LEVELS.map((lvl) => (
                    <button
                      key={lvl.id}
                      type="button"
                      onClick={() => setSelectedProductId(lvl.id)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        selectedProductId === lvl.id
                          ? 'bg-blue-600/20 border-blue-500 text-white shadow-lg shadow-blue-500/10'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span className="text-[10px] font-mono text-blue-400 block">{lvl.number}</span>
                      <span className="font-bold text-xs block line-clamp-1">{lvl.title}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Select Marketplace Platform */}
              <div>
                <label className="text-xs font-mono uppercase text-slate-400 block mb-2.5">
                  2. Выберите маркетплейс:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedMarketplace('wb')}
                    className={`p-3 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedMarketplace === 'wb'
                        ? 'bg-purple-950/60 border-purple-500 text-purple-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="text-xs font-bold block mb-0.5">🟣 Wildberries</span>
                    <span className="text-[10px] font-mono text-slate-400">Только WB</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedMarketplace('ozon')}
                    className={`p-3 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedMarketplace === 'ozon'
                        ? 'bg-blue-950/60 border-blue-500 text-blue-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="text-xs font-bold block mb-0.5">🔵 Ozon</span>
                    <span className="text-[10px] font-mono text-slate-400">Только Ozon</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedMarketplace('bundle')}
                    className={`p-3 sm:p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedMarketplace === 'bundle'
                        ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200 ring-1 ring-emerald-500'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="text-xs font-bold block mb-0.5">🔥 Комплект 2 в 1</span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold">WB + Ozon</span>
                  </button>
                </div>
              </div>

              {/* Step 3: Enter email */}
              <div>
                <label className="text-xs font-mono uppercase text-slate-400 block mb-2">
                  3. E-mail для получения лицензии и файла:
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seller@company.ru"
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Total Price Summary */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400 font-mono block">Итого к оплате:</span>
                  <span className="text-2xl sm:text-3xl font-black text-white">
                    {getPrice().toLocaleString('ru-RU')} ₽
                  </span>
                </div>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-3 py-1 rounded-full">
                  Бессрочный доступ
                </span>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 sm:py-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-blue-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Оплатить и получить PROFIT SYSTEM</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <p className="text-[10px] text-slate-500 text-center font-mono">
                Безопасная оплата картами МИР, Visa, Mastercard, СБП и ЮMoney
              </p>
            </form>
          )}
        </div>

      </div>
    </div>
  );
}
