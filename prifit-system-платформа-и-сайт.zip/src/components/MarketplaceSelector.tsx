import { ArrowRight, Check } from 'lucide-react';
import { Marketplace } from '../types';
import { AnimatedSection, StaggerContainer, StaggerItem } from './AnimatedSection';

interface MarketplaceSelectorProps {
  currentMarketplace: Marketplace;
  onSelectMarketplace: (m: Marketplace) => void;
  onNavigateToProducts: () => void;
}

export function MarketplaceSelector({
  currentMarketplace,
  onSelectMarketplace,
}: MarketplaceSelectorProps) {
  return (
    <section id="marketplaces" className="py-20 relative bg-slate-100/70 dark:bg-slate-950/80 border-t border-slate-200 dark:border-slate-900 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 text-slate-600 dark:text-slate-400 text-xs font-mono mb-4 uppercase tracking-wider shadow-xs">
            <span>Единый бренд • Две площадки</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-4">
            Выберите ваш маркетплейс
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-400">
            Для какой торговой площадки вам нужен точный расчёт unit-экономики и управление финансами?
          </p>
        </AnimatedSection>

        {/* 2 Marketplace Cards */}
        <StaggerContainer staggerDelay={0.15} className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          
          {/* WILDBERRIES CARD */}
          <StaggerItem>
            <div
              onClick={() => onSelectMarketplace('wildberries')}
              className={`group relative rounded-3xl p-8 transition-all cursor-pointer border ${
                currentMarketplace === 'wildberries'
                  ? 'bg-purple-50 dark:bg-gradient-to-b dark:from-purple-950/60 dark:to-slate-950 border-purple-500/80 shadow-2xl shadow-purple-900/20 ring-2 ring-purple-500/50'
                  : 'bg-white dark:bg-slate-900/50 hover:bg-purple-50/50 dark:hover:bg-slate-900/80 border-slate-200 dark:border-slate-800 hover:border-purple-400 shadow-sm'
              }`}
            >
              {/* Top Badge & Header */}
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-800 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-purple-600/30">
                    WB
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white group-hover:text-purple-700 dark:group-hover:text-purple-300 transition-colors">
                      Wildberries
                    </h3>
                    <p className="text-sm text-purple-600 dark:text-purple-400 font-mono">Unit-экономика Wildberries</p>
                  </div>
                </div>
                
                <span className="text-xs font-mono font-semibold px-3 py-1 rounded-full bg-purple-100 dark:bg-purple-500/10 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-500/20">
                  PROFIT WB
                </span>
              </div>

              <p className="text-slate-600 dark:text-slate-300 text-sm mb-6 leading-relaxed">
                Автоматизированный расчёт комиссий, логистики кС, складов хранения, удержаний за рекламу, СПП и акционных цен Wildberries.
              </p>

              {/* Feature List */}
              <ul className="space-y-3 mb-8 text-sm text-slate-700 dark:text-slate-300">
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0 font-bold">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Расчёт цены с учетом СПП и скидок WB</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0 font-bold">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Анализ действующих цен и удержаний</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0 font-bold">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Проверка участия в распродажах WB</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0 font-bold">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Точка безубыточности бизнеса (ТБ WB)</span>
                </li>
              </ul>

              {/* Bottom Button */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-purple-700 dark:text-purple-400 font-semibold group-hover:text-purple-800 dark:group-hover:text-purple-300">
                <span className="text-sm">Смотреть решения для Wildberries</span>
                <div className="w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-500/10 group-hover:bg-purple-200 dark:group-hover:bg-purple-500/20 flex items-center justify-center group-hover:translate-x-1 transition-all">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          </StaggerItem>

          {/* OZON CARD */}
          <StaggerItem>
            <div
              onClick={() => onSelectMarketplace('ozon')}
              className={`group relative rounded-3xl p-8 transition-all cursor-pointer border ${
                currentMarketplace === 'ozon'
                  ? 'bg-blue-50 dark:bg-gradient-to-b dark:from-blue-950/60 dark:to-slate-950 border-blue-500/80 shadow-2xl shadow-blue-900/20 ring-2 ring-blue-500/50'
                  : 'bg-white dark:bg-slate-900/50 hover:bg-blue-50/50 dark:hover:bg-slate-900/80 border-slate-200 dark:border-slate-800 hover:border-blue-400 shadow-sm'
              }`}
            >
              {/* Top Badge & Header */}
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-600 to-sky-800 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-600/30">
                    OZ
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-300 transition-colors">
                      Ozon
                    </h3>
                    <p className="text-sm text-blue-600 dark:text-blue-400 font-mono">Unit-экономика Ozon</p>
                  </div>
                </div>

                <span className="text-xs font-mono font-semibold px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-500/20">
                  PROFIT OZON
                </span>
              </div>

              <p className="text-slate-600 dark:text-slate-300 text-sm mb-6 leading-relaxed">
                Полный расчёт специфических расходов Ozon: комиссия категории, последняя миля, магистраль, эквайринг, авто-акции и финмодель.
              </p>

              {/* Feature List */}
              <ul className="space-y-3 mb-8 text-sm text-slate-700 dark:text-slate-300">
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 font-bold">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Расчёт цены с учетом эквайринга и комиссий Ozon</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-purple-400 flex items-center justify-center shrink-0 font-bold">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Анализ последней мили и магистрали Ozon</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-purple-400 flex items-center justify-center shrink-0 font-bold">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Проверка авто-акций и снижения цены</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-purple-400 flex items-center justify-center shrink-0 font-bold">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <span>Точка безубыточности бизнеса (ТБ Ozon)</span>
                </li>
              </ul>

              {/* Bottom Button */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-blue-700 dark:text-blue-400 font-semibold group-hover:text-blue-800 dark:group-hover:text-blue-300">
                <span className="text-sm">Смотреть решения для Ozon</span>
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-500/10 group-hover:bg-blue-200 dark:group-hover:bg-blue-500/20 flex items-center justify-center group-hover:translate-x-1 transition-all">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          </StaggerItem>

        </StaggerContainer>

        {/* Note on Architecture */}
        <div className="mt-12 text-center">
          <p className="text-xs text-slate-500 font-mono">
            * Архитектура PROFIT SYSTEM поддерживает масштабирование под Яндекс Маркет и Мегамаркет
          </p>
        </div>

      </div>
    </section>
  );
}
