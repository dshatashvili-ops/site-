import { Check, Minus, Sparkles, HelpCircle, ArrowRight } from 'lucide-react';
import { COMPARISON_MATRIX } from '../data/content';

interface ComparisonTableProps {
  onOpenQuiz: () => void;
  onOpenBuy: (productId?: string) => void;
}

export function ComparisonTable({ onOpenQuiz, onOpenBuy }: ComparisonTableProps) {
  return (
    <section id="comparison" className="py-24 bg-slate-100/60 dark:bg-slate-950 relative border-t border-slate-200 dark:border-slate-900 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-blue-700 dark:text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider shadow-xs">
            <span>Матрица возможностей</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-4">
            Сравнение версий PROFIT SYSTEM
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300">
            Детальное сопоставление функционала по всем четырем продуктовым уровням.
          </p>
        </div>

        {/* UX Banner: "Не знаете, какой вариант выбрать?" */}
        <div className="mb-12 max-w-4xl mx-auto p-6 rounded-3xl bg-gradient-to-r from-blue-50 via-indigo-50 to-sky-50 dark:from-blue-950/80 dark:via-slate-900 dark:to-indigo-950/80 border border-blue-200 dark:border-blue-500/30 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="flex items-center gap-4 text-left">
            <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 border border-blue-200 dark:border-blue-500/30">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Не знаете, какой уровень выбрать?</h3>
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                Ответьте на 3 простых вопроса, и наш алгоритм подберет идеальное решение под ваши задачи.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenQuiz}
            className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-blue-500/25 border border-blue-400/30 transition-all flex items-center gap-2 shrink-0 cursor-pointer"
          >
            <span>Помочь выбрать</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Matrix Table */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 overflow-hidden shadow-2xl backdrop-blur-md">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-white border-b border-slate-200 dark:border-slate-800 font-mono text-xs uppercase">
                  <th className="py-5 px-6 min-w-[260px]">Возможности и функционал</th>
                  <th className="py-5 px-4 text-center min-w-[120px] text-blue-700 dark:text-blue-400">01. Расчёт</th>
                  <th className="py-5 px-4 text-center min-w-[120px] text-cyan-700 dark:text-cyan-400">02. Анализ</th>
                  <th className="py-5 px-4 text-center min-w-[120px] text-purple-700 dark:text-purple-400">03. Акции</th>
                  <th className="py-5 px-4 text-center min-w-[140px] text-emerald-700 dark:text-emerald-400 font-bold bg-emerald-100/60 dark:bg-emerald-950/30 border-l border-r border-emerald-200 dark:border-emerald-900/50">
                    04. ТБ (Вся финмодель)
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 text-sm text-slate-700 dark:text-slate-300">
                {COMPARISON_MATRIX.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-4 px-6 font-medium text-slate-900 dark:text-white flex items-center gap-2">
                      <span>{row.feature}</span>
                      {row.tooltip && (
                        <span className="group relative cursor-pointer text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300">
                          <HelpCircle className="w-4 h-4" />
                          <span className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 hidden group-hover:block w-56 p-2 rounded-lg bg-slate-900 text-slate-100 text-[11px] font-normal border border-slate-700 shadow-xl z-30">
                            {row.tooltip}
                          </span>
                        </span>
                      )}
                    </td>

                    <td className="py-4 px-4 text-center">
                      {row.calc ? (
                        <div className="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto">
                          <Check className="w-4 h-4 stroke-[2.5]" />
                        </div>
                      ) : (
                        <Minus className="w-4 h-4 text-slate-300 dark:text-slate-600 mx-auto" />
                      )}
                    </td>

                    <td className="py-4 px-4 text-center">
                      {row.analysis ? (
                        <div className="w-6 h-6 rounded-full bg-cyan-100 dark:bg-cyan-500/20 text-cyan-600 dark:text-cyan-400 flex items-center justify-center mx-auto">
                          <Check className="w-4 h-4 stroke-[2.5]" />
                        </div>
                      ) : (
                        <Minus className="w-4 h-4 text-slate-300 dark:text-slate-600 mx-auto" />
                      )}
                    </td>

                    <td className="py-4 px-4 text-center">
                      {row.promo ? (
                        <div className="w-6 h-6 rounded-full bg-purple-100 dark:bg-purple-500/20 text-purple-600 dark:text-purple-400 flex items-center justify-center mx-auto">
                          <Check className="w-4 h-4 stroke-[2.5]" />
                        </div>
                      ) : (
                        <Minus className="w-4 h-4 text-slate-300 dark:text-slate-600 mx-auto" />
                      )}
                    </td>

                    <td className="py-4 px-4 text-center bg-emerald-50/50 dark:bg-emerald-950/20 border-l border-r border-emerald-200 dark:border-emerald-900/40">
                      {row.tb ? (
                        <div className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
                          <Check className="w-4 h-4 stroke-[2.5]" />
                        </div>
                      ) : (
                        <Minus className="w-4 h-4 text-slate-300 dark:text-slate-600 mx-auto" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Table Footer Actions */}
          <div className="p-6 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              * Все модули предоставляются с бессрочной лицензией без ежемесячной подписки.
            </p>
            <button
              onClick={() => onOpenBuy()}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg transition-all cursor-pointer"
            >
              Перейти к выбору и покупке
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}
