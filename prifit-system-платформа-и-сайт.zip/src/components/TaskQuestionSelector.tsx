import { useState } from 'react';
import { Calculator, BarChart3, Tag, TrendingUp, ArrowRight, CheckCircle2, Sparkles, HelpCircle } from 'lucide-react';
import { AnimatedSection, StaggerContainer, StaggerItem } from './AnimatedSection';

interface TaskQuestionSelectorProps {
  onSelectLevel: (levelCode: string) => void;
  onOpenQuiz: () => void;
  onOpenTbCalculator?: () => void;
}

export function TaskQuestionSelector({ onSelectLevel, onOpenQuiz, onOpenTbCalculator }: TaskQuestionSelectorProps) {
  const [selectedTaskIndex, setSelectedTaskIndex] = useState<number | null>(1); // Default to Card 2 or Card 1

  const taskCards = [
    {
      id: 'task-01',
      levelCode: '01',
      question: '«Какую цену установить?»',
      subtitle: 'Рассчитать цену под заданную экономику товара.',
      answerBadge: '→ 01 РАСЧЁТ ВБ',
      description: 'Автоматический подбор рекомендуемой цены под целевую маржу.',
      icon: Calculator,
      color: 'from-blue-500/20 via-blue-600/10 to-transparent',
      borderColor: 'hover:border-blue-500/50',
      activeBorder: 'border-blue-500 bg-blue-950/40 shadow-blue-500/20',
      badgeColor: 'text-blue-400 bg-blue-500/10 border-blue-500/20'
    },
    {
      id: 'task-02',
      levelCode: '02',
      question: '«Сколько я реально зарабатываю?»',
      subtitle: 'Проверить уже установленную цену.',
      answerBadge: '→ 02 АНАЛИЗ ЦЕН ВБ',
      description: 'Анализ текущей эффективности ваших продаж и реальных удержаний маркетплейса.',
      features: [
        'Фактическая маржа',
        'Чистая прибыль по SKU',
        'Детализация всех расходов',
        'Сравнение с целевой маржой'
      ],
      icon: BarChart3,
      color: 'from-cyan-500/20 via-cyan-600/10 to-transparent',
      borderColor: 'hover:border-cyan-500/50',
      activeBorder: 'border-cyan-500 bg-cyan-950/40 shadow-cyan-500/20',
      badgeColor: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20'
    },
    {
      id: 'task-03',
      levelCode: '03',
      question: '«Можно ли идти в акцию?»',
      subtitle: 'Проверить экономику товара с учётом акционной цены.',
      answerBadge: '→ 03 АКЦИОННЫЕ ЦЕНЫ',
      description: 'Загрузка акционных цен Wildberries, мгновенный расчёт акционной экономики и защита от ухода в минус.',
      icon: Tag,
      color: 'from-purple-500/20 via-purple-600/10 to-transparent',
      borderColor: 'hover:border-purple-500/50',
      activeBorder: 'border-purple-500 bg-purple-950/40 shadow-purple-500/20',
      badgeColor: 'text-purple-400 bg-purple-500/10 border-purple-500/20'
    },
    {
      id: 'task-04',
      levelCode: '04',
      question: '«Сколько должен зарабатывать мой бизнес?»',
      subtitle: 'Рассчитать финансовый порог и необходимую выручку.',
      answerBadge: '→ 04 ТБ',
      description: 'Связь unit-экономики с постоянными расходами компании и финансовым планированием.',
      features: [
        'Точка безубыточности (ТБ)',
        'Плановая выручка под доход',
        'Желаемая прибыль',
        'Сценарный анализ «Что если»'
      ],
      icon: TrendingUp,
      color: 'from-emerald-500/20 via-emerald-600/10 to-transparent',
      borderColor: 'hover:border-emerald-500/50',
      activeBorder: 'border-emerald-500 bg-emerald-950/40 shadow-emerald-500/20',
      badgeColor: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
    }
  ];

  const currentSelected = selectedTaskIndex !== null ? taskCards[selectedTaskIndex] : null;

  return (
    <section id="task-selector" className="py-24 bg-slate-100/70 dark:bg-slate-950 relative border-b border-slate-200 dark:border-slate-900 transition-colors overflow-hidden">
      {/* Glow background effects */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-600 dark:text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider font-semibold shadow-xs">
            <HelpCircle className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>Навигатор по задачам</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-brand font-extrabold text-slate-900 dark:text-white tracking-tight mb-4">
            Какой вопрос вы хотите решить?
          </h2>

          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-sans">
            Выберите задачу — PROFIT SYSTEM покажет подходящий уровень системы.
          </p>
        </AnimatedSection>

        {/* 4 Task Cards Grid */}
        <StaggerContainer staggerDelay={0.1} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {taskCards.map((card, idx) => {
            const isSelected = selectedTaskIndex === idx;
            const Icon = card.icon;

            return (
              <StaggerItem key={card.id}>
                <div
                  onClick={() => setSelectedTaskIndex(idx)}
                  className={`group relative rounded-3xl p-6 sm:p-7 transition-all duration-300 cursor-pointer flex flex-col justify-between border backdrop-blur-md h-full ${
                    isSelected
                      ? `${card.activeBorder} shadow-xl scale-[1.02]`
                      : `bg-white dark:bg-slate-900/60 border-slate-200 dark:border-slate-800/90 ${card.borderColor} hover:bg-slate-50 dark:hover:bg-slate-900/90 hover:scale-[1.01]`
                  }`}
                >
                  {/* Background soft gradient */}
                  <div className={`absolute inset-0 bg-gradient-to-b ${card.color} rounded-3xl opacity-40 group-hover:opacity-100 transition-opacity pointer-events-none`} />

                  <div className="relative z-10">
                    {/* Top bar */}
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-2.5 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white`}>
                        <Icon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <span className={`text-[11px] font-mono font-bold px-2.5 py-1 rounded-full border ${card.badgeColor}`}>
                        {card.answerBadge}
                      </span>
                    </div>

                    {/* Question */}
                    <h3 className="text-xl font-brand font-bold text-slate-900 dark:text-white mb-2 leading-tight group-hover:text-blue-600 dark:group-hover:text-blue-300 transition-colors">
                      {card.question}
                    </h3>

                    {/* Subtitle */}
                    <p className="text-xs font-mono text-slate-500 dark:text-slate-400 mb-4 font-medium">
                      {card.subtitle}
                    </p>

                    {/* Description or Features List */}
                    {card.features ? (
                      <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 font-sans my-4">
                        {card.features.map((feat, fIdx) => (
                          <li key={fIdx} className="flex items-center gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-xs text-slate-600 dark:text-slate-300 font-sans leading-relaxed my-4">
                        {card.description}
                      </p>
                    )}
                  </div>

                  {/* Card Selection Footer */}
                  <div className="relative z-10 pt-4 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs font-mono mt-auto">
                    <span className={isSelected ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-400 dark:text-slate-500'}>
                      {isSelected ? '✓ Выбрано' : 'Нажмите для выбора'}
                    </span>
                    <ArrowRight className={`w-4 h-4 transition-transform ${isSelected ? 'translate-x-1 text-blue-600 dark:text-blue-400' : 'text-slate-400 dark:text-slate-600 group-hover:text-slate-600 dark:group-hover:text-slate-400'}`} />
                  </div>
                </div>
              </StaggerItem>
            );
          })}
        </StaggerContainer>

        {/* Dynamic Selection Result Banner */}
        {currentSelected && (
          <div className="max-w-4xl mx-auto mb-12 p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-blue-500/40 shadow-xl dark:shadow-2xl shadow-blue-500/10 dark:shadow-blue-950/50 flex flex-col sm:flex-row items-center justify-between gap-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 space-y-1.5 text-center sm:text-left">
              <div className="text-xs font-mono text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Вы выбрали: <span className="text-slate-900 dark:text-white font-semibold">{currentSelected.question}</span>
              </div>
              <div className="text-lg sm:text-2xl font-brand font-extrabold text-slate-900 dark:text-white flex items-center justify-center sm:justify-start gap-2">
                <span>Вам подходит:</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-sky-500 dark:from-blue-400 dark:to-cyan-300 underline decoration-blue-500/50 underline-offset-4">
                  {currentSelected.answerBadge.replace('→ ', '')}
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 font-sans max-w-xl">
                {currentSelected.description}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 shrink-0 relative z-10">
              {currentSelected.levelCode === '04' && onOpenTbCalculator && (
                <button
                  onClick={onOpenTbCalculator}
                  className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-brand font-black text-sm shadow-xl shadow-amber-500/20 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>⚡ Запустить Веб-ТБ онлайн</span>
                </button>
              )}
              <button
                onClick={() => onSelectLevel(currentSelected.levelCode)}
                className="px-7 py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-brand font-bold text-sm shadow-xl shadow-blue-600/30 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer border border-blue-400/30"
              >
                <span>Подробнее о модуле</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Secondary CTA: Quiz Launch */}
        <div className="text-center pt-4">
          <div className="inline-flex flex-col sm:flex-row items-center gap-3 p-4 px-6 rounded-2xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 text-sm font-sans text-slate-700 dark:text-slate-300 shadow-xs">
            <span>Не уверены, какой уровень вам нужен?</span>
            <button
              onClick={onOpenQuiz}
              className="font-brand font-bold text-blue-600 dark:text-blue-400 hover:text-blue-500 dark:hover:text-blue-300 underline underline-offset-4 hover:scale-105 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-cyan-500 dark:text-cyan-400" />
              <span>Пройти короткий подбор →</span>
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}
