import { FileSpreadsheet, Zap, ShieldCheck, Cpu, Database, RefreshCw } from 'lucide-react';
import { AnimatedSection, StaggerContainer, StaggerItem } from './AnimatedSection';

export function ExcelSystemAdvantages() {
  const points = [
    {
      icon: <ShieldCheck className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />,
      title: 'Без подписки и скрытых платежей',
      desc: 'Вы платите один раз и получаете бессрочный доступ к выбранному модулю. Никаких списаний каждые 30 дней.'
    },
    {
      icon: <FileSpreadsheet className="w-6 h-6 text-green-600 dark:text-green-400" />,
      title: 'Знакомый и мощный интерфейс Excel',
      desc: 'Не нужно обучать сотрудников новой громоздкой облачной ERP-системе. Все расчёты выполняются мгновенно в Microsoft Excel.'
    },
    {
      icon: <Cpu className="w-6 h-6 text-blue-600 dark:text-blue-400" />,
      title: 'Полный контроль и конфиденциальность',
      desc: 'Ваши финансовые показатели, маржинальность и коммерческая тайна хранятся локально у вас на компьютере.'
    },
    {
      icon: <Zap className="w-6 h-6 text-amber-500 dark:text-yellow-400" />,
      title: 'Мгновенный запуск за 2 минуты',
      desc: 'Никаких недель интеграций и вызовов программистов. Скачали файл, вставили артикулы — и система сразу готова к работе.'
    },
    {
      icon: <Database className="w-6 h-6 text-purple-600 dark:text-purple-400" />,
      title: 'Гибкие алгоритмы сценарного анализа',
      desc: 'Изменяйте любые параметры (скидки, затраты на логистику или налоги) и смотрите последствия в режиме «Что если».'
    },
    {
      icon: <RefreshCw className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />,
      title: 'Актуальность правил маркетплейсов',
      desc: 'Алгоритмы построены с учетом актуальных сетках комиссий, эквайринга, логистики и удержаний Wildberries и Ozon в 2026 году.'
    }
  ];

  return (
    <section className="py-24 bg-slate-100/80 dark:bg-slate-950/90 border-t border-slate-200 dark:border-slate-900 transition-colors relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-blue-700 dark:text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider shadow-xs">
            <span>Инструмент для селлеров</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-4">
            Excel, который работает как система
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300">
            Мы взяли удобство и гибкость таблиц Excel и наложили на них строго логические математические алгоритмы оценки экономики бизнеса.
          </p>
        </AnimatedSection>

        {/* 6 Advantage Cards Grid */}
        <StaggerContainer staggerDelay={0.1} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {points.map((pt, idx) => (
            <StaggerItem key={idx}>
              <div className="p-8 rounded-3xl bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-all hover:-translate-y-1 shadow-sm hover:shadow-md h-full">
                <div className="w-12 h-12 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-center mb-6">
                  {pt.icon}
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{pt.title}</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">{pt.desc}</p>
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>

      </div>
    </section>
  );
}
