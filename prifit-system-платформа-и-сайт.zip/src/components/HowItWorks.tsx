import { HOW_IT_WORKS_STEPS } from '../data/content';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { AnimatedSection, StaggerContainer, StaggerItem } from './AnimatedSection';

export function HowItWorks() {
  return (
    <section className="py-24 bg-slate-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider">
            <span>Пошаговый сценарий</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
            Как это работает
          </h2>
          <p className="text-base sm:text-lg text-slate-300">
            Последовательный процесс расчёта и управления прибыльностью бизнеса от загрузки артикулов до финального отчета.
          </p>
        </AnimatedSection>

        {/* 6 Steps Grid */}
        <StaggerContainer staggerDelay={0.1} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {HOW_IT_WORKS_STEPS.map((stepItem, index) => (
            <StaggerItem key={stepItem.step}>
              <div
                className="relative p-8 rounded-3xl bg-slate-900/60 border border-slate-800 hover:border-blue-500/50 transition-all group h-full"
              >
                <div className="flex items-center justify-between mb-6">
                  <span className="text-3xl font-black font-mono text-blue-500/40 group-hover:text-blue-400 transition-colors">
                    {stepItem.step}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center text-slate-400 group-hover:text-white group-hover:border-blue-500 transition-colors">
                    <CheckCircle2 className="w-4 h-4 text-blue-400" />
                  </div>
                </div>

                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-blue-300 transition-colors">
                  {stepItem.title}
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {stepItem.desc}
                </p>

                {/* Connecting line for visual flow on large screens */}
                {index < HOW_IT_WORKS_STEPS.length - 1 && (
                  <div className="hidden lg:block absolute -right-4 top-1/2 -translate-y-1/2 z-10 text-slate-700">
                    <ArrowRight className="w-6 h-6" />
                  </div>
                )}
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>

      </div>
    </section>
  );
}
