import { ArrowRight, Calculator, BarChart3, Tag, TrendingUp, Layers, CheckCircle2 } from 'lucide-react';
import { AnimatedSection, StaggerContainer, StaggerItem } from './AnimatedSection';

interface BusinessEconomyChainProps {
  onGoToSimulator: () => void;
  onGoToProducts: () => void;
}

export function BusinessEconomyChain({ onGoToSimulator, onGoToProducts }: BusinessEconomyChainProps) {
  const chainSteps = [
    {
      step: '01',
      tag: '01 РАСЧЁТ',
      title: 'ЦЕНА ТОВАРА',
      subtitle: 'Unit-экономика отдельного SKU',
      formula: 'Себестоимость → Комиссия → Логистика → Налог → Чистая прибыль',
      role: 'Базовый уровень ценообразования: подбор цены под целевую маржу.',
      icon: Calculator,
      color: 'border-blue-500/40 bg-blue-950/20 text-blue-400',
      arrowColor: 'text-blue-500',
    },
    {
      step: '02',
      tag: '02 АНАЛИЗ ЦЕН',
      title: 'РЕАЛЬНАЯ МАРЖА',
      subtitle: 'Контроль фактической доходности',
      formula: 'Действующая цена → Удержания WB → Фактическая маржа %',
      role: 'Проверка эффективности уже установленных цен на маркетплейсе.',
      icon: BarChart3,
      color: 'border-cyan-500/40 bg-cyan-950/20 text-cyan-400',
      arrowColor: 'text-cyan-500',
    },
    {
      step: '03',
      tag: '03 АКЦИИ',
      title: 'АКЦИОННАЯ ЭКОНОМИКА',
      subtitle: 'Защита прибыли в распродажах',
      formula: 'Акционная цена → Проверка скидки → Сохранение маржи',
      role: 'Фильтр убыточных товаров перед входом в распродажи WB.',
      icon: Tag,
      color: 'border-purple-500/40 bg-purple-950/20 text-purple-400',
      arrowColor: 'text-purple-500',
    },
    {
      step: '04',
      tag: '04 ТБ',
      title: 'ЭКОНОМИКА БИЗНЕСА',
      subtitle: 'Финансовый порог компании',
      formula: '(Постоянные расходы + Прибыль) ÷ Маржа = ТБ',
      role: 'Связь unit-экономики с арендой, ФОТ и планом выручки всей компании.',
      icon: TrendingUp,
      color: 'border-emerald-500/40 bg-emerald-950/20 text-emerald-400',
      arrowColor: 'text-emerald-500',
    },
  ];

  return (
    <section className="py-24 bg-slate-50 dark:bg-slate-950 relative border-b border-slate-200 dark:border-slate-900 transition-colors overflow-hidden">
      {/* Background glow ambient */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[500px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-600 dark:text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider font-semibold shadow-xs">
            <Layers className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>Сквозная финансовая модель</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-brand font-extrabold text-slate-900 dark:text-white tracking-tight mb-4">
            От цены товара к экономике всего бизнеса
          </h2>

          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-sans">
            Как PROFIT SYSTEM объединяет unit-экономику отдельного SKU с общими финансовыми результатами вашей компании.
          </p>
        </AnimatedSection>

        {/* Visual Chain Progression Grid */}
        <StaggerContainer staggerDelay={0.12} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12 relative">
          {chainSteps.map((item, index) => {
            const Icon = item.icon;
            const isLast = index === chainSteps.length - 1;

            return (
              <StaggerItem key={index}>
                <div className="relative flex flex-col justify-between h-full">
                  
                  {/* Connector Arrow for Desktop */}
                  {!isLast && (
                    <div className="hidden lg:block absolute -right-3 top-1/2 -translate-y-1/2 z-20">
                      <div className="w-6 h-6 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 shadow-md">
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  )}

                  <div className={`h-full rounded-3xl p-6 sm:p-7 bg-white dark:bg-slate-900/80 border ${item.color} backdrop-blur-md flex flex-col justify-between shadow-xl relative overflow-hidden group hover:scale-[1.02] transition-all`}>
                    
                    {/* Step watermark background */}
                    <span className="absolute top-2 right-4 font-mono font-black text-6xl text-slate-200 dark:text-slate-800/20 select-none pointer-events-none">
                      {item.step}
                    </span>

                    <div>
                      {/* Top Tag & Icon */}
                      <div className="flex items-center justify-between mb-5 relative z-10">
                        <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                          <Icon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                        </div>
                        <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                          {item.tag}
                        </span>
                      </div>

                      {/* Step Title */}
                      <h3 className="text-xl font-brand font-bold text-slate-900 dark:text-white mb-1 leading-tight group-hover:text-blue-600 dark:group-hover:text-blue-300 transition-colors">
                        {item.title}
                      </h3>

                      <p className="text-xs font-mono text-slate-500 dark:text-slate-400 mb-4 font-medium">
                        {item.subtitle}
                      </p>

                      {/* Formula box */}
                      <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800/80 text-[11px] font-mono text-blue-700 dark:text-blue-300 mb-4 leading-relaxed">
                        {item.formula}
                      </div>

                      {/* Role / Description */}
                      <p className="text-xs font-sans text-slate-600 dark:text-slate-300 leading-relaxed">
                        {item.role}
                      </p>
                    </div>

                    {/* Bottom indicator */}
                    <div className="pt-4 mt-6 border-t border-slate-200 dark:border-slate-800/80 flex items-center gap-2 text-[11px] font-mono text-slate-500 dark:text-slate-400">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                      <span>Уровень {item.step} в единой системе</span>
                    </div>

                  </div>
                </div>
              </StaggerItem>
            );
          })}
        </StaggerContainer>

        {/* Summary Banner Bottom */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row items-center justify-between gap-6 shadow-xl dark:shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

          <div className="space-y-2 max-w-3xl text-center lg:text-left relative z-10">
            <span className="text-xs font-mono text-blue-600 dark:text-blue-400 uppercase tracking-wider font-semibold">
              Единый финансовый алгоритм
            </span>
            <p className="text-base sm:text-lg font-sans text-slate-800 dark:text-slate-200 leading-relaxed">
              PROFIT SYSTEM — это единая сквозная финансовая модель, которая берет за основу юнит-экономику каждого товара и рассчитывает точки финансовой устойчивости всей вашей компании.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0 relative z-10">
            <button
              onClick={onGoToSimulator}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-brand font-bold text-sm shadow-xl shadow-blue-600/30 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 cursor-pointer border border-blue-400/30"
            >
              <span>Попробовать расчёт в калькуляторе</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}
