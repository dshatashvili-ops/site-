import { useState } from 'react';
import { Sliders, RefreshCw, CheckCircle2, AlertTriangle, ArrowRight, DollarSign, Calculator } from 'lucide-react';

interface InteractiveCalculatorProps {
  onNavigateToProducts?: () => void;
}

export function InteractiveCalculator({ onNavigateToProducts }: InteractiveCalculatorProps) {
  const [costPrice, setCostPrice] = useState<number>(1500);
  const [targetMargin, setTargetMargin] = useState<number>(15); // %
  const [marketplaceCommission, setMarketplaceCommission] = useState<number>(22); // %
  const [logistics, setLogistics] = useState<number>(250);
  const [adsPercent, setAdsPercent] = useState<number>(7); // %

  // Calculation formula simulation
  // Price = (Cost + Logistics) / (1 - (Commission% + Ads% + Tax% + TargetMargin%)/100)
  const taxPercent = 6; // УСН 6%
  const totalDeductionPercent = marketplaceCommission + adsPercent + taxPercent + targetMargin;
  
  // Safe limit for calculation
  const clampedDeduction = Math.min(totalDeductionPercent, 90);
  const calculatedClientPrice = Math.round((costPrice + logistics) / (1 - clampedDeduction / 100));
  
  const commissionRub = Math.round((calculatedClientPrice * marketplaceCommission) / 100);
  const adsRub = Math.round((calculatedClientPrice * adsPercent) / 100);
  const taxRub = Math.round((calculatedClientPrice * taxPercent) / 100);
  const netProfit = Math.round((calculatedClientPrice * targetMargin) / 100);

  const getStatus = () => {
    if (targetMargin >= 15) return { text: 'ВЫСОКАЯ РЕНТАБЕЛЬНОСТЬ', color: 'text-emerald-400 bg-emerald-950/60 border-emerald-800' };
    if (targetMargin >= 10) return { text: 'НОРМАЛЬНАЯ МАРЖА', color: 'text-blue-400 bg-blue-950/60 border-blue-800' };
    return { text: 'РИСК УБЫТКА', color: 'text-amber-400 bg-amber-950/60 border-amber-800' };
  };

  const statusInfo = getStatus();

  return (
    <section id="simulator" className="py-20 bg-slate-950/90 border-y border-slate-900 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider font-semibold shadow-inner">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            <span>Демонстрационная модель</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-brand font-extrabold text-white tracking-tight mb-4">
            Что произойдёт с вашей прибылью?
          </h2>
          <p className="text-base sm:text-lg text-slate-300 font-sans mb-6">
            Попробуйте изменить маржинальность или расходы, чтобы в реальном времени увидеть, как сработает алгоритм подбора цены PROFIT SYSTEM.
          </p>

          {/* Action button next to section header */}
          {onNavigateToProducts && (
            <div className="flex justify-center mt-4">
              <button
                onClick={onNavigateToProducts}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-brand font-bold text-sm shadow-xl shadow-blue-500/25 hover:shadow-blue-500/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2.5 cursor-pointer border border-blue-400/30"
              >
                <Calculator className="w-4 h-4 text-cyan-300" />
                <span>Попробовать расчёт в PROFIT SYSTEM</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Interactive Widget Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch max-w-6xl mx-auto">
          
          {/* Left Controls Column */}
          <div className="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl backdrop-blur-md">
            <div>
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-800">
                <Sliders className="w-5 h-5 text-blue-400" />
                <h3 className="text-lg font-bold text-white">Параметры юнит-экономики</h3>
              </div>

              {/* Slider 1: Target Margin */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-mono uppercase text-slate-400">Целевая маржинальность (%):</label>
                  <span className="text-lg font-extrabold text-emerald-400 font-mono">{targetMargin} %</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="35"
                  step="1"
                  value={targetMargin}
                  onChange={(e) => setTargetMargin(Number(e.target.value))}
                  className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                  <span>5% (Минимум)</span>
                  <span>15% (Цель)</span>
                  <span>35% (Премиум)</span>
                </div>
              </div>

              {/* Input 2: Cost Price */}
              <div className="mb-6">
                <label className="text-xs font-mono uppercase text-slate-400 block mb-2">Себестоимость товара (₽):</label>
                <div className="relative">
                  <input
                    type="number"
                    value={costPrice}
                    onChange={(e) => setCostPrice(Math.max(100, Number(e.target.value)))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white font-mono font-bold text-base focus:outline-none focus:border-blue-500 transition-colors"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">₽</span>
                </div>
              </div>

              {/* Input 3: Logistics */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="text-xs font-mono uppercase text-slate-400 block mb-2">Логистика (кС) ₽:</label>
                  <input
                    type="number"
                    value={logistics}
                    onChange={(e) => setLogistics(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-mono uppercase text-slate-400 block mb-2">Комиссия WB/Ozon %:</label>
                  <input
                    type="number"
                    value={marketplaceCommission}
                    onChange={(e) => setMarketplaceCommission(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-500 font-mono pt-4 border-t border-slate-800/80">
              * В полной версии PROFIT SYSTEM данные комиссии и логистики подтягиваются автоматически.
            </p>
          </div>

          {/* Right Live Output Column */}
          <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-40 h-40 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-lg font-bold text-white">Результат расчёта</h3>
                </div>
                <span className={`text-[11px] font-mono font-bold px-3 py-1 rounded-full border ${statusInfo.color}`}>
                  {statusInfo.text}
                </span>
              </div>

              {/* Recommended Price Display */}
              <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 mb-6 text-center">
                <span className="text-xs font-mono uppercase text-slate-400 block mb-1">Рекомендуемая цена клиенту:</span>
                <span className="text-4xl sm:text-5xl font-black text-white font-sans tracking-tight">
                  {calculatedClientPrice.toLocaleString('ru-RU')} ₽
                </span>
              </div>

              {/* Output breakdown table */}
              <div className="space-y-3 font-mono text-xs">
                <div className="flex justify-between p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/60 text-slate-300">
                  <span>Чистая прибыль c единицы:</span>
                  <span className="font-bold text-emerald-400">{netProfit.toLocaleString('ru-RU')} ₽</span>
                </div>
                <div className="flex justify-between p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/60 text-slate-300">
                  <span>Комиссия площадки ({marketplaceCommission}%):</span>
                  <span>{commissionRub.toLocaleString('ru-RU')} ₽</span>
                </div>
                <div className="flex justify-between p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/60 text-slate-300">
                  <span>Логистика и доставка:</span>
                  <span>{logistics.toLocaleString('ru-RU')} ₽</span>
                </div>
                <div className="flex justify-between p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/60 text-slate-300">
                  <span>Рекламный бюджет ({adsPercent}%):</span>
                  <span>{adsRub.toLocaleString('ru-RU')} ₽</span>
                </div>
                <div className="flex justify-between p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/60 text-slate-300">
                  <span>Налог УСН ({taxPercent}%):</span>
                  <span>{taxRub.toLocaleString('ru-RU')} ₽</span>
                </div>
              </div>

              {/* Call to action inside results card */}
              {onNavigateToProducts && (
                <div className="mt-6 pt-4 border-t border-slate-800/80">
                  <button
                    onClick={onNavigateToProducts}
                    className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-brand font-bold text-sm shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Попробовать расчёт в PROFIT SYSTEM</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>Применение алгоритма сценарного анализа «Что если»</span>
              <span className="text-blue-400 font-semibold font-mono">PROFIT SYSTEM v9</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
