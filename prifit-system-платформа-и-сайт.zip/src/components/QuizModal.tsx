import React, { useState, useEffect } from 'react';
import { X, Sparkles, ArrowRight, RotateCcw, CheckCircle2 } from 'lucide-react';
import { ProductLevelId } from '../types';

interface QuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (productId: ProductLevelId) => void;
  onCompareAll?: () => void;
}

interface QuizStep {
  title: string;
  subtitle?: string;
  options: {
    label: string;
    description?: string;
    weight: { calc?: number; analysis?: number; promo?: number; tb?: number };
  }[];
}

const QUIZ_STEPS: QuizStep[] = [
  {
    title: 'Какой маркетплейс вы используете?',
    subtitle: 'Выберите ваш основной или планируемый канал продаж',
    options: [
      { label: 'Wildberries', description: 'Продажи или запуск на WB', weight: { calc: 1, analysis: 1, promo: 1, tb: 1 } },
      { label: 'Ozon', description: 'Продажи или запуск на Ozon', weight: { calc: 1, analysis: 1, promo: 1, tb: 1 } },
      { label: 'Wildberries + Ozon', description: 'Мультиканальные продажи на двух площадках', weight: { calc: 1, analysis: 1, promo: 1, tb: 1 } },
    ]
  },
  {
    title: 'Что вам нужно сделать прямо сейчас?',
    subtitle: 'Основная операционная задача',
    options: [
      { label: 'Рассчитать цену нового товара', description: 'Подобрать правильную цену под целевую маржу перед запуском', weight: { calc: 3 } },
      { label: 'Проверить текущую цену', description: 'Оценить реальную чистую прибыль и удержания по существующим SKU', weight: { analysis: 3 } },
      { label: 'Проверить участие в акции', description: 'Понять, выгодно ли снижать цену для участия в распродаже маркетплейса', weight: { promo: 3 } },
      { label: 'Рассчитать экономику бизнеса', description: 'Учесть постоянные расходы, ФОТ и определить точку безубыточности', weight: { tb: 3 } },
    ]
  },
  {
    title: 'У вас уже установлены цены на товары?',
    subtitle: 'Текущий статус ваших карточек на маркетплейсе',
    options: [
      { label: 'Да, товары уже продаются по действующим ценам', weight: { analysis: 2, promo: 2, tb: 1 } },
      { label: 'Нет, я только готовлюсь к заведению спецификаций', weight: { calc: 3 } },
    ]
  },
  {
    title: 'Вы участвуете в акциях и распродажах маркетплейса?',
    subtitle: 'Автоакции и сезонные скидки WB / Ozon',
    options: [
      { label: 'Да, постоянно или планирую регулярно участвовать', weight: { promo: 3, tb: 1 } },
      { label: 'Нет, меня интересует только базовый расчёт и текущие цены', weight: { calc: 1, analysis: 1 } },
    ]
  },
  {
    title: 'Нужно ли учитывать постоянные расходы бизнеса?',
    subtitle: 'Аренда, заработная плата, софт, аутсорсинг и финпланирование',
    options: [
      { label: 'Да, нужно видеть точку безубыточности всей компании', weight: { tb: 3 } },
      { label: 'Нет, пока достаточно unit-экономики отдельных SKU', weight: { calc: 1, analysis: 1, promo: 1 } },
    ]
  },
  {
    title: 'Что для вас важнее всего на данном этапе?',
    subtitle: 'Ключевой приоритет финансового контроля',
    options: [
      { label: 'Цена отдельного товара', description: 'Точный расчёт рекомендуемой цены под маржу', weight: { calc: 3 } },
      { label: 'Рентабельность ассортимента', description: 'Контроль прибыльности существующих цен', weight: { analysis: 3 } },
      { label: 'Экономика акций', description: 'Защита маржи при участии в распродажах', weight: { promo: 3 } },
      { label: 'Финансовое планирование бизнеса', description: 'Планирование выручки и сценарный анализ', weight: { tb: 3 } },
    ]
  }
];

export function QuizModal({ isOpen, onClose, onSelectProduct, onCompareAll }: QuizModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [scores, setScores] = useState({ calc: 0, analysis: 0, promo: 0, tb: 0 });
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSelectOption = (weight: { calc?: number; analysis?: number; promo?: number; tb?: number }) => {
    const newScores = {
      calc: scores.calc + (weight.calc || 0),
      analysis: scores.analysis + (weight.analysis || 0),
      promo: scores.promo + (weight.promo || 0),
      tb: scores.tb + (weight.tb || 0),
    };
    setScores(newScores);

    if (currentStep < QUIZ_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setIsFinished(true);
    }
  };

  const handleReset = () => {
    setCurrentStep(0);
    setScores({ calc: 0, analysis: 0, promo: 0, tb: 0 });
    setIsFinished(false);
  };

  // Determine top level
  const getRecommendedLevel = (): { id: ProductLevelId; code: string; title: string; subtitle: string; checklist: string[] } => {
    let topId: ProductLevelId = 'calc';
    let maxScore = scores.calc;

    if (scores.analysis > maxScore) {
      maxScore = scores.analysis;
      topId = 'analysis';
    }
    if (scores.promo > maxScore) {
      maxScore = scores.promo;
      topId = 'promo';
    }
    if (scores.tb > maxScore) {
      maxScore = scores.tb;
      topId = 'tb';
    }

    switch (topId) {
      case 'tb':
        return {
          id: 'tb',
          code: '04',
          title: 'PROFIT SYSTEM 04 — ТБ | ТОЧКА БЕЗУБЫТОЧНОСТИ',
          subtitle: 'По вашим ответам вам подходит уровень 04 ТБ. Вы хотите комплексно управлять экономикой бизнеса, учитывать постоянные расходы и иметь сценарное планирование выручки.',
          checklist: [
            'Анализ unit-экономики товара',
            'Анализ текущей цены и маржи',
            'Загрузка акционных цен',
            'Расчёт точки безубыточности бизнеса (ТБ)',
            'Учёт постоянных расходов (аренда, ФОТ, сервисы)',
            'Сценарный анализ «Что если»'
          ]
        };
      case 'promo':
        return {
          id: 'promo',
          code: '03',
          title: 'PROFIT SYSTEM 03 — АКЦИОННЫЕ ЦЕНЫ',
          subtitle: 'По вашим ответам вам подходит уровень 03 АКЦИОННЫЕ ЦЕНЫ. Вы работаете с установленными ценами и хотите защитить рентабельность при участии в распродажах маркетплейса.',
          checklist: [
            'Анализ unit-экономики товара',
            'Анализ текущей цены и маржинальности',
            'Загрузка акционных цен Wildberries',
            'Расчёт экономики акционной цены',
            'Проверка рентабельности и отсечение убыточных товаров'
          ]
        };
      case 'analysis':
        return {
          id: 'analysis',
          code: '02',
          title: 'PROFIT SYSTEM 02 — АНАЛИЗ ЦЕН ВБ',
          subtitle: 'По вашим ответам вам подходит уровень 02 АНАЛИЗ ЦЕН ВБ. У вас уже есть действующих ассортимент и вам нужно контролировать фактическую маржу и удержания.',
          checklist: [
            'Анализ unit-экономики товара',
            'Проверка уже установленных цен',
            'Детализация фактических расходов (логистика, комиссии, налоги)',
            'Сравнение текущей маржи с целевыми показателями'
          ]
        };
      case 'calc':
      default:
        return {
          id: 'calc',
          code: '01',
          title: 'PROFIT SYSTEM 01 — РАСЧЁТ ВБ',
          subtitle: 'По вашим ответам вам подходит уровень 01 РАСЧЁТ ВБ. Ваша главная задача — точно подобрать рекомендуемую цену товара под целевую маржу перед началом продаж.',
          checklist: [
            'Автоматический подбор цены под целевую маржу',
            'Полный расчёт переменных расходов (комиссия, кС, логистика, налоги)',
            'Расчёт чистой прибыли с 1 штуки',
            'Оценка итоговой себестоимости и доли затрат'
          ]
        };
    }
  };

  const rec = getRecommendedLevel();
  const activeStepObj = QUIZ_STEPS[currentStep];

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 md:p-8 bg-slate-950/85 backdrop-blur-md overflow-y-auto overscroll-contain animate-fade-in"
    >
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl shadow-2xl my-auto flex flex-col max-h-[calc(100vh-1.5rem)] sm:max-h-[calc(100vh-3rem)] overflow-hidden">
        
        {/* Sticky Header with Close Button */}
        <div className="p-4 sm:p-5 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 flex items-center justify-between gap-4 z-20 shrink-0">
          <div className="flex items-center gap-2 text-blue-400 font-mono text-[11px] sm:text-xs uppercase font-semibold">
            <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              {!isFinished
                ? `Подбор уровня PROFIT SYSTEM • Шаг ${currentStep + 1} из ${QUIZ_STEPS.length}`
                : 'Результат подбора системы'}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 cursor-pointer transition-colors shrink-0"
            title="Закрыть (Esc)"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Container */}
        <div className="overflow-y-auto p-5 sm:p-8 flex-1">
          {!isFinished ? (
            <>
              {/* Progress Bar */}
              <div className="w-full bg-slate-950 h-2 rounded-full mb-6 overflow-hidden border border-slate-800">
                <div
                  className="bg-gradient-to-r from-blue-500 to-cyan-400 h-full transition-all duration-300"
                  style={{ width: `${((currentStep + 1) / QUIZ_STEPS.length) * 100}%` }}
                />
              </div>

              <h3 className="text-xl sm:text-2xl font-brand font-bold text-white mb-2 leading-tight">
                {activeStepObj.title}
              </h3>
              {activeStepObj.subtitle && (
                <p className="text-xs text-slate-400 font-sans mb-6">
                  {activeStepObj.subtitle}
                </p>
              )}

              {/* Options List */}
              <div className="space-y-3 mb-6">
                {activeStepObj.options.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(opt.weight)}
                    className="w-full text-left p-4 rounded-2xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-blue-500/50 transition-all group flex items-center justify-between gap-4 cursor-pointer"
                  >
                    <div>
                      <h4 className="font-brand font-bold text-white text-sm group-hover:text-blue-300 transition-colors mb-0.5">
                        {opt.label}
                      </h4>
                      {opt.description && (
                        <p className="text-xs font-sans text-slate-400 leading-relaxed">
                          {opt.description}
                        </p>
                      )}
                    </div>
                    <div className="w-7 h-7 rounded-full bg-slate-900 border border-slate-800 group-hover:border-blue-500 group-hover:bg-blue-500/20 flex items-center justify-center shrink-0">
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-400 transition-transform group-hover:translate-x-0.5" />
                    </div>
                  </button>
                ))}
              </div>

              {/* Modal Footer Controls */}
              <div className="flex items-center justify-between text-xs text-slate-500 border-t border-slate-800/80 pt-4 font-mono">
                <button
                  onClick={handleReset}
                  className="flex items-center gap-1.5 hover:text-slate-300 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Начать сначала</span>
                </button>

                <span>Платформа PROFIT SYSTEM</span>
              </div>
            </>
          ) : (
            /* Finished Recommendation Result Screen */
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-mono font-semibold uppercase tracking-wider">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>РЕКОМЕНДАЦИЯ ПО ВАШИМ ОТВЕТАМ</span>
              </div>

              <div>
                <div className="text-xs font-mono text-slate-400 uppercase tracking-widest mb-1">
                  ВАМ ПОДХОДИТ:
                </div>
                <h3 className="text-2xl sm:text-3xl font-brand font-extrabold text-white tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-300 to-indigo-200">
                  {rec.title}
                </h3>
              </div>

              <p className="text-sm font-sans text-slate-300 leading-relaxed p-4 rounded-2xl bg-slate-950 border border-slate-800/80">
                {rec.subtitle}
              </p>

              {/* Checklist */}
              <div className="space-y-2">
                <div className="text-xs font-mono text-slate-400 uppercase font-semibold">
                  Что вы получите в этом модуле:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {rec.checklist.map((item, i) => (
                    <div key={i} className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/60 text-xs text-slate-200 font-sans">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-end gap-3">
                {onCompareAll && (
                  <button
                    onClick={() => {
                      onClose();
                      onCompareAll();
                    }}
                    className="w-full sm:w-auto px-5 py-3 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white font-brand font-semibold text-xs border border-slate-800 transition-colors cursor-pointer"
                  >
                    Сравнить все уровни
                  </button>
                )}

                <button
                  onClick={() => {
                    onSelectProduct(rec.id);
                    onClose();
                  }}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-brand font-bold text-sm shadow-xl shadow-blue-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer border border-blue-400/30"
                >
                  <span>Посмотреть продукт</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
