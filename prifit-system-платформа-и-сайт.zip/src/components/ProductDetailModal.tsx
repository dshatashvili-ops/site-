import React, { useEffect } from 'react';
import { X, CheckCircle2, ArrowRight, Download } from 'lucide-react';
import { ProductLevel, Marketplace } from '../types';

interface ProductDetailModalProps {
  product: ProductLevel | null;
  currentMarketplace: Marketplace;
  onClose: () => void;
  onOpenBuy: (productId: string) => void;
  onOpenDemo: () => void;
}

export function ProductDetailModal({
  product,
  currentMarketplace,
  onClose,
  onOpenBuy,
  onOpenDemo,
}: ProductDetailModalProps) {
  useEffect(() => {
    if (!product) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [product, onClose]);

  if (!product) return null;

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 md:p-8 bg-slate-950/85 backdrop-blur-md overflow-y-auto overscroll-contain animate-in fade-in duration-150"
    >
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl shadow-2xl my-auto flex flex-col max-h-[calc(100vh-1.5rem)] sm:max-h-[calc(100vh-3rem)] overflow-hidden">
        
        {/* Sticky/Fixed Modal Header with Close Button */}
        <div className="p-4 sm:p-6 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 flex items-center justify-between gap-4 z-20 shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Уровень {product.number}
            </span>
            {product.badge && (
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                {product.badge}
              </span>
            )}
          </div>

          {/* Close Button - Always visible and clickable */}
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 cursor-pointer transition-colors shrink-0"
            title="Закрыть (Esc)"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-5 sm:p-8 space-y-6 sm:space-y-8 flex-1">
          <div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white mb-2 leading-tight">
              {product.title}
            </h2>
            <p className="text-sm sm:text-base font-medium text-slate-300">
              {product.subtitle}
            </p>
          </div>

          {/* Description card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed">
            {product.description}
          </div>

          {/* Use Case & Audience */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-slate-500 block uppercase mb-1">Когда использовать:</span>
              <span className="text-slate-200 font-sans text-xs sm:text-sm">{product.whenToUse}</span>
            </div>
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-slate-500 block uppercase mb-1">Кому подходит:</span>
              <span className="text-slate-200 font-sans text-xs sm:text-sm">{product.whoIsItFor}</span>
            </div>
          </div>

          {/* Full Feature Checklist */}
          <div>
            <h3 className="text-xs sm:text-sm font-mono uppercase text-slate-400 tracking-wider mb-4">
              Полный перечень возможностей модуля:
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
              {product.features.map((feat, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-200 p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/60">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Price Options & Actions */}
          <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-blue-950/50 to-slate-950 border border-blue-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 sm:gap-6">
            <div>
              <span className="text-xs text-slate-400 font-mono block">Бессрочная лицензия:</span>
              <div className="flex items-baseline gap-2 sm:gap-3">
                <span className="text-2xl sm:text-3xl font-black text-white">
                  {currentMarketplace === 'wildberries'
                    ? `${product.price.wb.toLocaleString('ru-RU')} ₽`
                    : currentMarketplace === 'ozon'
                    ? `${product.price.ozon.toLocaleString('ru-RU')} ₽`
                    : `${product.price.wb.toLocaleString('ru-RU')} ₽`}
                </span>
                <span className="text-xs text-slate-400 font-mono">без подписки</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <button
                onClick={() => {
                  onClose();
                  onOpenDemo();
                }}
                className="flex-1 sm:flex-initial px-4 py-2.5 sm:px-5 sm:py-3 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 font-semibold text-xs border border-slate-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>Демо</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenBuy(product.id);
                }}
                className="flex-1 sm:flex-initial px-5 py-2.5 sm:px-6 sm:py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Купить модуль</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
