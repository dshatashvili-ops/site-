import { Percent, Truck, Warehouse, Megaphone, CreditCard, FileText, DollarSign, Layers } from 'lucide-react';

export function ExpensesBreakdown() {
  const expenses = [
    { icon: <Percent className="w-5 h-5 text-purple-400" />, title: 'Комиссия', desc: 'Процент категории маркетплейса (10-45%)' },
    { icon: <Truck className="w-5 h-5 text-blue-400" />, title: 'Логистика', desc: 'Доставка клиенту, кС, обратная логистика' },
    { icon: <Warehouse className="w-5 h-5 text-amber-400" />, title: 'Хранение', desc: 'Стоимость размещения на складах FBO/FBW' },
    { icon: <Megaphone className="w-5 h-5 text-rose-400" />, title: 'Реклама', desc: 'Затраты на ДРР, АРК и внутреннее продвижение' },
    { icon: <CreditCard className="w-5 h-5 text-cyan-400" />, title: 'Эквайринг', desc: 'Прием платежей и финансовые удержания' },
    { icon: <FileText className="w-5 h-5 text-emerald-400" />, title: 'Налоги', desc: 'УСН (Доходы / Доходы минус расходы) / ОСНО' },
  ];

  return (
    <section className="py-24 bg-slate-950/80 border-t border-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider">
            <span>Прозрачная анатомия цены</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
            PROFIT SYSTEM учитывает все расходы
          </h2>
          <p className="text-base sm:text-lg text-slate-300">
            Никаких скрытых списаний и непредвиденных убытков. Каждый рубль в цене распределяется под ваш полный контроль.
          </p>
        </div>

        {/* Visual Diagram Structure */}
        <div className="max-w-4xl mx-auto">
          
          {/* Top Price Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-center font-bold text-xl sm:text-2xl shadow-xl shadow-blue-600/20 max-w-md mx-auto mb-8 border border-blue-400/30">
            <span>ЦЕНА ТОВАРА КЛИЕНТУ</span>
          </div>

          {/* Downward Connector Arrow */}
          <div className="w-0.5 h-8 bg-gradient-to-b from-blue-500 to-slate-800 mx-auto mb-8" />

          {/* Expenses Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
            {expenses.map((exp, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-colors"
              >
                <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center mb-3">
                  {exp.icon}
                </div>
                <h4 className="font-bold text-white text-base mb-1">{exp.title}</h4>
                <p className="text-xs text-slate-400 leading-snug">{exp.desc}</p>
              </div>
            ))}
          </div>

          {/* Downward Connector Arrow */}
          <div className="w-0.5 h-8 bg-gradient-to-b from-slate-800 to-emerald-500 mx-auto mb-8" />

          {/* Bottom Net Profit Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-emerald-900/60 to-slate-950 border border-emerald-500/50 text-center max-w-md mx-auto shadow-2xl shadow-emerald-950/50">
            <span className="text-xs font-mono uppercase tracking-wider text-emerald-400 block mb-1">
              Конечный результат:
            </span>
            <span className="text-2xl sm:text-3xl font-black text-white">
              ЧИСТАЯ ПРИБЫЛЬ И МАРЖА
            </span>
          </div>

        </div>

      </div>
    </section>
  );
}
