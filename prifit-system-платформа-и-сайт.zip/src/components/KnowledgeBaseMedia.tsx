import { Youtube, Send, BookOpen, Play, ExternalLink } from 'lucide-react';
import { ARTICLES, VIDEOS } from '../data/content';
import { AnimatedSection, StaggerContainer, StaggerItem } from './AnimatedSection';

export function KnowledgeBaseMedia() {
  return (
    <section id="media" className="py-24 bg-slate-50 dark:bg-slate-950 relative border-t border-slate-200 dark:border-slate-900 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-600 dark:text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider">
            <span>Обучение и медиа</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-4">
            База знаний PROFIT SYSTEM
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300">
            Видео-уроки, разборы кейсов unit-экономики и регулярные обновления в нашем экспертном сообществе.
          </p>
        </AnimatedSection>

        {/* Telegram & YouTube Banner Grid */}
        <StaggerContainer staggerDelay={0.15} className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16 max-w-5xl mx-auto">
          
          {/* Telegram Banner */}
          <StaggerItem>
            <div className="p-8 rounded-3xl bg-sky-50/80 dark:bg-gradient-to-br dark:from-sky-950/60 dark:to-slate-900 border border-sky-200 dark:border-sky-500/30 flex flex-col justify-between shadow-lg dark:shadow-xl h-full">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-sky-500/20 text-sky-600 dark:text-sky-400 flex items-center justify-center mb-6 border border-sky-500/30">
                  <Send className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">PROFIT SYSTEM в Telegram</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-6 leading-relaxed">
                  Оперативные разборы изменений комиссий WB и Ozon, советы по управлению маржой, анонсы новых версий и шаблонов.
                </p>
              </div>
              <a
                href="https://t.me"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white dark:text-slate-950 font-bold text-sm transition-all shadow-lg shadow-sky-500/20"
              >
                <span>Подписаться на Telegram-канал</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </StaggerItem>

          {/* YouTube Banner */}
          <StaggerItem>
            <div className="p-8 rounded-3xl bg-red-50/80 dark:bg-gradient-to-br dark:from-red-950/60 dark:to-slate-900 border border-red-200 dark:border-red-500/30 flex flex-col justify-between shadow-lg dark:shadow-xl h-full">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-red-500/20 text-red-600 dark:text-red-400 flex items-center justify-center mb-6 border border-red-500/30">
                  <Youtube className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Видео-инструкции на YouTube</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-6 leading-relaxed">
                  Подробные видеоразборы использования модулей «Расчёт», «Анализ», «Акции» и «Точка безубыточности» с примерами.
                </p>
              </div>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm transition-all shadow-lg shadow-red-600/20"
              >
                <span>Смотреть уроки на YouTube</span>
                <Play className="w-4 h-4 fill-current" />
              </a>
            </div>
          </StaggerItem>

        </StaggerContainer>

        {/* Video Tutorial Cards */}
        <div className="mb-16">
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
            <Play className="w-5 h-5 text-red-500" />
            <span>Популярные видео-уроки</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {VIDEOS.map((vid) => (
              <div
                key={vid.id}
                className="p-6 rounded-2xl bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-all group cursor-pointer shadow-xs"
              >
                <div className="aspect-video rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 mb-4 relative overflow-hidden flex items-center justify-center group-hover:border-red-500/50 transition-colors">
                  <div className="w-12 h-12 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </div>
                  <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-slate-900/80 text-[10px] font-mono text-white">
                    {vid.duration}
                  </span>
                </div>
                <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-300 transition-colors line-clamp-2">
                  {vid.title}
                </h4>
                <div className="flex items-center justify-between text-xs text-slate-500 font-mono">
                  <span>{vid.views} просмотров</span>
                  <span className="text-red-500 font-medium">Смотреть &rarr;</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Blog Guides List */}
        <div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <span>Статьи и гайды по unit-экономике</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {ARTICLES.map((art) => (
              <div
                key={art.id}
                className="p-6 rounded-2xl bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-all shadow-xs"
              >
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono mb-3">
                  <span className="px-2.5 py-0.5 rounded bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400 border border-blue-200 dark:border-blue-500/20">
                    {art.category}
                  </span>
                  <span>{art.readTime} чтения</span>
                </div>
                <h4 className="font-bold text-slate-900 dark:text-white text-base mb-2 hover:text-blue-600 dark:hover:text-blue-300 transition-colors cursor-pointer">
                  {art.title}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4 line-clamp-3">
                  {art.summary}
                </p>
                <div className="text-xs text-slate-400 font-mono">
                  {art.date}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
