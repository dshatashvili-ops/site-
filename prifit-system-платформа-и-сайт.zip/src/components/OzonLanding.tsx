import { ArrowLeft, CheckCircle2, Download } from 'lucide-react';
import { PRODUCT_LEVELS, SITE_BRAND } from '../data/content';
import { Logo } from './Logo';

interface OzonLandingProps {
  onBack: () => void;
  onOpenBuy: (productId?: string) => void;
  onOpenDemo: () => void;
}

export function OzonLanding({ onBack, onOpenBuy, onOpenDemo }: OzonLandingProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans">
      
      {/* Top Navigation */}
      <div className="border-b border-blue-900/50 bg-slate-950/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo variant="icon" className="w-8 h-8" />
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-xs font-mono text-blue-300 hover:text-white transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>&larr; На главную PROFIT SYSTEM</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
            <span className="text-xs font-mono font-bold text-blue-300 uppercase">OZON SPECIAL</span>
          </div>
        </div>
      </div>

      {/* Ozon Hero */}
      <section className="py-16 sm:py-24 relative overflow-hidden bg-gradient-to-b from-blue-950/40 via-slate-950 to-slate-950">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center">
          
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-mono mb-6">
            <span>Модули расчёта для Ozon</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-tight mb-6">
            Unit-экономика <br />
            <span className="bg-gradient-to-r from-blue-400 via-sky-300 to-cyan-400 bg-clip-text text-transparent">
              Ozon под полным контролем
            </span>
          </h1>

          <p className="text-base sm:text-xl text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed">
            Расчёт комиссии Ozon, расходов на магистраль и последнюю милю, эквайринга, акций Ozon и точки безубыточности бизнеса.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => onOpenBuy()}
              className="px-8 py-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-xl shadow-blue-600/30 transition-all cursor-pointer"
            >
              Выбрать продукт Ozon
            </button>
            <button
              onClick={onOpenDemo}
              className="px-6 py-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold text-sm border border-slate-800 flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Скачать Демо Ozon</span>
            </button>
          </div>

        </div>
      </section>

      {/* Ozon Specific Product Levels Grid */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white text-center mb-12">
          4 Уровня инструментов для селлеров Ozon
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {PRODUCT_LEVELS.map((level) => (
            <div
              key={level.id}
              className="p-8 rounded-3xl bg-slate-900/80 border border-blue-900/40 hover:border-blue-500/60 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-blue-500/10 text-blue-300 border border-blue-500/20">
                    OZON {level.number}
                  </span>
                  <span className="text-xl font-bold text-white font-mono">
                    {level.price.ozon.toLocaleString('ru-RU')} ₽
                  </span>
                </div>

                <h3 className="text-2xl font-bold text-white mb-2">{level.title}</h3>
                <p className="text-xs text-slate-300 mb-6">{level.subtitle}</p>

                <div className="space-y-2 mb-8">
                  {level.features.map((f, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => onOpenBuy(level.id)}
                className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-lg shadow-blue-600/20"
              >
                Купить модуль для Ozon
              </button>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
