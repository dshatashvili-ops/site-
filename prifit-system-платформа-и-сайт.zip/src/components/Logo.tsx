import React from 'react';
import { useTheme } from '../context/ThemeContext';

interface LogoProps {
  className?: string;
  variant?: 'icon' | 'full';
}

export function Logo({ className = 'h-10', variant = 'icon' }: LogoProps) {
  const { isDark } = useTheme();

  // Unique Gradient IDs to avoid SVG ID collisions across instances
  const ribbonGradId = isDark ? 'ps-ribbon-grad-dark' : 'ps-ribbon-grad-light';
  const bevelGradId = isDark ? 'ps-bevel-dark' : 'ps-bevel-light';

  if (variant === 'full') {
    return (
      <svg
        viewBox="0 0 420 120"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
        aria-label="PROFIT SYSTEM"
      >
        <defs>
          {isDark ? (
            <>
              <linearGradient id={ribbonGradId} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="40%" stopColor="#2563eb" />
                <stop offset="80%" stopColor="#1d4ed8" />
                <stop offset="100%" stopColor="#1e40af" />
              </linearGradient>
              <linearGradient id={bevelGradId} x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.65" />
                <stop offset="50%" stopColor="#ffffff" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0.35" />
              </linearGradient>
            </>
          ) : (
            <>
              <linearGradient id={ribbonGradId} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0284c7" />
                <stop offset="50%" stopColor="#2563eb" />
                <stop offset="100%" stopColor="#1e40af" />
              </linearGradient>
              <linearGradient id={bevelGradId} x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0.25" />
              </linearGradient>
            </>
          )}
        </defs>
        <g transform="translate(10, 10) scale(0.833)">
          <path
            d="M 28 28 L 78 28 A 16 16 0 0 1 78 60 L 42 60 A 16 16 0 0 0 42 92 L 82 92"
            fill="none"
            stroke={`url(#${ribbonGradId})`}
            strokeWidth="16"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M 28 28 L 78 28 A 16 16 0 0 1 78 60 L 42 60 A 16 16 0 0 0 42 92 L 82 92"
            fill="none"
            stroke={`url(#${bevelGradId})`}
            strokeWidth="16"
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity="0.8"
          />
        </g>
        <line
          x1="125"
          y1="35"
          x2="125"
          y2="85"
          stroke={isDark ? '#334155' : '#CBD5E1'}
          strokeWidth="1"
        />
        <text
          x="145"
          y="64"
          fill={isDark ? '#FFFFFF' : '#0F172A'}
          fontSize="25"
          fontWeight="800"
          letterSpacing="8"
          fontFamily="sans-serif"
        >
          PROFIT
        </text>
        <text
          x="145"
          y="86"
          fill={isDark ? '#94A3B8' : '#475569'}
          fontSize="21"
          fontWeight="400"
          letterSpacing="12"
          fontFamily="sans-serif"
        >
          SYSTEM
        </text>
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 120 120"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="PROFIT SYSTEM Icon"
    >
      <defs>
        {isDark ? (
          <>
            <linearGradient id={ribbonGradId} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="40%" stopColor="#2563eb" />
              <stop offset="80%" stopColor="#1d4ed8" />
              <stop offset="100%" stopColor="#1e40af" />
            </linearGradient>
            <linearGradient id={bevelGradId} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.65" />
              <stop offset="50%" stopColor="#ffffff" stopOpacity="0.1" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0.35" />
            </linearGradient>
          </>
        ) : (
          <>
            <linearGradient id={ribbonGradId} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0284c7" />
              <stop offset="50%" stopColor="#2563eb" />
              <stop offset="100%" stopColor="#1e40af" />
            </linearGradient>
            <linearGradient id={bevelGradId} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0.25" />
            </linearGradient>
          </>
        )}
      </defs>
      <g transform="translate(10, 10) scale(0.833)">
        <path
          d="M 28 28 L 78 28 A 16 16 0 0 1 78 60 L 42 60 A 16 16 0 0 0 42 92 L 82 92"
          fill="none"
          stroke={`url(#${ribbonGradId})`}
          strokeWidth="16"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 28 28 L 78 28 A 16 16 0 0 1 78 60 L 42 60 A 16 16 0 0 0 42 92 L 82 92"
          fill="none"
          stroke={`url(#${bevelGradId})`}
          strokeWidth="16"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.8"
        />
      </g>
    </svg>
  );
}
