import { useState } from 'react';
import { Activity, ChevronDown, Menu, X, Sparkles, Download, ArrowRight, Sun, Moon, Sliders } from 'lucide-react';
import { SITE_BRAND, PRODUCT_LEVELS } from '../data/content';
import { Marketplace } from '../types';
import { useTheme } from '../context/ThemeContext';
import { Logo } from './Logo';

interface HeaderProps {
  currentMarketplace: Marketplace;
  onSelectMarketplace: (m: Marketplace) => void;
  onOpenQuiz: () => void;
  onOpenDemo: () => void;
  onOpenBuy: (productId?: string) => void;
  onNavigateToSection: (sectionId: string) => void;
  onOpenTbCalculator: () => void;
}

export function Header({
  currentMarketplace,
  onSelectMarketplace,
  onOpenQuiz,
  onOpenDemo,
  onOpenBuy,
  onNavigateToSection,
  onOpenTbCalculator,
}: HeaderProps) {
  const { theme, toggleTheme, isDark } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [productsDropdownOpen, setProductsDropdownOpen] = useState(false);
  const [marketplaceDropdownOpen, setMarketplaceDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between">
        
        {/* Brand Logo */}
        <div
          className="flex items-center cursor-pointer group"
          onClick={() => {
            onSelectMarketplace('all');
            onNavigateToSection('hero');
          }}
        >
          <Logo variant="full" className="h-10 sm:h-11 w-auto group-hover:scale-105 transition-transform" />
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1 text-sm font-medium text-slate-700 dark:text-slate-300">
          
          {/* Marketplace Dropdown */}
          <div className="relative group" onMouseLeave={() => setMarketplaceDropdownOpen(false)}>
            <button
              onClick={() => setMarketplaceDropdownOpen(!marketplaceDropdownOpen)}
              onMouseEnter={() => setMarketplaceDropdownOpen(true)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${
                currentMarketplace !== 'all' ? 'text-blue-600 dark:text-blue-400 font-semibold' : ''
              }`}
            >
              <span>Маркетплейсы</span>
              <ChevronDown className="w-4 h-4 opacity-70 group-hover:rotate-180 transition-transform" />
            </button>

            {marketplaceDropdownOpen && (
              <div
                className="absolute top-full left-0 w-64 pt-2 z-50"
                onMouseEnter={() => setMarketplaceDropdownOpen(true)}
              >
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-2 shadow-2xl backdrop-blur-xl">
                  <button
                    onClick={() => {
                      onSelectMarketplace('all');
                      setMarketplaceDropdownOpen(false);
                      onNavigateToSection('marketplaces');
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center gap-2.5 hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors ${
                      currentMarketplace === 'all' ? 'bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400 font-semibold' : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="w-6 h-6 rounded bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-700 dark:text-slate-300">ALL</div>
                    <div>
                      <div className="text-sm font-medium text-slate-900 dark:text-white">Все решения</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">WB + Ozon</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      onSelectMarketplace('wildberries');
                      setMarketplaceDropdownOpen(false);
                      onNavigateToSection('marketplaces');
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center gap-2.5 hover:bg-purple-50 dark:hover:bg-purple-950/40 transition-colors ${
                      currentMarketplace === 'wildberries' ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 font-semibold' : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="w-6 h-6 rounded bg-purple-600 flex items-center justify-center text-xs font-bold text-white">WB</div>
                    <div>
                      <div className="text-sm font-medium text-purple-700 dark:text-purple-300">Wildberries</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">Unit-экономика WB</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      onSelectMarketplace('ozon');
                      setMarketplaceDropdownOpen(false);
                      onNavigateToSection('marketplaces');
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center gap-2.5 hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors ${
                      currentMarketplace === 'ozon' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 font-semibold' : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center text-xs font-bold text-white">OZ</div>
                    <div>
                      <div className="text-sm font-medium text-blue-700 dark:text-blue-300">Ozon</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">Unit-экономика Ozon</div>
                    </div>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Products Dropdown */}
          <div className="relative group" onMouseLeave={() => setProductsDropdownOpen(false)}>
            <button
              onClick={() => setProductsDropdownOpen(!productsDropdownOpen)}
              onMouseEnter={() => setProductsDropdownOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              <span>Продукты</span>
              <ChevronDown className="w-4 h-4 opacity-70 group-hover:rotate-180 transition-transform" />
            </button>

            {productsDropdownOpen && (
              <div
                className="absolute top-full left-0 w-80 pt-2 z-50"
                onMouseEnter={() => setProductsDropdownOpen(true)}
              >
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-2 shadow-2xl backdrop-blur-xl">
                  {PRODUCT_LEVELS.map((level) => (
                    <button
                      key={level.id}
                      onClick={() => {
                        setProductsDropdownOpen(false);
                        onNavigateToSection('products');
                      }}
                      className="w-full text-left p-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors flex items-start gap-3 group/item"
                    >
                      <span className="text-xs font-mono font-bold px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 mt-0.5">
                        {level.number}
                      </span>
                      <div>
                        <div className="text-sm font-semibold text-slate-900 dark:text-white group-hover/item:text-blue-600 dark:group-hover/item:text-blue-400 transition-colors">
                          {level.title}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">{level.subtitle}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <button
            onClick={() => onNavigateToSection('simulator')}
            className="px-3 py-2 rounded-lg hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5 text-blue-500" />
            <span>Симулятор</span>
          </button>

          <button
            onClick={() => onNavigateToSection('comparison')}
            className="px-3 py-2 rounded-lg hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            Сравнение
          </button>

          <button
            onClick={onOpenDemo}
            className="px-3 py-2 rounded-lg text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 flex items-center gap-1 transition-colors cursor-pointer font-medium"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Демо</span>
          </button>

          <button
            onClick={() => onNavigateToSection('media')}
            className="px-3 py-2 rounded-lg hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            База знаний
          </button>

          <button
            onClick={() => onNavigateToSection('faq')}
            className="px-3 py-2 rounded-lg hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            FAQ
          </button>
        </nav>

        {/* Right Actions */}
        <div className="hidden sm:flex items-center gap-3">
          
          {/* Theme Switcher Toggle */}
          <button
            onClick={toggleTheme}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-800 transition-all flex items-center gap-2 cursor-pointer shadow-xs"
            title={isDark ? 'Переключить на светлую тему' : 'Переключить на тёмную тему'}
          >
            {isDark ? (
              <>
                <Sun className="w-4 h-4 text-amber-400" />
                <span className="hidden xl:inline">Светлая</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-indigo-600" />
                <span className="hidden xl:inline">Тёмная</span>
              </>
            )}
          </button>

          <button
            onClick={onOpenTbCalculator}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all flex items-center gap-1.5 cursor-pointer relative group"
            title="Запустить Веб-расчёт Точки Безубыточности онлайн"
          >
            <Activity className="w-3.5 h-3.5 text-slate-950" />
            <span>Веб-ТБ</span>
            <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-slate-950 text-amber-400 font-black">
              24H
            </span>
          </button>

          <button
            onClick={onOpenQuiz}
            className="px-3.5 py-2 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-800 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <span>Подбор</span>
          </button>

          <button
            onClick={() => onOpenBuy()}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-xs transition-all shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30 border border-blue-400/30 flex items-center gap-1.5 cursor-pointer"
          >
            <span>Выбрать продукт</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile menu button */}
        <div className="flex lg:hidden items-center gap-2">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-800 text-slate-700 dark:text-slate-300"
            title="Сменить тему"
          >
            {isDark ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-indigo-600" />}
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-700 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white focus:outline-none"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-6 py-6 space-y-4 max-h-[calc(100vh-5rem)] overflow-y-auto shadow-2xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <span className="text-xs font-mono font-semibold text-slate-500 dark:text-slate-400">Тема сайта:</span>
            <button
              onClick={toggleTheme}
              className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-800 flex items-center gap-1.5"
            >
              {isDark ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span>Светлая тема</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-indigo-600" />
                  <span>Тёмная тема</span>
                </>
              )}
            </button>
          </div>
          <div className="space-y-2">
            <p className="text-xs font-mono text-slate-500 uppercase tracking-wider">Маркетплейсы</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onSelectMarketplace('wildberries');
                  setMobileMenuOpen(false);
                  onNavigateToSection('marketplaces');
                }}
                className="p-3 rounded-lg bg-purple-950/30 border border-purple-800/40 text-purple-300 text-xs font-medium text-left"
              >
                🟣 Wildberries
              </button>
              <button
                onClick={() => {
                  onSelectMarketplace('ozon');
                  setMobileMenuOpen(false);
                  onNavigateToSection('marketplaces');
                }}
                className="p-3 rounded-lg bg-blue-950/30 border border-blue-800/40 text-blue-300 text-xs font-medium text-left"
              >
                🔵 Ozon
              </button>
            </div>
          </div>

          <div className="pt-2 space-y-2">
            <p className="text-xs font-mono text-slate-500 uppercase tracking-wider">Навигация</p>
            <button
              onClick={() => { onNavigateToSection('products'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 text-sm text-slate-700 dark:text-slate-300 font-medium"
            >
              Продукты (4 уровня)
            </button>
            <button
              onClick={() => { onNavigateToSection('simulator'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 text-sm text-slate-700 dark:text-slate-300 font-medium flex items-center gap-2"
            >
              <Sliders className="w-4 h-4 text-blue-500" />
              <span>Демонстрационная модель (Симулятор)</span>
            </button>
            <button
              onClick={() => { onNavigateToSection('comparison'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 text-sm text-slate-700 dark:text-slate-300 font-medium"
            >
              Сравнение версий
            </button>
            <button
              onClick={() => { onOpenDemo(); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 text-sm text-emerald-600 dark:text-emerald-400 font-semibold"
            >
              Скачать демо-версию
            </button>
            <button
              onClick={() => { onNavigateToSection('media'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 text-sm text-slate-700 dark:text-slate-300 font-medium"
            >
              База знаний
            </button>
            <button
              onClick={() => { onNavigateToSection('faq'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 text-sm text-slate-700 dark:text-slate-300 font-medium"
            >
              Частые вопросы (FAQ)
            </button>
          </div>

          <div className="pt-4 border-t border-slate-900 space-y-2">
            <button
              onClick={() => { onOpenTbCalculator(); setMobileMenuOpen(false); }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 text-sm font-bold shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
            >
              <Activity className="w-4 h-4 text-slate-950" />
              <span>Запустить Веб-калькулятор ТБ (Промо 24ч)</span>
            </button>
            <button
              onClick={() => { onOpenQuiz(); setMobileMenuOpen(false); }}
              className="w-full py-3 rounded-xl bg-slate-900 text-slate-200 text-sm font-medium border border-slate-800 flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-blue-400" />
              <span>Помочь выбрать продукт</span>
            </button>
            <button
              onClick={() => { onOpenBuy(); setMobileMenuOpen(false); }}
              className="w-full py-3 rounded-xl bg-blue-600 text-white text-sm font-semibold shadow-lg shadow-blue-500/20"
            >
              Выбрать продукт / Купить
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
