import { CheckCircle2, ArrowRight, BarChart3, Calculator, Eye, Tag, PieChart } from 'lucide-react';
import { PRODUCT_LEVELS } from '../data/content';
import { ProductLevel, Marketplace } from '../types';
import { AnimatedSection, StaggerContainer, StaggerItem } from './AnimatedSection';

interface ProductLevelsProps {
  currentMarketplace: Marketplace;
  onSelectProduct: (product: ProductLevel) => void;
  onOpenBuy: (productId: string) => void;
  onOpenTbCalculator?: () => void;
}

export function ProductLevels({ currentMarketplace, onSelectProduct, onOpenBuy, onOpenTbCalculator }: ProductLevelsProps) {
  
  const getIconForLevel = (id: string) => {
    switch (id) {
      case 'calc':
        return <Calculator className="w-6 h-6 text-blue-400" />;
      case 'analysis':
        return <Eye className="w-6 h-6 text-cyan-400" />;
      case 'promo':
        return <Tag className="w-6 h-6 text-purple-400" />;
      case 'tb':
        return <PieChart className="w-6 h-6 text-emerald-400" />;
      default:
        return <BarChart3 className="w-6 h-6 text-blue-400" />;
    }
  };

  return (
    <section id="products" className="py-24 relative bg-slate-50 dark:bg-slate-950 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Title */}
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-blue-700 dark:text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider shadow-xs">
            <span>Продуктовая лестница</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-4">
            Четыре уровня PROFIT SYSTEM
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300">
            Выберите уровень задачи. Каждый следующий уровень полностью расширяет функционал предыдущего.
          </p>
        </AnimatedSection>

        {/* 4 Product Cards Grid */}
        <StaggerContainer staggerDelay={0.1} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {PRODUCT_LEVELS.map((level) => (
            <StaggerItem key={level.id}>
              <div
                className={`group relative rounded-2xl p-6 bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 hover:border-blue-500 transition-all flex flex-col justify-between hover:-translate-y-1 shadow-md hover:shadow-xl h-full ${level.glow}`}
              >
              {/* Badge if available */}
              {level.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-extrabold text-[10px] tracking-wider uppercase shadow-md">
                  {level.badge}
                </div>
              )}

              <div>
                {/* Header Number & Icon */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-center">
                    {getIconForLevel(level.id)}
                  </div>
                  <span className="font-mono text-2xl font-black text-slate-400 dark:text-slate-600 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {level.number}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-300 transition-colors">
                  {level.title}
                </h3>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
                  {level.subtitle}
                </p>

                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed mb-6 bg-slate-100/80 dark:bg-slate-950/60 p-3 rounded-xl border border-slate-200 dark:border-slate-800/80">
                  {level.tagline}
                </p>

                {/* Who is it for */}
                <div className="mb-6">
                  <span className="text-[10px] font-mono uppercase text-slate-400 dark:text-slate-500 tracking-wider block mb-1">
                    Кому подходит:
                  </span>
                  <span className="text-xs text-slate-800 dark:text-slate-300 font-medium bg-slate-100 dark:bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-800 inline-block">
                    {level.whoIsItFor}
                  </span>
                </div>

                {/* Key Features bullet list */}
                <div className="space-y-2 mb-8">
                  <span className="text-[10px] font-mono uppercase text-slate-400 dark:text-slate-500 tracking-wider block mb-1">
                    Возможности:
                  </span>
                  {level.features.slice(0, 5).map((feat, fIdx) => (
                    <div key={fIdx} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                      <span className="line-clamp-1">{feat}</span>
                    </div>
                  ))}
                  {level.features.length > 5 && (
                    <p className="text-[11px] text-blue-600 dark:text-blue-400 font-mono mt-1">+ ещё {level.features.length - 5} функций в полной версии</p>
                  )}
                </div>
              </div>

              {/* Price & CTA */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800/80 mt-auto">
                <div className="flex items-baseline justify-between mb-4">
                  <div>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-mono">Стоимость:</span>
                    <span className="text-xl font-extrabold font-mono text-slate-900 dark:text-white">
                      {currentMarketplace === 'wildberries'
                        ? `${level.price.wb.toLocaleString('ru-RU')} ₽`
                        : currentMarketplace === 'ozon'
                        ? `${level.price.ozon.toLocaleString('ru-RU')} ₽`
                        : `${level.price.wb.toLocaleString('ru-RU')} ₽`}
                    </span>
                  </div>
                  {level.price.bundle && (
                    <span className="text-[10px] font-mono text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/60 px-2 py-0.5 rounded">
                      Комплект WB+Ozon
                    </span>
                  )}
                </div>

                {level.id === 'tb' && onOpenTbCalculator && (
                  <button
                    onClick={onOpenTbCalculator}
                    className="w-full mb-2 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>⚡ Запустить Веб-ТБ (24ч)</span>
                  </button>
                )}

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => onSelectProduct(level)}
                    className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-950 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-300 font-medium text-xs border border-slate-300 dark:border-slate-800 transition-colors cursor-pointer"
                  >
                    Подробнее
                  </button>
                  <button
                    onClick={() => onOpenBuy(level.id)}
                    className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors shadow-lg shadow-blue-600/20 cursor-pointer"
                  >
                    Купить
                  </button>
                </div>
              </div>
            </div>
          </StaggerItem>
        ))}
      </StaggerContainer>

        {/* Step progression line description */}
        <div className="mt-16 p-6 rounded-2xl bg-gradient-to-r from-blue-50 via-indigo-50 to-white dark:from-blue-950/40 dark:via-indigo-950/40 dark:to-slate-950 border border-blue-200 dark:border-slate-800 text-center max-w-4xl mx-auto shadow-xs">
          <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 font-medium">
            <span className="text-blue-600 dark:text-blue-400 font-bold">Продуктовая лестница:</span> От расчёта цены конкретного товара — к полному финансовому управлению бизнесом на маркетплейсах.
          </p>
        </div>

      </div>
    </section>
  );
}
