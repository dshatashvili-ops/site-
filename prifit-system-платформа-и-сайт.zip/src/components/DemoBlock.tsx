import { Download, CheckCircle2, FileSpreadsheet } from 'lucide-react';
import { AnimatedSection } from './AnimatedSection';

interface DemoBlockProps {
  onOpenDemo: () => void;
  onOpenTbCalculator?: () => void;
}

export function DemoBlock({ onOpenDemo, onOpenTbCalculator }: DemoBlockProps) {
  return (
    <section className="py-20 bg-slate-50 dark:bg-slate-950 relative border-t border-slate-200 dark:border-slate-900 transition-colors overflow-hidden">
      {/* Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-blue-600/10 blur-3xl rounded-full pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 relative z-10">
        <AnimatedSection className="p-8 sm:p-12 rounded-3xl bg-slate-100 dark:bg-slate-900 bg-gradient-to-r from-blue-50/80 via-slate-50 to-blue-50/80 dark:from-slate-900 dark:via-blue-950/40 dark:to-slate-900 border border-slate-200 dark:border-blue-500/30 text-center shadow-xl dark:shadow-2xl">
          
          <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-6 border border-blue-200 dark:border-blue-500/30">
            <FileSpreadsheet className="w-8 h-8" />
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-4">
            Попробуйте PROFIT SYSTEM бесплатно
          </h2>

          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto mb-8">
            Загрузите демо-версию, чтобы лично оценить скорость автоматического подбора цены, формулу чистой прибыли и удобство интерфейса.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto mb-8 text-xs font-mono text-slate-700 dark:text-slate-300">
            <div className="p-3 rounded-xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>3 реальных товара в демо</span>
            </div>
            <div className="p-3 rounded-xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>Фиксированные настройки</span>
            </div>
            <div className="p-3 rounded-xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>Полная демонстрация логики</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onOpenDemo}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-base shadow-xl shadow-emerald-500/20 transition-all inline-flex items-center justify-center gap-3 cursor-pointer hover:scale-105"
            >
              <Download className="w-5 h-5" />
              <span>Скачать демо Excel бесплатно</span>
            </button>

            {onOpenTbCalculator && (
              <button
                onClick={onOpenTbCalculator}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-base shadow-xl shadow-amber-500/20 transition-all inline-flex items-center justify-center gap-2 cursor-pointer hover:scale-105"
              >
                <span>⚡ Запустить Веб-ТБ онлайн (Промо 24ч)</span>
              </button>
            )}
          </div>

          <p className="text-xs text-slate-500 font-mono mt-4">
            Мгновенное скачивание файла .XLSX &bull; Совместимо с Windows и Mac Excel
          </p>

        </AnimatedSection>
      </div>
    </section>
  );
}
