import { useState } from 'react';
import { ArrowRight, ShieldCheck, Zap, Download, FileSpreadsheet, RefreshCw, CheckCircle2 } from 'lucide-react';
import { SITE_BRAND } from '../data/content';
import { AnimatedSection, StaggerContainer, StaggerItem } from './AnimatedSection';

interface HeroProps {
  onOpenDemo: () => void;
  onOpenBuy: () => void;
  onNavigateToProducts: () => void;
  onOpenTbCalculator: () => void;
}

export function Hero({ onOpenDemo, onOpenBuy, onOpenTbCalculator }: HeroProps) {
  const [activeTab, setActiveTab] = useState<'wb' | 'ozon'>('wb');

  return (
    <section id="hero" className="relative pt-10 pb-20 md:pt-14 md:pb-28 overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-gradient-to-b from-blue-600/15 via-indigo-600/10 to-transparent blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 -right-40 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -left-40 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Tagline Badge */}
        <AnimatedSection direction="down" duration={0.4} className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-blue-700 dark:text-blue-300 text-xs sm:text-sm font-medium backdrop-blur-md shadow-xs">
            <span className="w-2 h-2 rounded-full bg-blue-500 dark:bg-blue-400 animate-pulse" />
            <span>Система расчёта и управления экономикой на маркетплейсах</span>
          </div>
        </AnimatedSection>

        {/* Main Headings */}
        <AnimatedSection delay={0.1} className="text-center max-w-4xl mx-auto mb-8">
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black text-slate-900 dark:text-white tracking-tight leading-[1.08] mb-6 font-sans">
            Не угадывайте. <br />
            <span className="bg-gradient-to-r from-blue-600 via-sky-500 to-indigo-600 dark:from-blue-400 dark:via-sky-300 dark:to-indigo-400 bg-clip-text text-transparent drop-shadow-sm">
              Рассчитывайте.
            </span>
          </h1>
          <p className="text-base sm:text-xl text-slate-600 dark:text-slate-300 leading-relaxed font-normal max-w-3xl mx-auto">
            {SITE_BRAND.description}
          </p>
        </AnimatedSection>

        {/* CTA Buttons */}
        <AnimatedSection delay={0.2} className="flex flex-col sm:flex-row flex-wrap items-center justify-center gap-4 mb-10">
          <button
            onClick={onOpenBuy}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-base shadow-xl shadow-blue-600/25 border border-blue-400/40 flex items-center justify-center gap-3 group transition-all cursor-pointer hover:scale-[1.02]"
          >
            <span>Выбрать инструмент</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={onOpenTbCalculator}
            className="w-full sm:w-auto px-7 py-4 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-base shadow-xl shadow-amber-500/20 border border-amber-400/50 flex items-center justify-center gap-2 transition-all cursor-pointer hover:scale-[1.02]"
          >
            <Zap className="w-5 h-5 fill-current text-slate-950" />
            <span>Веб-калькулятор ТБ онлайн</span>
            <span className="text-xs px-2 py-0.5 rounded bg-slate-950 text-amber-400 font-mono font-bold">24H</span>
          </button>

          <button
            onClick={onOpenDemo}
            className="w-full sm:w-auto px-7 py-4 rounded-xl bg-white dark:bg-slate-900/90 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 font-semibold text-base border border-slate-300 dark:border-slate-800 flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
          >
            <Download className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <span>Демо-версия</span>
          </button>
        </AnimatedSection>

        {/* Key Features Badges Row */}
        <StaggerContainer staggerDelay={0.08} className="flex flex-wrap items-center justify-center gap-3 sm:gap-6 text-xs sm:text-sm text-slate-600 dark:text-slate-400 font-mono mb-16">
          <StaggerItem>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800/60 shadow-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Без подписки</span>
            </div>
          </StaggerItem>
          <StaggerItem>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800/60 shadow-xs">
              <FileSpreadsheet className="w-4 h-4 text-green-600 dark:text-green-400" />
              <span>Работает в Excel</span>
            </div>
          </StaggerItem>
          <StaggerItem>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800/60 shadow-xs">
              <Zap className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>Автоматические расчёты</span>
            </div>
          </StaggerItem>
          <StaggerItem>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800/60 shadow-xs">
              <RefreshCw className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <span>Поддержка обновлений</span>
            </div>
          </StaggerItem>
        </StaggerContainer>

        {/* Real Product Mockup Section */}
        <AnimatedSection delay={0.3} duration={0.6} className="relative max-w-5xl mx-auto">
          {/* Subtle Glow behind mockup */}
          <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 opacity-15 dark:opacity-20 blur-xl pointer-events-none" />

          {/* Excel Mockup Window */}
          <div className="relative bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl dark:shadow-2xl overflow-hidden backdrop-blur-md transition-colors">
            
            {/* Top Window Bar */}
            <div className="px-4 py-3 bg-slate-100/90 dark:bg-slate-900/90 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between transition-colors">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <div className="w-3 h-3 rounded-full bg-green-500/80" />
                <span className="ml-3 text-xs font-mono font-semibold text-slate-600 dark:text-slate-400 flex items-center gap-2">
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>PROFIT SYSTEM v9.2 — {activeTab === 'wb' ? 'Расчёт & Анализ WB.xlsx' : 'Расчёт & Анализ Ozon.xlsx'}</span>
                </span>
              </div>

              {/* Marketplace Toggle Tabs in Mockup */}
              <div className="flex items-center gap-1 bg-slate-200/80 dark:bg-slate-950 p-1 rounded-lg border border-slate-300/80 dark:border-slate-800 text-xs">
                <button
                  onClick={() => setActiveTab('wb')}
                  className={`px-3 py-1 rounded font-medium transition-colors ${
                    activeTab === 'wb' ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  WILDBERRIES
                </button>
                <button
                  onClick={() => setActiveTab('ozon')}
                  className={`px-3 py-1 rounded font-medium transition-colors ${
                    activeTab === 'ozon' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  OZON
                </button>
              </div>
            </div>

            {/* Dashboard Mockup Body */}
            <div className="p-4 sm:p-6 bg-slate-50/70 dark:bg-slate-950/90 font-mono text-xs transition-colors">
              
              {/* Summary KPIs Row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800 shadow-xs">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1 font-sans">Ассортимент</p>
                  <p className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white font-sans">21 SKU</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-500 mt-0.5">в расчете</p>
                </div>

                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800 shadow-xs">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1 font-sans">Маржинальность</p>
                  <p className="text-xl sm:text-2xl font-bold text-emerald-600 dark:text-emerald-400 font-sans">15.0 %</p>
                  <p className="text-[10px] text-emerald-600 dark:text-emerald-500 mt-0.5">целевая экономика</p>
                </div>

                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800 shadow-xs">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1 font-sans">Чистая прибыль</p>
                  <p className="text-xl sm:text-2xl font-bold text-blue-600 dark:text-blue-400 font-sans">12 845 ₽</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-500 mt-0.5">с единицы партий</p>
                </div>

                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800 shadow-xs">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1 font-sans">Комиссия {activeTab.toUpperCase()}</p>
                  <p className="text-xl sm:text-2xl font-bold text-slate-800 dark:text-slate-200 font-sans">{activeTab === 'wb' ? '43.0 %' : '38.5 %'}</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-500 mt-0.5">категория Одежда/Дом</p>
                </div>
              </div>

              {/* Table Data Preview */}
              <div className="rounded-xl border border-slate-200 dark:border-slate-800/80 overflow-x-auto bg-white dark:bg-slate-900/40 shadow-xs">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-100/90 dark:bg-slate-900/90 text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[11px] uppercase">
                      <th className="py-2.5 px-3">Наименование товара</th>
                      <th className="py-2.5 px-3">Цена клиента</th>
                      <th className="py-2.5 px-3">Комиссия</th>
                      <th className="py-2.5 px-3">Логистика</th>
                      <th className="py-2.5 px-3">Расходы</th>
                      <th className="py-2.5 px-3 text-emerald-600 dark:text-emerald-400">Чистая прибыль</th>
                      <th className="py-2.5 px-3">Маржа %</th>
                      <th className="py-2.5 px-3 text-center">Статус</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/50 text-slate-700 dark:text-slate-300">
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-white flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400" />
                        <span>Вентилятор напольный Pro</span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">5 280 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">2 270 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">239 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">1 751 ₽</td>
                      <td className="py-2.5 px-3 font-bold text-emerald-600 dark:text-emerald-400">821 ₽</td>
                      <td className="py-2.5 px-3 text-emerald-600 dark:text-emerald-400 font-bold">15.6%</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold border border-emerald-200 dark:border-emerald-500/20">
                          <CheckCircle2 className="w-3 h-3" /> OK
                        </span>
                      </td>
                    </tr>

                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-white flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400" />
                        <span>Кофеварка капельная 1.2л</span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">4 190 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">1 804 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">210 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">1 376 ₽</td>
                      <td className="py-2.5 px-3 font-bold text-emerald-600 dark:text-emerald-400">800 ₽</td>
                      <td className="py-2.5 px-3 text-emerald-600 dark:text-emerald-400 font-bold">19.1%</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold border border-emerald-200 dark:border-emerald-500/20">
                          <CheckCircle2 className="w-3 h-3" /> OK
                        </span>
                      </td>
                    </tr>

                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-white flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400" />
                        <span>Кабель USB-C Fast Charge 2m</span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">890 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">382 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">98 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">186 ₽</td>
                      <td className="py-2.5 px-3 font-bold text-emerald-600 dark:text-emerald-400">224 ₽</td>
                      <td className="py-2.5 px-3 text-emerald-600 dark:text-emerald-400 font-bold">25.2%</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold border border-emerald-200 dark:border-emerald-500/20">
                          <CheckCircle2 className="w-3 h-3" /> OK
                        </span>
                      </td>
                    </tr>

                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-white flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400" />
                        <span>Наушники беспроводные TWS</span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">2 980 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">1 279 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">153 ₽</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">814 ₽</td>
                      <td className="py-2.5 px-3 font-bold text-emerald-600 dark:text-emerald-400">734 ₽</td>
                      <td className="py-2.5 px-3 text-emerald-600 dark:text-emerald-400 font-bold">24.6%</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold border border-emerald-200 dark:border-emerald-500/20">
                          <CheckCircle2 className="w-3 h-3" /> OK
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Bottom status line */}
              <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex flex-wrap items-center justify-between text-slate-500 dark:text-slate-400 text-[11px]">
                <div className="flex items-center gap-4">
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">✓ Расчёт обновлен по правилам 2026 года</span>
                  <span>Логистика и коэффициенты складов учтены</span>
                </div>
                <div className="text-slate-500 dark:text-slate-500">
                  Платформа PROFIT SYSTEM • Excel Ready
                </div>
              </div>

            </div>
          </div>
        </AnimatedSection>

      </div>
    </section>
  );
}
