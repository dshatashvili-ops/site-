import { Target, PieChart, ShieldAlert, BarChart3, Sliders, ArrowRight, CheckCircle2 } from 'lucide-react';
import { AnimatedSection, StaggerContainer, StaggerItem } from './AnimatedSection';

interface ResultsOutcomeSectionProps {
  onNavigateToProducts: () => void;
}

export function ResultsOutcomeSection({ onNavigateToProducts }: ResultsOutcomeSectionProps) {
  const outcomes = [
    {
      number: '01',
      title: 'Минимальную экономически оправданную цену',
      description: 'Точный порог цены товара, ниже которого продавать нельзя, чтобы гарантированно не работать в минус с учётом всех комиссий, логистики, рекламы и налогов.',
      levelTag: 'Модуль 01 • Расчёт цены',
      icon: Target,
      color: 'from-blue-500/20 to-cyan-500/10',
      borderColor: 'border-blue-500/30',
      badgeColor: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
      numColor: 'text-blue-400'
    },
    {
      number: '02',
      title: 'Фактическую прибыль по SKU',
      description: 'Детализацию реального финансового результата по каждому наименованию ассортимента. Мгновенная подсветка прибыльных и уходящих в убыток позиций.',
      levelTag: 'Модуль 02 • Анализ цен',
      icon: PieChart,
      color: 'from-cyan-500/20 to-teal-500/10',
      borderColor: 'border-cyan-500/30',
      badgeColor: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
      numColor: 'text-cyan-400'
    },
    {
      number: '03',
      title: 'Какие товары становятся убыточными на акции',
      description: 'Безопасные границы участия в автоакциях и распродажах WB/Ozon. Заранее увидите, какие товары провалят маржу, и сохраните капитал.',
      levelTag: 'Модуль 03 • Расчёт акций',
      icon: ShieldAlert,
      color: 'from-purple-500/20 to-indigo-500/10',
      borderColor: 'border-purple-500/30',
      badgeColor: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
      numColor: 'text-purple-400'
    },
    {
      number: '04',
      title: 'Какую выручку нужно сделать бизнесу',
      description: 'Точную цифру минимальной выручки в рублях и штуках, необходимую для достижения полной точки безубыточности (ТБ) и покрытия всех постоянных затрат.',
      levelTag: 'Модуль 04 • Точка безубыточности',
      icon: BarChart3,
      color: 'from-emerald-500/20 to-teal-500/10',
      borderColor: 'border-emerald-500/30',
      badgeColor: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
      numColor: 'text-emerald-400'
    },
    {
      number: '05',
      title: 'Как изменение маржи влияет на финансовый порог',
      description: 'Сценарное моделирование «Что если»: понимание, как сдвиг комиссии, процента выкупа или рекламного бюджета меняет необходимый план продаж.',
      levelTag: 'Сценарный анализ ТБ',
      icon: Sliders,
      color: 'from-amber-500/20 to-orange-500/10',
      borderColor: 'border-amber-500/30',
      badgeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
      numColor: 'text-amber-400'
    }
  ];

  return (
    <section id="outcomes" className="py-24 bg-slate-100/70 dark:bg-slate-950/95 border-b border-slate-200 dark:border-slate-900 transition-colors relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Header */}
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-600 dark:text-blue-400 text-xs font-mono mb-4 uppercase tracking-wider font-semibold shadow-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>ЦЕННОСТЬ ДЛЯ ПРЕДПРИНИМАТЕЛЯ</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-brand font-extrabold text-slate-900 dark:text-white tracking-tight mb-4">
            КАКОЙ РЕЗУЛЬТАТ ВЫ ПОЛУЧАЕТЕ
          </h2>
          
          <p className="text-xl sm:text-2xl font-brand font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-sky-500 to-indigo-600 dark:from-blue-400 dark:via-cyan-300 dark:to-indigo-300">
            После расчёта вы точно знаете:
          </p>
        </AnimatedSection>

        {/* 5 Grid Cards */}
        <StaggerContainer staggerDelay={0.1} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {outcomes.map((item, idx) => {
            const Icon = item.icon;
            // Make item 5 span full width on grid if desired, or fit nicely
            const isLastOdd = idx === 4;

            return (
              <StaggerItem key={item.number}>
                <div
                  className={`group relative bg-white dark:bg-slate-900/80 backdrop-blur-md border ${item.borderColor} rounded-3xl p-6 sm:p-8 hover:bg-slate-50 dark:hover:bg-slate-900 transition-all duration-300 hover:scale-[1.02] hover:shadow-xl dark:hover:shadow-2xl flex flex-col justify-between h-full ${
                    isLastOdd ? 'md:col-span-2 lg:col-span-1' : ''
                  }`}
                >
                  {/* Subtle card gradient highlight */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${item.color} rounded-3xl opacity-50 group-hover:opacity-100 transition-opacity pointer-events-none`} />

                  <div className="relative z-10">
                    {/* Top bar: Number & Badge */}
                    <div className="flex items-center justify-between mb-6">
                      <span className={`text-3xl sm:text-4xl font-black font-mono tracking-tight ${item.numColor}`}>
                        {item.number}
                      </span>
                      <span className={`text-[11px] font-mono px-2.5 py-1 rounded-full border ${item.badgeColor}`}>
                        {item.levelTag}
                      </span>
                    </div>

                    {/* Icon & Title */}
                    <div className="flex items-start gap-3 mb-4">
                      <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 shrink-0 text-slate-900 dark:text-white group-hover:border-slate-300 dark:group-hover:border-slate-700 transition-colors">
                        <Icon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <h3 className="text-lg font-brand font-bold text-slate-900 dark:text-white leading-snug group-hover:text-blue-600 dark:group-hover:text-blue-200 transition-colors">
                        {item.title}
                      </h3>
                    </div>

                    {/* Description */}
                    <p className="text-sm font-sans text-slate-600 dark:text-slate-300 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  {/* Bottom line marker */}
                  <div className="relative z-10 pt-6 mt-6 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-500">
                    <span>PROFIT SYSTEM Outcome</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Гарантированный расчёт
                    </span>
                  </div>
                </div>
              </StaggerItem>
            );
          })}
        </StaggerContainer>

        {/* Action Button Below Section */}
        <div className="mt-16 text-center">
          <button
            onClick={onNavigateToProducts}
            className="inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-brand font-bold text-base shadow-xl shadow-blue-500/25 hover:shadow-blue-500/40 hover:scale-105 active:scale-95 transition-all cursor-pointer border border-blue-400/30"
          >
            <span>Получить точные цифры для вашего бизнеса</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

      </div>
    </section>
  );
}
