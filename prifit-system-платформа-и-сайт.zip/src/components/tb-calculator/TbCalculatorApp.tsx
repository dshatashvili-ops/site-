import React, { useState, useMemo, useEffect } from 'react';
import { Header } from './Header';
import { MetricCards } from './MetricCards';
import { FixedExpensesTable } from './FixedExpensesTable';
import { PlannedMetricsCard } from './PlannedMetricsCard';
import { MarginCard } from './MarginCard';
import { WhatIfCard } from './WhatIfCard';
import { ExpenseChartCard } from './ExpenseChartCard';
import { ActionBar } from './ActionBar';
import { DocumentReportModal } from './DocumentReportModal';
import { VideoGuideModal } from './VideoGuideModal';
import { PromoActivationModal } from './PromoActivationModal';
import { SubscriptionPaymentModal } from './SubscriptionPaymentModal';
import { ExpenseItem, TbAccessMode } from '../../types';
import { INITIAL_EXPENSES } from '../../data/initialData';
import { exportToExcel, downloadExcelTemplate } from '../../utils/excelService';
import { Flame, Sparkles, ArrowRight } from 'lucide-react';

interface TbCalculatorAppProps {
  onBackToLanding: () => void;
  onNavigateToProduct04?: () => void;
}

const DEMO_ALLOWED_IDS = ['1', '2', '3', '4', '5'];

export const TbCalculatorApp: React.FC<TbCalculatorAppProps> = ({
  onBackToLanding,
  onNavigateToProduct04,
}) => {
  // State for Financial Data
  const [expenses, setExpenses] = useState<ExpenseItem[]>(INITIAL_EXPENSES);
  const [desiredProfit, setDesiredProfit] = useState<number>(500000);
  const [marginPercent, setMarginPercent] = useState<number>(25);
  const [whatIfMarginPercent, setWhatIfMarginPercent] = useState<number>(12);

  // Access mode state
  const [accessMode, setAccessMode] = useState<TbAccessMode>('demo');
  const [promoExpiresAt, setPromoExpiresAt] = useState<number | null>(null);
  const [promoTimeRemainingFormatted, setPromoTimeRemainingFormatted] = useState<string>('');

  // Modals
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [isVideoGuideOpen, setIsVideoGuideOpen] = useState<boolean>(false);
  const [videoGuideTab, setVideoGuideTab] = useState<'video' | 'methodology'>('methodology');
  const [isPromoModalOpen, setIsPromoModalOpen] = useState<boolean>(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);

  // Toast Notifications
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  // Check saved access mode in localStorage on load
  useEffect(() => {
    try {
      const savedMode = localStorage.getItem('profit_tb_access_mode') as TbAccessMode | null;
      const savedExpires = localStorage.getItem('profit_tb_promo_expires_at');

      if (savedMode === 'paid_subscription') {
        setAccessMode('paid_subscription');
      } else if (savedMode === 'promo_24h' && savedExpires) {
        const expiresTime = parseInt(savedExpires, 10);
        if (Date.now() < expiresTime) {
          setAccessMode('promo_24h');
          setPromoExpiresAt(expiresTime);
        } else {
          setAccessMode('demo');
          localStorage.setItem('profit_tb_access_mode', 'demo');
        }
      }
    } catch (e) {
      // localStorage disabled or error
    }
  }, []);

  // Timer interval for Promo 24h
  useEffect(() => {
    if (accessMode !== 'promo_24h' || !promoExpiresAt) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const diff = promoExpiresAt - now;

      if (diff <= 0) {
        setAccessMode('demo');
        setPromoExpiresAt(null);
        setPromoTimeRemainingFormatted('');
        localStorage.setItem('profit_tb_access_mode', 'demo');
        showToast('error', 'Ваш 24-часовой бесплатный промо-доступ завершён.');
        setIsPaymentModalOpen(true);
      } else {
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        const formatted = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        setPromoTimeRemainingFormatted(formatted);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [accessMode, promoExpiresAt]);

  // Handle 24h Promo Activation (Click 2)
  const handleConfirmPromoActivation = () => {
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000;
    setAccessMode('promo_24h');
    setPromoExpiresAt(expiresAt);
    try {
      localStorage.setItem('profit_tb_access_mode', 'promo_24h');
      localStorage.setItem('profit_tb_promo_expires_at', String(expiresAt));
    } catch (e) {}

    setIsPromoModalOpen(false);
    showToast('success', '🔥 Промо-доступ на 24 часа успешно активирован! Все функции разблокированы.');
  };

  // Handle Successful Subscription Payment
  const handleSuccessSubscriptionPayment = () => {
    setAccessMode('paid_subscription');
    try {
      localStorage.setItem('profit_tb_access_mode', 'paid_subscription');
    } catch (e) {}

    setIsPaymentModalOpen(false);
    showToast('success', '🎉 Подписка успешно оформлена! Вам предоставлен бессрочный PRO-доступ.');
  };

  // Recalculated Total Fixed Expenses (In demo mode, strictly sums the top 5 visible items)
  const totalExpenses = useMemo(() => {
    if (accessMode === 'demo') {
      const demoVisible = expenses.filter((item) => DEMO_ALLOWED_IDS.includes(item.id));
      return demoVisible.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    }
    return expenses.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  }, [expenses, accessMode]);

  // Break-even Point in Revenue
  const breakEvenPoint = useMemo(() => {
    return marginPercent > 0 ? totalExpenses / (marginPercent / 100) : 0;
  }, [totalExpenses, marginPercent]);

  // Required Revenue for Target Profit
  const requiredRevenue = useMemo(() => {
    const requiredMargin = totalExpenses + desiredProfit;
    return marginPercent > 0 ? requiredMargin / (marginPercent / 100) : 0;
  }, [totalExpenses, desiredProfit, marginPercent]);

  // Expense Handlers
  const handleUpdateExpense = (id: string, field: keyof ExpenseItem, value: any) => {
    setExpenses((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const handleAddExpense = (partial: Partial<ExpenseItem>) => {
    const newId = String(Date.now());
    const nextNumber = expenses.length > 0 ? Math.max(...expenses.map((e) => e.number)) + 1 : 1;
    const newItem: ExpenseItem = {
      id: newId,
      number: nextNumber,
      name: partial.name || 'Новая статья',
      amount: partial.amount || 0,
      comment: partial.comment || '',
      category: partial.category || 'other',
    };
    setExpenses((prev) => [...prev, newItem]);
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses((prev) => {
      const filtered = prev.filter((item) => item.id !== id);
      return filtered.map((item, idx) => ({ ...item, number: idx + 1 }));
    });
  };

  // Action Handlers
  const handleCalculate = () => {
    showToast('success', 'Результаты финансового расчета мгновенно пересчитаны!');
  };

  const handleClear = () => {
    setExpenses(INITIAL_EXPENSES);
    setDesiredProfit(500000);
    setMarginPercent(25);
    setWhatIfMarginPercent(12);
    showToast('success', 'Параметры сброшены к стандартным');
  };

  const handleClearAll = () => {
    setExpenses((prev) => prev.map((item) => ({ ...item, amount: 0 })));
    setDesiredProfit(0);
    showToast('success', 'Все суммы расходов обнулены');
  };

  const handleExportExcel = () => {
    exportToExcel(expenses, desiredProfit, marginPercent, whatIfMarginPercent);
    showToast('success', 'Файл Excel (.xlsx) с формулами сгенерирован и скачан!');
  };

  const handleDownloadTemplate = () => {
    downloadExcelTemplate();
    showToast('success', 'Шаблон файла Excel (.xlsx) успешно скачан!');
  };

  const handleOpenVideoGuideWithTab = (tab?: 'video' | 'methodology') => {
    setVideoGuideTab(tab || 'methodology');
    setIsVideoGuideOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans flex flex-col antialiased selection:bg-blue-500 selection:text-white relative">
      {/* Toast Notification */}
      {notification && (
        <div
          className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-xl shadow-xl border text-xs sm:text-sm font-bold flex items-center gap-2 transition-all animate-in slide-in-from-top-2 ${
            notification.type === 'success'
              ? 'bg-emerald-600 text-white border-emerald-500'
              : 'bg-red-600 text-white border-red-500'
          }`}
        >
          <span>{notification.message}</span>
        </div>
      )}

      {/* Top Header */}
      <Header
        accessMode={accessMode}
        promoTimeRemainingFormatted={promoTimeRemainingFormatted}
        onOpenVideoGuide={handleOpenVideoGuideWithTab}
        onRequestPromo={() => setIsPromoModalOpen(true)}
        onRequestSubscription={() => setIsPaymentModalOpen(true)}
        onBackToLanding={onBackToLanding}
      />

      {/* Top Demo Banner if in Demo Mode */}
      {accessMode === 'demo' && (
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 px-4 py-2 text-xs font-bold shadow-md flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 fill-current text-slate-950" />
            <span>
              Вы используете демонстрационный режим. Получите ПОЛНЫЙ доступ на 24 часа бесплатно за 2 клика без ввода карты!
            </span>
          </div>
          <button
            onClick={() => setIsPromoModalOpen(true)}
            className="px-3.5 py-1 rounded-lg bg-slate-950 text-amber-400 hover:text-amber-300 font-black text-xs cursor-pointer transition-all shadow-xs shrink-0"
          >
            Активировать 24 часа бесплатно
          </button>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* Top 4 KPI Cards */}
        <MetricCards
          breakEvenPoint={breakEvenPoint}
          marginPercent={marginPercent}
          desiredProfit={desiredProfit}
          requiredRevenue={requiredRevenue}
        />

        {/* Core Layout: Left Table & Right Calculation Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left Column (7 cols): Fixed Expenses Table */}
          <div className="lg:col-span-7 flex flex-col">
            <FixedExpensesTable
              expenses={expenses}
              totalExpenses={totalExpenses}
              accessMode={accessMode}
              onUpdateExpense={handleUpdateExpense}
              onAddExpense={handleAddExpense}
              onDeleteExpense={handleDeleteExpense}
              onRequestPromo={() => setIsPromoModalOpen(true)}
            />
          </div>

          {/* Right Column (5 cols): Planned Metrics, Margin, What-If, Chart */}
          <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
            {/* Product 04 Banner Button (Level with Fixed Expenses Table) */}
            <button
              onClick={onNavigateToProduct04 || onBackToLanding}
              className="w-full bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 hover:from-blue-900 hover:to-indigo-900 border border-blue-500/40 hover:border-blue-400 text-white p-3.5 rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-between gap-3 group hover:scale-[1.01]"
              title="Перейти к Продуктовой лестнице 04"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Sparkles className="w-4.5 h-4.5 text-amber-400 animate-pulse" />
                </div>
                <div className="text-left">
                  <div className="text-xs font-black text-amber-400 uppercase tracking-tight font-brand flex items-center gap-1.5">
                    <span>ПРОДУКТ 04:</span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-100 font-bold">
                    Бессрочный доступ к ТБ без подписки
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 text-xs text-blue-300 font-bold group-hover:translate-x-1 transition-transform shrink-0">
                <span className="hidden sm:inline">Подробнее</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </button>

            {/* Planned Metrics */}
            <PlannedMetricsCard
              desiredProfit={desiredProfit}
              marginPercent={marginPercent}
              totalExpenses={totalExpenses}
              onUpdateDesiredProfit={setDesiredProfit}
            />

            {/* Margin Slider */}
            <MarginCard
              marginPercent={marginPercent}
              accessMode={accessMode}
              onUpdateMargin={setMarginPercent}
              onRequestPromo={() => setIsPromoModalOpen(true)}
            />

            {/* What-If Analysis */}
            <WhatIfCard
              totalExpenses={totalExpenses}
              whatIfMarginPercent={whatIfMarginPercent}
              accessMode={accessMode}
              onUpdateWhatIfMargin={setWhatIfMarginPercent}
              onRequestPromo={() => setIsPromoModalOpen(true)}
            />

            {/* Expense Breakdown Donut Chart */}
            <ExpenseChartCard
              expenses={expenses}
              totalExpenses={totalExpenses}
            />
          </div>
        </div>

        {/* Bottom Action Bar */}
        <ActionBar
          accessMode={accessMode}
          onCalculate={handleCalculate}
          onClear={handleClear}
          onClearAll={handleClearAll}
          onExportExcel={handleExportExcel}
          onGenerateReport={() => setIsReportModalOpen(true)}
          onRequestPromo={() => setIsPromoModalOpen(true)}
        />
      </main>

      {/* Printable Report Modal */}
      <DocumentReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        expenses={expenses}
        totalExpenses={totalExpenses}
        breakEvenPoint={breakEvenPoint}
        marginPercent={marginPercent}
        desiredProfit={desiredProfit}
        requiredRevenue={requiredRevenue}
        whatIfMarginPercent={whatIfMarginPercent}
      />

      {/* Video Guide & Methodology Modal */}
      <VideoGuideModal
        isOpen={isVideoGuideOpen}
        onClose={() => setIsVideoGuideOpen(false)}
        defaultTab={videoGuideTab}
      />

      {/* 2-Click Promo Activation Modal */}
      <PromoActivationModal
        isOpen={isPromoModalOpen}
        onClose={() => setIsPromoModalOpen(false)}
        onConfirmPromo={handleConfirmPromoActivation}
        onRequestSubscription={() => {
          setIsPromoModalOpen(false);
          setIsPaymentModalOpen(true);
        }}
      />

      {/* Subscription Acquiring Payment Modal */}
      <SubscriptionPaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        onSuccessPayment={handleSuccessSubscriptionPayment}
      />
    </div>
  );
};
