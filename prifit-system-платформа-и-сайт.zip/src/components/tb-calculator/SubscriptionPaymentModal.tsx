import React, { useState, useEffect } from 'react';
import {
  X,
  CreditCard,
  ShieldCheck,
  Lock,
  QrCode,
  Sparkles,
  Loader2,
} from 'lucide-react';

interface SubscriptionPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessPayment: () => void;
}

export const SubscriptionPaymentModal: React.FC<SubscriptionPaymentModalProps> = ({
  isOpen,
  onClose,
  onSuccessPayment,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'sbp'>('card');
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [promoCode, setPromoCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const basePrice = 5900;
  const finalPrice = discountApplied ? Math.round(basePrice * 0.8) : basePrice;

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'PROFIT' || promoCode.trim().toUpperCase() === 'PROMO2026') {
      setDiscountApplied(true);
      setErrorMessage('');
    } else {
      setErrorMessage('Неверный промокод');
    }
  };

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setErrorMessage('Укажите Email для отправки чека и доступа');
      return;
    }

    setIsProcessing(true);
    setErrorMessage('');

    // Simulate acquiring processing
    setTimeout(() => {
      setIsProcessing(false);
      onSuccessPayment();
    }, 1800);
  };

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 md:p-8 bg-slate-950/85 backdrop-blur-md overflow-y-auto overscroll-contain animate-in fade-in duration-150"
    >
      <div className="relative bg-slate-900 text-white rounded-2xl sm:rounded-3xl max-w-2xl w-full my-auto flex flex-col border border-blue-500/30 shadow-2xl max-h-[calc(100vh-1.5rem)] sm:max-h-[calc(100vh-3rem)] overflow-hidden">
        {/* Glow accent */}
        <div className="absolute -top-32 -right-32 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-4 sm:p-6 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 flex items-center justify-between gap-4 z-20 shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black shadow-lg shadow-blue-500/20 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[11px] font-mono font-bold text-blue-400 uppercase tracking-wider">
                ОФОРМЛЕНИЕ ПОДПИСКИ
              </div>
              <h3 className="text-base sm:text-xl font-bold font-brand text-white leading-tight">
                PROFIT SYSTEM — Веб-ТБ
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 cursor-pointer transition-colors shrink-0"
            title="Закрыть (Esc)"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="overflow-y-auto p-5 sm:p-8 flex-1 space-y-6">
          {/* Pricing card summary */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-800/90 border border-slate-700/80 flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="text-xs text-slate-400 font-mono">Тариф «Полный доступ ТБ»</div>
              <div className="text-xs sm:text-sm font-bold text-slate-200 mt-0.5">Неограниченное число расчётов, экспорт Excel & PDF</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-400 line-through">
                {discountApplied ? '5 900 ₽' : ''}
              </div>
              <div className="text-xl sm:text-2xl font-black text-blue-400 font-mono">
                {finalPrice.toLocaleString('ru-RU')} ₽ <span className="text-xs text-slate-400 font-normal">/ мес</span>
              </div>
            </div>
          </div>

          {/* Product 04 Banner Note */}
          <div className="p-3.5 rounded-xl bg-blue-950/60 border border-blue-500/30 text-xs text-blue-200 leading-relaxed">
            💡 <strong>Обратите внимание:</strong> Полный бессрочный функционал Веб-ТБ без ежемесячной подписки навсегда входит в состав основного <strong>Продукта 04 (Система управления прибылью)</strong>.
          </div>

          {/* Payment Methods Tabs */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setPaymentMethod('card')}
              className={`p-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                paymentMethod === 'card'
                  ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                  : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>Банковская карта</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('sbp')}
              className={`p-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                paymentMethod === 'sbp'
                  ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                  : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              <QrCode className="w-4 h-4" />
              <span>СБП (QR-код) / Tinkoff Pay</span>
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handlePay} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  ФИО владельца:
                </label>
                <input
                  type="text"
                  placeholder="Иванов Иван Иванович"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Email для чека и доступа <span className="text-blue-400">*</span>:
                </label>
                <input
                  type="email"
                  required
                  placeholder="seller@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {paymentMethod === 'card' && (
              <div className="space-y-3 p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">
                    Номер банковской карты:
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      maxLength={19}
                      placeholder="2202 2000 0000 0000"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full px-3 py-2.5 pl-10 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-blue-500"
                    />
                    <CreditCard className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      Срок действия:
                    </label>
                    <input
                      type="text"
                      maxLength={5}
                      placeholder="MM/YY"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full px-3 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      CVC / CVV:
                    </label>
                    <input
                      type="password"
                      maxLength={3}
                      placeholder="•••"
                      value={cardCvc}
                      onChange={(e) => setCardCvc(e.target.value)}
                      className="w-full px-3 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Promo code input */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Промокод (если есть)"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                className="flex-1 px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white font-mono uppercase focus:outline-none focus:border-blue-500"
              />
              <button
                type="button"
                onClick={handleApplyPromo}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs cursor-pointer"
              >
                Применить
              </button>
            </div>

            {discountApplied && (
              <div className="text-xs text-emerald-400 font-medium flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                <span>Промокод применён! Скидка -20%</span>
              </div>
            )}

            {errorMessage && (
              <div className="text-xs text-red-400 font-medium">{errorMessage}</div>
            )}

            {/* Pay Button */}
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-3.5 px-6 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-xl shadow-blue-600/30 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Безопасная обработка платежа...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Оплатить {finalPrice.toLocaleString('ru-RU')} ₽ и открыть доступ</span>
                </>
              )}
            </button>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-1">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Защищено шифрованием SSL 256-bit
              </span>
              <span>ЮKassa / Tinkoff</span>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
