import React from 'react';
import { Scale, BarChart3, Target, Banknote } from 'lucide-react';
import { formatCurrency, formatPercent } from '../../utils/formatters';

interface MetricCardsProps {
  breakEvenPoint: number;
  marginPercent: number;
  desiredProfit: number;
  requiredRevenue: number;
}

export const MetricCards: React.FC<MetricCardsProps> = ({
  breakEvenPoint,
  marginPercent,
  desiredProfit,
  requiredRevenue,
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Card 1: Break-even point */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4 transition-all hover:shadow-md">
        <div className="w-12 h-12 rounded-full bg-blue-900 dark:bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-sm">
          <Scale className="w-6 h-6" />
        </div>
        <div>
          <div className="text-[11px] font-bold tracking-wider text-slate-500 dark:text-slate-400 uppercase font-mono">
            ТОЧКА БЕЗУБЫТОЧНОСТИ
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-0.5">
            {formatCurrency(breakEvenPoint)}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">в месяц</div>
        </div>
      </div>

      {/* Card 2: Margin */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4 transition-all hover:shadow-md">
        <div className="w-12 h-12 rounded-full bg-emerald-600 dark:bg-emerald-500 flex items-center justify-center text-white shrink-0 shadow-sm">
          <BarChart3 className="w-6 h-6" />
        </div>
        <div>
          <div className="text-[11px] font-bold tracking-wider text-slate-500 dark:text-slate-400 uppercase font-mono">
            МАРЖИНАЛЬНОСТЬ
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-0.5">
            {formatPercent(marginPercent)}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">текущая</div>
        </div>
      </div>

      {/* Card 3: Desired Profit */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4 transition-all hover:shadow-md">
        <div className="w-12 h-12 rounded-full bg-purple-600 dark:bg-purple-500 flex items-center justify-center text-white shrink-0 shadow-sm">
          <Target className="w-6 h-6" />
        </div>
        <div>
          <div className="text-[11px] font-bold tracking-wider text-slate-500 dark:text-slate-400 uppercase font-mono">
            ЖЕЛАЕМАЯ ПРИБЫЛЬ
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-0.5">
            {formatCurrency(desiredProfit)}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">в месяц</div>
        </div>
      </div>

      {/* Card 4: Required Revenue */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4 transition-all hover:shadow-md">
        <div className="w-12 h-12 rounded-full bg-blue-600 dark:bg-blue-500 flex items-center justify-center text-white shrink-0 shadow-sm">
          <Banknote className="w-6 h-6" />
        </div>
        <div>
          <div className="text-[11px] font-bold tracking-wider text-slate-500 dark:text-slate-400 uppercase font-mono">
            НЕОБХОДИМАЯ ВЫРУЧКА
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-0.5">
            {formatCurrency(requiredRevenue)}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
            для достижения прибыли
          </div>
        </div>
      </div>
    </div>
  );
};
