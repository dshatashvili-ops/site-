import React from 'react';
import { BarChart3, Lock, AlertCircle } from 'lucide-react';
import { formatPercent } from '../../utils/formatters';
import { TbAccessMode } from '../../types';

interface MarginCardProps {
  marginPercent: number;
  accessMode: TbAccessMode;
  onUpdateMargin: (val: number) => void;
  onRequestPromo: () => void;
}

export const MarginCard: React.FC<MarginCardProps> = ({
  marginPercent,
  accessMode,
  onUpdateMargin,
  onRequestPromo,
}) => {
  const isDemo = accessMode === 'demo';

  const handleSliderOrInput = (rawValue: number) => {
    let val = Math.min(99, Math.max(1, rawValue));

    if (isDemo) {
      if (val < 25) {
        val = 25;
        onRequestPromo();
      } else if (val > 35) {
        val = 35;
        onRequestPromo();
      }
    }

    onUpdateMargin(val);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
            <BarChart3 className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-sm uppercase tracking-tight font-brand">
            УРОВЕНЬ МАРЖИНАЛЬНОСТИ БИЗНЕСА
          </h3>
        </div>
        {isDemo && (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 font-bold flex items-center gap-1">
            <Lock className="w-3 h-3" /> Лимит 25-35%
          </span>
        )}
      </div>

      <div className="space-y-3">
        {/* Label & Manual Editable Number Input */}
        <div className="flex items-center justify-between gap-3 text-xs font-semibold text-slate-700 dark:text-slate-300">
          <span>Средняя маржинальность (% от выручки):</span>
          <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1">
            <input
              type="number"
              min={1}
              max={99}
              step={0.1}
              value={marginPercent}
              onChange={(e) => handleSliderOrInput(parseFloat(e.target.value) || 1)}
              className="w-16 text-right font-black text-emerald-600 dark:text-emerald-400 font-mono text-base bg-transparent focus:outline-none"
            />
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">%</span>
          </div>
        </div>

        {/* Range Slider 1% - 99% */}
        <div className="space-y-1">
          <input
            type="range"
            min={1}
            max={99}
            step={1}
            value={marginPercent}
            onChange={(e) => handleSliderOrInput(parseFloat(e.target.value) || 1)}
            className="w-full h-2.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-600"
          />

          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1">
            <span>1%</span>
            <span>25%</span>
            <span>35%</span>
            <span>50%</span>
            <span>99%</span>
          </div>
        </div>

        {/* Demo Mode Notice */}
        {isDemo && (
          <div className="p-2.5 bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 rounded-lg text-[11px] text-amber-800 dark:text-amber-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-500 mt-0.5" />
            <div>
              <span>В демо-версии ограничение на выбор маржинальности (доступно от 25% до 35%).Для диапазона 1%–99% </span>
              <button
                onClick={onRequestPromo}
                className="font-bold underline text-amber-900 dark:text-amber-200 hover:text-amber-600 cursor-pointer"
              >
                активируйте Промо 24ч
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
