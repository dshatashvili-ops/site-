import React, { useEffect, useMemo } from 'react';
import {
  X,
  Printer,
  FileText,
  TrendingUp,
  Target,
  PieChart as PieIcon,
  Layers,
  AlertCircle,
  CheckCircle2,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { ExpenseItem, ExpenseCategory } from '../../types';
import { CATEGORIES } from '../../data/initialData';
import { formatCurrency, formatPercent } from '../../utils/formatters';

interface DocumentReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  expenses: ExpenseItem[];
  totalExpenses: number;
  breakEvenPoint: number;
  marginPercent: number;
  desiredProfit: number;
  requiredRevenue: number;
  whatIfMarginPercent: number;
}

export const DocumentReportModal: React.FC<DocumentReportModalProps> = ({
  isOpen,
  onClose,
  expenses,
  totalExpenses,
  breakEvenPoint,
  marginPercent,
  desiredProfit,
  requiredRevenue,
  whatIfMarginPercent,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  // Calculations for What-If Scenario
  const whatIfBreakEvenPoint = useMemo(() => {
    return whatIfMarginPercent > 0 ? totalExpenses / (whatIfMarginPercent / 100) : 0;
  }, [totalExpenses, whatIfMarginPercent]);

  const whatIfRequiredRevenue = useMemo(() => {
    const requiredMargin = totalExpenses + desiredProfit;
    return whatIfMarginPercent > 0 ? requiredMargin / (whatIfMarginPercent / 100) : 0;
  }, [totalExpenses, desiredProfit, whatIfMarginPercent]);

  const diffBEP = whatIfBreakEvenPoint - breakEvenPoint;
  const diffBEPPercent = breakEvenPoint > 0 ? (diffBEP / breakEvenPoint) * 100 : 0;

  const diffRevenue = whatIfRequiredRevenue - requiredRevenue;
  const diffRevenuePercent = requiredRevenue > 0 ? (diffRevenue / requiredRevenue) * 100 : 0;

  // Category Breakdown Calculation
  const categoryStats = useMemo(() => {
    const map: Record<ExpenseCategory, { total: number; count: number }> = {
      rent_utilities: { total: 0, count: 0 },
      payroll: { total: 0, count: 0 },
      marketing: { total: 0, count: 0 },
      transport: { total: 0, count: 0 },
      subscriptions: { total: 0, count: 0 },
      other: { total: 0, count: 0 },
    };

    expenses.forEach((item) => {
      const cat = item.category || 'other';
      if (!map[cat]) {
        map[cat] = { total: 0, count: 0 };
      }
      map[cat].total += Number(item.amount) || 0;
      if (Number(item.amount) > 0) {
        map[cat].count += 1;
      }
    });

    return Object.entries(map)
      .map(([key, data]) => {
        const catKey = key as ExpenseCategory;
        const catInfo = CATEGORIES[catKey] || CATEGORIES.other;
        const percent = totalExpenses > 0 ? (data.total / totalExpenses) * 100 : 0;
        return {
          id: catKey,
          label: catInfo.label,
          color: catInfo.color,
          total: data.total,
          count: data.count,
          percent,
        };
      })
      .filter((cat) => cat.total > 0)
      .sort((a, b) => b.total - a.total);
  }, [expenses, totalExpenses]);

  // Top 3 largest expenses for analytics
  const topExpenses = useMemo(() => {
    return [...expenses]
      .filter((e) => Number(e.amount) > 0)
      .sort((a, b) => Number(b.amount) - Number(a.amount))
      .slice(0, 3);
  }, [expenses]);

  if (!isOpen) return null;

  const handlePrint = () => {
    const reportElement = document.getElementById('printable-report');
    if (!reportElement) {
      window.print();
      return;
    }

    try {
      // Remove any existing print iframe
      const oldIframe = document.getElementById('print-report-isolated-iframe');
      if (oldIframe) {
        oldIframe.remove();
      }

      const iframe = document.createElement('iframe');
      iframe.id = 'print-report-isolated-iframe';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      iframe.style.visibility = 'hidden';
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document;
      if (!doc) {
        window.print();
        return;
      }

      // Collect current stylesheets
      let styles = '';
      document.querySelectorAll('style, link[rel="stylesheet"]').forEach((el) => {
        styles += el.outerHTML;
      });

      const printCustomStyles = `
        <style>
          @page {
            size: A4 portrait;
            margin: 10mm 12mm 10mm 12mm;
          }
          *, *::before, *::after {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          html, body {
            margin: 0 !important;
            padding: 0 !important;
            background: #ffffff !important;
            color: #0f172a !important;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
            font-size: 10pt !important;
            line-height: 1.4 !important;
            width: 100% !important;
          }
          #printable-report {
            padding: 0 !important;
            margin: 0 !important;
            width: 100% !important;
            background: #ffffff !important;
            color: #0f172a !important;
          }
          .print-no-break {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }
          table {
            width: 100% !important;
            border-collapse: collapse !important;
          }
          thead {
            display: table-header-group !important;
          }
          tr {
            break-inside: avoid !important;
            page-break-inside: avoid !important;
          }
        </style>
      `;

      doc.open();
      doc.write(`
        <!DOCTYPE html>
        <html lang="ru">
          <head>
            <meta charset="utf-8" />
            <title>PROFIT SYSTEM - Расчёт точки безубыточности (${currentDate})</title>
            ${styles}
            ${printCustomStyles}
          </head>
          <body class="bg-white text-slate-900">
            ${reportElement.outerHTML}
          </body>
        </html>
      `);
      doc.close();

      setTimeout(() => {
        try {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
        } catch (e) {
          console.error('Iframe print error, falling back to window.print', e);
          window.print();
        } finally {
          setTimeout(() => {
            iframe.remove();
          }, 3000);
        }
      }, 300);
    } catch (err) {
      console.error('Print preparation error:', err);
      window.print();
    }
  };

  const currentDate = new Date().toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const currentTime = new Date().toLocaleTimeString('ru-RU', {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div
      id="printable-report-modal"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 md:p-8 bg-slate-950/85 backdrop-blur-sm overflow-y-auto overscroll-contain animate-in fade-in duration-150 print-backdrop-reset"
    >
      <div
        id="printable-report-card"
        className="bg-white text-slate-900 rounded-2xl max-w-5xl w-full max-h-[calc(100vh-1.5rem)] sm:max-h-[calc(100vh-3rem)] my-auto flex flex-col shadow-2xl border border-slate-200 overflow-hidden print-card-reset"
      >
        {/* Header - Hidden on Print */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between gap-3 shrink-0 z-20 print:hidden border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500/30 text-blue-400 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-lg font-brand text-white">
                Финансовый отчёт: Точка Безубыточности
              </h3>
              <p className="text-xs text-slate-400">
                Полный комплексный срез всех блоков финансовой модели
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              onClick={handlePrint}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 transition-all inline-flex items-center gap-2 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Распечатать / Сохранить в PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 cursor-pointer transition-colors shrink-0"
              title="Закрыть (Esc)"
              aria-label="Закрыть"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Report Content */}
        <div
          className="p-6 sm:p-10 overflow-y-auto space-y-8 flex-1 print-body-reset text-slate-900 bg-white"
          id="printable-report"
        >
          {/* 1. Header Title & Metadata */}
          <div className="border-b-2 border-slate-900 pb-5 flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-blue-100 text-blue-800 text-[10px] font-black font-mono uppercase tracking-wider border border-blue-200">
                  PROFIT SYSTEM
                </span>
                <span className="text-xs font-bold text-slate-500 font-mono">
                  ФИНАНСОВЫЙ ОТЧЁТ
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black font-brand text-slate-900 mt-2 uppercase tracking-tight">
                РАСЧЁТ ТОЧКИ БЕЗУБЫТОЧНОСТИ И ЦЕЛЕВОЙ ПРИБЫЛИ
              </h1>
              <p className="text-xs text-slate-600 mt-1 max-w-2xl">
                Сквозная финансовая модель постоянных расходов, безубыточного объёма продаж и целевых показателей прибыльности бизнеса.
              </p>
            </div>

            <div className="text-right text-xs font-mono text-slate-600 space-y-1 self-end sm:self-auto bg-slate-50 sm:bg-transparent p-3 sm:p-0 rounded-xl border sm:border-0 border-slate-200">
              <div>
                <span className="text-slate-400">Дата: </span>
                <strong className="text-slate-900">{currentDate}</strong>
              </div>
              <div>
                <span className="text-slate-400">Время: </span>
                <strong className="text-slate-900">{currentTime}</strong>
              </div>
              <div>
                <span className="text-slate-400">Валюта: </span>
                <strong className="text-slate-900">Российский рубль (₽)</strong>
              </div>
            </div>
          </div>

          {/* 2. Блок 1: Сводный KPI Dashboard (6 ключевых показателей) */}
          <div className="print-no-break space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <h2 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-900">
                1. Сводные ключевые показатели бизнеса (KPI)
              </h2>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {/* Постоянные затраты */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[10px] font-bold text-slate-500 uppercase font-mono">
                  ПОСТОЯННЫЕ ЗАТРАТЫ
                </div>
                <div className="text-base sm:text-lg font-black text-slate-900 mt-1 font-mono">
                  {formatCurrency(totalExpenses)}
                </div>
                <div className="text-[10px] text-slate-500">в месяц (100% фикс)</div>
              </div>

              {/* Маржинальность */}
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
                <div className="text-[10px] font-bold text-emerald-800 uppercase font-mono">
                  МАРЖИНАЛЬНОСТЬ
                </div>
                <div className="text-base sm:text-lg font-black text-emerald-950 mt-1 font-mono">
                  {formatPercent(marginPercent)}
                </div>
                <div className="text-[10px] text-emerald-700">маржинальный доход</div>
              </div>

              {/* Точка безубыточности */}
              <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200">
                <div className="text-[10px] font-bold text-blue-800 uppercase font-mono">
                  ТОЧКА БЕЗУБЫТОЧНОСТИ
                </div>
                <div className="text-base sm:text-lg font-black text-blue-950 mt-1 font-mono">
                  {formatCurrency(breakEvenPoint)}
                </div>
                <div className="text-[10px] text-blue-700">минимальная выручка / мес</div>
              </div>

              {/* Суточный оборот ТБ */}
              <div className="p-3.5 rounded-xl bg-indigo-50 border border-indigo-200">
                <div className="text-[10px] font-bold text-indigo-800 uppercase font-mono">
                  ТБ В СУТКИ
                </div>
                <div className="text-base sm:text-lg font-black text-indigo-950 mt-1 font-mono">
                  {formatCurrency(breakEvenPoint / 30)}
                </div>
                <div className="text-[10px] text-indigo-700">минимум продаж / день</div>
              </div>

              {/* Желаемая прибыль */}
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200">
                <div className="text-[10px] font-bold text-amber-800 uppercase font-mono">
                  ЖЕЛАЕМАЯ ПРИБЫЛЬ
                </div>
                <div className="text-base sm:text-lg font-black text-amber-950 mt-1 font-mono">
                  {formatCurrency(desiredProfit)}
                </div>
                <div className="text-[10px] text-amber-700">чистая прибыль / мес</div>
              </div>

              {/* Необходимая выручка */}
              <div className="p-3.5 rounded-xl bg-purple-50 border border-purple-200">
                <div className="text-[10px] font-bold text-purple-800 uppercase font-mono">
                  ЦЕЛЕВАЯ ВЫРУЧКА
                </div>
                <div className="text-base sm:text-lg font-black text-purple-950 mt-1 font-mono">
                  {formatCurrency(requiredRevenue)}
                </div>
                <div className="text-[10px] text-purple-700">план продаж / мес</div>
              </div>
            </div>
          </div>

          {/* 3. Блок 2: Плановые показатели и декомпозиция выручки */}
          <div className="print-no-break space-y-3">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-purple-600" />
              <h2 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-900">
                2. Плановые финансовые показатели и структура целевого дохода
              </h2>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                    <th className="py-2.5 px-4">Параметр планирования</th>
                    <th className="py-2.5 px-4 text-right">Сумма в месяц (₽)</th>
                    <th className="py-2.5 px-4 text-right">Суточная норма (₽/день)</th>
                    <th className="py-2.5 px-4">Экономическое значение</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  <tr>
                    <td className="py-2 px-4 font-semibold">Постоянные обязательные расходы</td>
                    <td className="py-2 px-4 text-right font-mono font-bold">{formatCurrency(totalExpenses)}</td>
                    <td className="py-2 px-4 text-right font-mono text-slate-600">{formatCurrency(totalExpenses / 30)}</td>
                    <td className="py-2 px-4 text-slate-600">Сумма, необходимая для покрытия 100% затрат бизнеса</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 font-semibold">Целевая чистая прибыль</td>
                    <td className="py-2 px-4 text-right font-mono font-bold text-amber-700">{formatCurrency(desiredProfit)}</td>
                    <td className="py-2 px-4 text-right font-mono text-slate-600">{formatCurrency(desiredProfit / 30)}</td>
                    <td className="py-2 px-4 text-slate-600">Желаемый чистый доход собственника после всех вычетов</td>
                  </tr>
                  <tr className="bg-purple-50/50">
                    <td className="py-2 px-4 font-semibold text-purple-950">Необходимый маржинальный доход</td>
                    <td className="py-2 px-4 text-right font-mono font-black text-purple-950">{formatCurrency(totalExpenses + desiredProfit)}</td>
                    <td className="py-2 px-4 text-right font-mono text-purple-800">{formatCurrency((totalExpenses + desiredProfit) / 30)}</td>
                    <td className="py-2 px-4 text-purple-900">Постоянные затраты + желаемая прибыль (фонд маржи)</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 font-semibold">Плановая маржинальность</td>
                    <td className="py-2 px-4 text-right font-mono font-bold text-emerald-700">{formatPercent(marginPercent)}</td>
                    <td className="py-2 px-4 text-right font-mono text-slate-600">—</td>
                    <td className="py-2 px-4 text-slate-600">Доля маржинального дохода в каждом рубле выручки</td>
                  </tr>
                  <tr className="bg-slate-100 font-bold border-t-2 border-slate-300">
                    <td className="py-2.5 px-4 uppercase font-mono">ИТОГОВАЯ ЦЕЛЕВАЯ ВЫРУЧКА:</td>
                    <td className="py-2.5 px-4 text-right font-mono text-sm text-blue-900">{formatCurrency(requiredRevenue)}</td>
                    <td className="py-2.5 px-4 text-right font-mono text-sm text-blue-900">{formatCurrency(requiredRevenue / 30)}</td>
                    <td className="py-2.5 px-4 text-xs font-semibold text-blue-950">Выручка для достижения целевой прибыли</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* 4. Блок 3: Сценарный анализ «Что если» (Стресс-тест изменения маржи) */}
          <div className="print-no-break space-y-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-600" />
              <h2 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-900">
                3. Сценарный анализ чувствительности «Что если» (Стресс-тест маржинальности)
              </h2>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                    <th className="py-2.5 px-4">Показатель финансовой модели</th>
                    <th className="py-2.5 px-4 text-right bg-blue-50/70 text-blue-950">
                      Базовый сценарий ({formatPercent(marginPercent)})
                    </th>
                    <th className="py-2.5 px-4 text-right bg-indigo-50/70 text-indigo-950">
                      Сценарий «Что если» ({formatPercent(whatIfMarginPercent)})
                    </th>
                    <th className="py-2.5 px-4 text-right">Разница (Δ ₽)</th>
                    <th className="py-2.5 px-4 text-right">Разница (Δ %)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  <tr>
                    <td className="py-2 px-4 font-semibold">Маржинальность продаж</td>
                    <td className="py-2 px-4 text-right font-mono font-bold text-blue-900">{formatPercent(marginPercent)}</td>
                    <td className="py-2 px-4 text-right font-mono font-bold text-indigo-900">{formatPercent(whatIfMarginPercent)}</td>
                    <td className="py-2 px-4 text-right font-mono font-bold text-slate-700">
                      {(whatIfMarginPercent - marginPercent) > 0 ? `+${(whatIfMarginPercent - marginPercent).toFixed(1)}%` : `${(whatIfMarginPercent - marginPercent).toFixed(1)}%`}
                    </td>
                    <td className="py-2 px-4 text-right font-mono text-slate-500">—</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 font-semibold">Точка Безубыточности (в месяц)</td>
                    <td className="py-2 px-4 text-right font-mono font-bold text-blue-900">{formatCurrency(breakEvenPoint)}</td>
                    <td className="py-2 px-4 text-right font-mono font-bold text-indigo-900">{formatCurrency(whatIfBreakEvenPoint)}</td>
                    <td className={`py-2 px-4 text-right font-mono font-bold ${diffBEP > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                      {diffBEP > 0 ? `+${formatCurrency(diffBEP)}` : formatCurrency(diffBEP)}
                    </td>
                    <td className={`py-2 px-4 text-right font-mono font-bold ${diffBEPPercent > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                      {diffBEPPercent > 0 ? `+${diffBEPPercent.toFixed(1)}%` : `${diffBEPPercent.toFixed(1)}%`}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 font-semibold">Суточная норма ТБ (в день)</td>
                    <td className="py-2 px-4 text-right font-mono text-slate-700">{formatCurrency(breakEvenPoint / 30)}</td>
                    <td className="py-2 px-4 text-right font-mono text-slate-700">{formatCurrency(whatIfBreakEvenPoint / 30)}</td>
                    <td className={`py-2 px-4 text-right font-mono ${diffBEP > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                      {diffBEP > 0 ? `+${formatCurrency(diffBEP / 30)}` : formatCurrency(diffBEP / 30)}
                    </td>
                    <td className="py-2 px-4 text-right font-mono text-slate-500">{diffBEPPercent > 0 ? `+${diffBEPPercent.toFixed(1)}%` : `${diffBEPPercent.toFixed(1)}%`}</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-4 font-semibold">Целевая выручка (с прибылью {formatCurrency(desiredProfit)})</td>
                    <td className="py-2 px-4 text-right font-mono font-bold text-blue-900">{formatCurrency(requiredRevenue)}</td>
                    <td className="py-2 px-4 text-right font-mono font-bold text-indigo-900">{formatCurrency(whatIfRequiredRevenue)}</td>
                    <td className={`py-2 px-4 text-right font-mono font-bold ${diffRevenue > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                      {diffRevenue > 0 ? `+${formatCurrency(diffRevenue)}` : formatCurrency(diffRevenue)}
                    </td>
                    <td className={`py-2 px-4 text-right font-mono font-bold ${diffRevenuePercent > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                      {diffRevenuePercent > 0 ? `+${diffRevenuePercent.toFixed(1)}%` : `${diffRevenuePercent.toFixed(1)}%`}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Stress test explanation summary */}
            <div className="p-3 rounded-xl bg-indigo-50/60 border border-indigo-200 text-xs text-indigo-950 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-indigo-700 shrink-0 mt-0.5" />
              <div>
                <strong>Вывод сценарного анализа: </strong>
                {whatIfMarginPercent < marginPercent ? (
                  <span>
                    При снижении маржинальности с {formatPercent(marginPercent)} до {formatPercent(whatIfMarginPercent)} порог безубыточности бизнеса увеличивается на <strong>{formatCurrency(diffBEP)} (+{diffBEPPercent.toFixed(1)}%)</strong>. Чтобы сохранить целевую прибыль {formatCurrency(desiredProfit)}, компании потребуется делать дополнительно <strong>{formatCurrency(diffRevenue)}</strong> выручки в месяц.
                  </span>
                ) : (
                  <span>
                    При увеличении маржинальности с {formatPercent(marginPercent)} до {formatPercent(whatIfMarginPercent)} порог безубыточности снижается на <strong>{formatCurrency(Math.abs(diffBEP))} ({Math.abs(diffBEPPercent).toFixed(1)}%)</strong>, существенно снижая финансовые риски бизнеса.
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* 5. Блок 4: Структура постоянных расходов по категориям */}
          <div className="print-no-break space-y-3">
            <div className="flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-teal-600" />
              <h2 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-900">
                4. Структура постоянных затрат по категориям
              </h2>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                    <th className="py-2.5 px-4">Категория затрат</th>
                    <th className="py-2.5 px-4 text-center w-28">Статей</th>
                    <th className="py-2.5 px-4 text-right">Сумма в месяц (₽)</th>
                    <th className="py-2.5 px-4 text-right w-24">Доля (%)</th>
                    <th className="py-2.5 px-4">Визуальное распределение</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  {categoryStats.map((cat) => (
                    <tr key={cat.id}>
                      <td className="py-2 px-4 font-semibold flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: cat.color }} />
                        <span>{cat.label}</span>
                      </td>
                      <td className="py-2 px-4 text-center font-mono text-slate-600">{cat.count}</td>
                      <td className="py-2 px-4 text-right font-mono font-bold">{formatCurrency(cat.total)}</td>
                      <td className="py-2 px-4 text-right font-mono font-bold text-slate-700">{cat.percent.toFixed(1)}%</td>
                      <td className="py-2 px-4">
                        <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${Math.min(100, Math.max(2, cat.percent))}%`,
                              backgroundColor: cat.color,
                            }}
                          />
                        </div>
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-slate-100 font-bold border-t-2 border-slate-300">
                    <td className="py-2.5 px-4 uppercase font-mono">ИТОГО ПО ВСЕМ КАТЕГОРИЯМ:</td>
                    <td className="py-2.5 px-4 text-center font-mono">{expenses.filter((e) => Number(e.amount) > 0).length}</td>
                    <td className="py-2.5 px-4 text-right font-mono text-sm text-blue-900">{formatCurrency(totalExpenses)}</td>
                    <td className="py-2.5 px-4 text-right font-mono font-bold text-blue-900">100.0%</td>
                    <td></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* 6. Блок 5: Полный реестр постоянных затрат (Все статьи) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-600" />
                <h2 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-900">
                  5. Полный реестр постоянных расходов ({expenses.length} позиций)
                </h2>
              </div>
              <span className="text-xs font-mono text-slate-500">
                Итого: {formatCurrency(totalExpenses)}
              </span>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                    <th className="py-2.5 px-3 w-10 text-center">№</th>
                    <th className="py-2.5 px-3">Наименование статьи расходов</th>
                    <th className="py-2.5 px-3">Категория</th>
                    <th className="py-2.5 px-3 text-right">Сумма (₽/мес)</th>
                    <th className="py-2.5 px-3 text-right w-20">Доля</th>
                    <th className="py-2.5 px-3">Комментарий / Назначение</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  {expenses.map((item) => {
                    const catInfo = CATEGORIES[item.category] || CATEGORIES.other;
                    const itemShare = totalExpenses > 0 ? ((Number(item.amount) || 0) / totalExpenses) * 100 : 0;
                    return (
                      <tr key={item.id} className="hover:bg-slate-50">
                        <td className="py-2 px-3 text-center text-slate-500 font-mono">{item.number}</td>
                        <td className="py-2 px-3 font-semibold text-slate-900">{item.name}</td>
                        <td className="py-2 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                            {catInfo.label}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">
                          {formatCurrency(item.amount)}
                        </td>
                        <td className="py-2 px-3 text-right font-mono text-slate-600 text-[11px]">
                          {itemShare.toFixed(1)}%
                        </td>
                        <td className="py-2 px-3 text-slate-600 text-[11px]">
                          {item.comment || '—'}
                        </td>
                      </tr>
                    );
                  })}
                  <tr className="bg-slate-100 font-black text-xs sm:text-sm border-t-2 border-slate-300">
                    <td colSpan={3} className="py-2.5 px-3 text-right uppercase font-mono">ИТОГО ПОСТОЯННЫХ ЗАТРАТ:</td>
                    <td className="py-2.5 px-3 text-right text-blue-900 font-mono">{formatCurrency(totalExpenses)}</td>
                    <td className="py-2.5 px-3 text-right font-mono text-blue-900">100.0%</td>
                    <td></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* 7. Блок 6: Аналитические выводы и рекомендации для собственника */}
          <div className="print-no-break space-y-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <h2 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-900">
                6. Финансовые выводы и рекомендации модели
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                <div className="font-bold text-slate-900 font-mono text-[11px] uppercase">
                  1. Безубыточный минимум (ТБ)
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  Бизнес начинает генерировать чистую прибыль только после преодоления планки выручки в <strong>{formatCurrency(breakEvenPoint)}</strong> в месяц (или <strong>{formatCurrency(breakEvenPoint / 30)}</strong> в день).
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                <div className="font-bold text-slate-900 font-mono text-[11px] uppercase">
                  2. Чувствительность к марже
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  При маржинальности <strong>{formatPercent(marginPercent)}</strong> для получения прибыли <strong>{formatCurrency(desiredProfit)}</strong> необходима выручка <strong>{formatCurrency(requiredRevenue)}</strong>. Изменение маржи на 1% меняет ТБ на 4%.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                <div className="font-bold text-slate-900 font-mono text-[11px] uppercase">
                  3. Ключевые статьи расходов
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  ТОП-3 статьи расходов: {topExpenses.map((t) => `${t.name} (${formatCurrency(t.amount)})`).join(', ') || 'не указаны'}. Они формируют основной финансовый риск компании.
                </p>
              </div>
            </div>
          </div>

          {/* 8. Signatures and Approval Footer */}
          <div className="print-no-break pt-6 border-t-2 border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs text-slate-600">
            <div className="space-y-2">
              <div className="font-bold text-slate-900 font-mono">Составитель отчёта:</div>
              <div className="text-slate-700">PROFIT SYSTEM — Сервис сквозного финансового планирования</div>
              <div className="text-slate-500 font-mono text-[11px]">https://profit-system.ru</div>
            </div>

            <div className="space-y-4 sm:text-right">
              <div className="font-bold text-slate-900 font-mono">Утверждение руководителем:</div>
              <div className="pt-4 border-b border-slate-400 inline-block w-64 text-left text-[10px] text-slate-400">
                Подпись / Расшифровка
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
