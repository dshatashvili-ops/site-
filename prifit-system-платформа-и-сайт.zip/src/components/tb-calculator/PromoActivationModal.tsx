import React, { useEffect } from 'react';
import { Flame, CheckCircle2, AlertTriangle, X, Zap } from 'lucide-react';

interface PromoActivationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmPromo: () => void;
  onRequestSubscription: () => void;
}

export const PromoActivationModal: React.FC<PromoActivationModalProps> = ({
  isOpen,
  onClose,
  onConfirmPromo,
  onRequestSubscription,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 md:p-8 bg-slate-950/85 backdrop-blur-md overflow-y-auto overscroll-contain animate-in fade-in duration-150"
    >
      <div className="relative bg-slate-900 text-white rounded-2xl sm:rounded-3xl max-w-lg w-full my-auto flex flex-col border border-amber-500/30 shadow-2xl max-h-[calc(100vh-1.5rem)] sm:max-h-[calc(100vh-3rem)] overflow-hidden">
        {/* Glow background accent */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-4 sm:p-6 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 flex items-center justify-between gap-4 z-20 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/20 shrink-0">
              <Flame className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="text-[11px] font-mono font-bold text-amber-400 uppercase tracking-wider">
                БЕСПЛАТНЫЙ ТЕСТОВЫЙ ДОСТУП
              </div>
              <h3 className="text-base sm:text-lg font-bold font-brand text-white leading-tight">
                Активация Промо на 24 часа
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 cursor-pointer transition-colors shrink-0"
            title="Закрыть (Esc)"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="overflow-y-auto p-5 sm:p-8 flex-1 space-y-6">
          {/* What is included */}
          <div className="space-y-3">
            <p className="text-xs sm:text-sm text-slate-300">
              Вам открывается <strong>ПОЛНЫЙ функционал</strong> веб-расчёта Точки Безубыточности PROFIT SYSTEM без каких-либо ограничений:
            </p>

            <ul className="space-y-2.5 text-xs sm:text-sm text-slate-200">
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Неограниченное количество постоянных статей расходов</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Полный экспорт всех расчетов и формул в Excel (.xlsx)</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Генерация и печать готовых PDF-отчётов финансовой модели</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Анализ сценариев «Что если» при изменении маржинальности</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Загрузка собственных Excel-реестров постоянных затрат</span>
              </li>
            </ul>
          </div>

          {/* Mandatory Warning Box */}
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs leading-relaxed space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-amber-300">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>ВАЖНОЕ ПРЕДУПРЕЖДЕНИЕ:</span>
            </div>
            <p>
              Промо-доступ предоставляется ровно на <strong>24 часа</strong>. По истечении 24 часов полные PRO-функции заблокируются и инструмент перейдёт в демо-режим.
            </p>
            <p className="text-amber-200">
              Для бессрочного использования полных функций доступна подписка по цене <strong>5 900 ₽/месяц</strong>.
            </p>
            <p className="text-blue-300 pt-1 font-medium">
              💡 <strong>Выгодная альтернатива:</strong> Полный бессрочный доступ к ТБ без ежемесячной подписки входит в состав комплексного <strong>Продукта 04 (Система управления прибылью)</strong>.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2.5 pt-2">
            <button
              onClick={onConfirmPromo}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-sm shadow-xl shadow-amber-500/20 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4 fill-current" />
              <span>Да, активировать 24 часа бесплатно!</span>
            </button>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
              <span>Карта не требуется</span>
              <button
                onClick={() => {
                  onClose();
                  onRequestSubscription();
                }}
                className="text-amber-400 hover:underline cursor-pointer"
              >
                Сразу оформить подписку за 5 900 ₽
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
