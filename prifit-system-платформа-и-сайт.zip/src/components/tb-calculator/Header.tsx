import React from 'react';
import { HelpCircle, ArrowLeft, Flame, ShieldCheck, PlayCircle, BookOpen, ArrowRight, Sparkles } from 'lucide-react';
import { TbAccessMode } from '../../types';

interface HeaderProps {
  accessMode: TbAccessMode;
  promoTimeRemainingFormatted?: string;
  onOpenVideoGuide: (tab?: 'video' | 'methodology') => void;
  onRequestPromo: () => void;
  onRequestSubscription: () => void;
  onBackToLanding: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  accessMode,
  promoTimeRemainingFormatted,
  onOpenVideoGuide,
  onRequestPromo,
  onRequestSubscription,
  onBackToLanding,
}) => {
  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-40 shadow-lg">
      <div className="max-w-[1600px] w-full mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Brand & Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToLanding}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center gap-2 text-xs font-bold"
            title="Вернуться на главный сайт"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">На сайт</span>
          </button>

          <div className="h-6 w-px bg-slate-800 hidden sm:block" />

          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold font-brand tracking-tight text-white text-base sm:text-lg">
                PROFIT SYSTEM
              </span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-500/20 border border-blue-500/30 text-blue-400 uppercase">
                Расчет точки безубыточности
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Интерактивный финансовый дешборд планирования прибыли и расходов
            </p>
          </div>
        </div>

        {/* Center/Right: Access Status Badge & Promo Actions */}
        <div className="flex items-center gap-2 sm:gap-3 ml-auto">
          {/* Main Bar Button: Video Guide */}
          <button
            onClick={() => onOpenVideoGuide('video')}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-xs shadow-md shadow-red-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Смотреть видеоинструкцию"
          >
            <PlayCircle className="w-4 h-4 fill-current text-white shrink-0" />
            <span className="hidden sm:inline">Видеоинструкция</span>
          </button>

          {/* Main Bar Button: Methodology */}
          <button
            onClick={() => onOpenVideoGuide('methodology')}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
            title="Методология расчёта"
          >
            <BookOpen className="w-4 h-4 text-blue-400 shrink-0" />
            <span className="hidden md:inline">? Справка</span>
          </button>

          {/* Access status badge */}
          {accessMode === 'demo' && (
            <button
              onClick={onRequestPromo}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer animate-pulse"
            >
              <Flame className="w-4 h-4 fill-current text-slate-950" />
              <span>Бесплатно 24 часа!</span>
            </button>
          )}

          {accessMode === 'promo_24h' && (
            <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Промо 24ч: {promoTimeRemainingFormatted || '23:59:59'}</span>
              <button
                onClick={onRequestSubscription}
                className="text-[10px] text-slate-300 underline hover:text-white cursor-pointer ml-1"
              >
                Продлить (5 900 ₽/мес)
              </button>
            </div>
          )}

          {accessMode === 'paid_subscription' && (
            <div className="px-3 py-1.5 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 font-mono text-xs font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span>ПОЛНЫЙ ДОСТУП</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
