import React, { useMemo, useState } from 'react';
import { PieChart as PieIcon } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { ExpenseItem } from '../../types';
import { CATEGORIES } from '../../data/initialData';
import { formatCurrency } from '../../utils/formatters';

interface ExpenseChartCardProps {
  expenses: ExpenseItem[];
  totalExpenses: number;
}

export const ExpenseChartCard: React.FC<ExpenseChartCardProps> = React.memo(({ expenses, totalExpenses }) => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  // Group expenses by category with useMemo for fast instant recalculation
  const chartData = useMemo(() => {
    const categoryTotals: Record<string, number> = {};
    
    for (let i = 0; i < expenses.length; i++) {
      const item = expenses[i];
      const cat = item.category || 'other';
      const amt = Number(item.amount) || 0;
      categoryTotals[cat] = (categoryTotals[cat] || 0) + amt;
    }

    return Object.entries(categoryTotals)
      .filter(([_, value]) => Number(value) > 0)
      .map(([catKey, value]) => {
        const catInfo = CATEGORIES[catKey as keyof typeof CATEGORIES] || CATEGORIES.other;
        const numericVal = Number(value) || 0;
        const percent = totalExpenses > 0 ? (numericVal / totalExpenses) * 100 : 0;
        return {
          id: catKey,
          name: catInfo.label,
          value: numericVal,
          color: catInfo.color,
          percent: Math.round(percent),
        };
      })
      .sort((a, b) => b.value - a.value);
  }, [expenses, totalExpenses]);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-500/10 flex items-center justify-center text-teal-600 dark:text-teal-400">
            <PieIcon className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-sm uppercase tracking-tight font-brand">
            СТРУКТУРА ПОСТОЯННЫХ РАСХОДОВ
          </h3>
        </div>
        {totalExpenses > 0 && (
          <span className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400">
            {formatCurrency(totalExpenses)}
          </span>
        )}
      </div>

      {chartData.length > 0 ? (
        <div className="space-y-4">
          <div className="h-48 w-full relative">
            <ResponsiveContainer width="100%" height={192} minWidth={100} minHeight={192}>
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={78}
                  paddingAngle={3}
                  dataKey="value"
                  isAnimationActive={false} // Instant 0ms loading without slow 1.5s lag
                  onMouseEnter={(_, index) => setActiveIndex(index)}
                  onMouseLeave={() => setActiveIndex(null)}
                >
                  {chartData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.color}
                      stroke={activeIndex === index ? '#ffffff' : 'transparent'}
                      strokeWidth={2}
                      className="cursor-pointer transition-all duration-150"
                    />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: any) => [formatCurrency(Number(value) || 0), 'Сумма']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    color: '#f8fafc',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-1 gap-1.5 text-xs max-h-48 overflow-y-auto pr-1">
            {chartData.map((item, idx) => (
              <div
                key={item.id || idx}
                onMouseEnter={() => setActiveIndex(idx)}
                onMouseLeave={() => setActiveIndex(null)}
                className={`flex items-center justify-between p-1 rounded-lg transition-colors cursor-pointer ${
                  activeIndex === idx
                    ? 'bg-slate-100 dark:bg-slate-800'
                    : 'text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2 overflow-hidden">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <span className="truncate text-[11px] font-medium">{item.name}</span>
                </div>
                <div className="font-mono text-[11px] font-bold shrink-0 ml-2">
                  {formatCurrency(item.value)} ({item.percent}%)
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="py-8 text-center text-xs text-slate-400">
          Нет данных по расходам для отображения графика
        </div>
      )}
    </div>
  );
});

ExpenseChartCard.displayName = 'ExpenseChartCard';

