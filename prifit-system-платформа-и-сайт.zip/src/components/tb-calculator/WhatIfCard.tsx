import React from 'react';
import { Sliders, Lock, TrendingDown, ArrowRight } from 'lucide-react';
import { formatCurrency, formatPercent } from '../../utils/formatters';
import { TbAccessMode } from '../../types';

interface WhatIfCardProps {
  totalExpenses: number;
  whatIfMarginPercent: number;
  accessMode: TbAccessMode;
  onUpdateWhatIfMargin: (val: number) => void;
  onRequestPromo: () => void;
}

export const WhatIfCard: React.FC<WhatIfCardProps> = ({
  totalExpenses,
  whatIfMarginPercent,
  accessMode,
  onUpdateWhatIfMargin,
  onRequestPromo,
}) => {
  const isDemo = accessMode === 'demo';

  const whatIfBreakEven = whatIfMarginPercent > 0 ? totalExpenses / (whatIfMarginPercent / 100) : 0;

  const handleMarginChange = (val: number) => {
    const clamped = Math.min(99, Math.max(1, val));
    if (isDemo) {
      onRequestPromo();
    }
    onUpdateWhatIfMargin(clamped);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4 relative overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center text-amber-600 dark:text-amber-400">
            <Sliders className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-sm uppercase tracking-tight font-brand">
            АНАЛИЗ СЦЕНАРИЕВ «ЧТО ЕСЛИ»
          </h3>
        </div>
        {isDemo && (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 font-bold flex items-center gap-1">
            <Lock className="w-3 h-3" /> PRO Сценарии
          </span>
        )}
      </div>

      {/* Main Sensitivity Analysis Block - Fully Visible in Demo */}
      <div className="space-y-4">
        <p className="text-xs text-slate-600 dark:text-slate-400">
          Стресс-тест моделирование: какая потребуется выручка, если маржинальность снизится (акции, скидки, рост комиссии маркетплейса)?
        </p>

        {/* Input & Value */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
            <span>Альтернативная маржинальность:</span>
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1">
              <input
                type="number"
                min={1}
                max={99}
                step={0.1}
                value={whatIfMarginPercent}
                onChange={(e) => handleMarginChange(parseFloat(e.target.value) || 1)}
                className="w-16 text-right font-black text-amber-600 dark:text-amber-400 font-mono text-base bg-transparent focus:outline-none"
              />
              <span className="text-amber-600 dark:text-amber-400 font-bold">%</span>
            </div>
          </div>

          <input
            type="range"
            min={1}
            max={99}
            step={1}
            value={whatIfMarginPercent}
            onChange={(e) => handleMarginChange(parseFloat(e.target.value) || 1)}
            className="w-full h-2.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
          />

          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-0.5">
            <span>1%</span>
            <span>15%</span>
            <span>30%</span>
            <span>50%</span>
            <span>99%</span>
          </div>
        </div>

        {/* Calculated New Break-Even Box */}
        <div className="p-3.5 bg-amber-50/80 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/40 flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold text-amber-800 dark:text-amber-300 uppercase font-mono">
              НОВАЯ ТОЧКА БЕЗУБЫТОЧНОСТИ
            </div>
            <div className="text-xl font-black text-amber-900 dark:text-amber-200 mt-0.5">
              {formatCurrency(whatIfBreakEven)}
            </div>
          </div>
          <div className="p-2 rounded-lg bg-amber-500/20 text-amber-700 dark:text-amber-300">
            <TrendingDown className="w-5 h-5" />
          </div>
        </div>

        {/* Demo Mode Button Footer */}
        {isDemo && (
          <div className="pt-2">
            <button
              onClick={onRequestPromo}
              className="w-full py-2 px-3 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-700 dark:text-amber-300 font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Разблокировать полную сценарную модель (Промо 24ч)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
