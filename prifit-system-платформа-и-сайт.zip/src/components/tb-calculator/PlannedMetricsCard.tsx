import React from 'react';
import { Target, TrendingUp, Info } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface PlannedMetricsCardProps {
  desiredProfit: number;
  marginPercent: number;
  totalExpenses: number;
  onUpdateDesiredProfit: (val: number) => void;
}

export const PlannedMetricsCard: React.FC<PlannedMetricsCardProps> = ({
  desiredProfit,
  marginPercent,
  totalExpenses,
  onUpdateDesiredProfit,
}) => {
  const requiredMarginIncome = totalExpenses + desiredProfit;
  const requiredRevenue = marginPercent > 0 ? requiredMarginIncome / (marginPercent / 100) : 0;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
      <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="w-8 h-8 rounded-lg bg-purple-50 dark:bg-purple-500/10 flex items-center justify-center text-purple-600 dark:text-purple-400">
          <Target className="w-5 h-5" />
        </div>
        <h3 className="font-bold text-slate-900 dark:text-white text-sm uppercase tracking-tight font-brand">
          ПЛАНИРУЕМЫЕ ПОКАЗАТЕЛИ ПРИБЫЛИ
        </h3>
      </div>

      {/* Input Target Profit */}
      <div className="space-y-1.5">
        <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between">
          <span>Желаемая чистая прибыль в месяц:</span>
          <span className="font-bold text-purple-600 dark:text-purple-400">{formatCurrency(desiredProfit)}</span>
        </label>
        <div className="relative">
          <input
            type="number"
            step={50000}
            min={0}
            value={desiredProfit}
            onChange={(e) => onUpdateDesiredProfit(parseFloat(e.target.value) || 0)}
            className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {/* Summary outputs */}
      <div className="grid grid-cols-2 gap-3 pt-2">
        <div className="p-3 bg-purple-50/60 dark:bg-purple-950/40 rounded-lg border border-purple-100 dark:border-purple-900/40">
          <div className="text-[10px] font-bold text-purple-700 dark:text-purple-300 uppercase font-mono">
            НЕОБХОДИМАЯ МАРЖА
          </div>
          <div className="text-base font-black text-purple-900 dark:text-purple-200 mt-1">
            {formatCurrency(requiredMarginIncome)}
          </div>
          <div className="text-[10px] text-purple-600 dark:text-purple-400 mt-0.5">Расходы + Прибыль</div>
        </div>

        <div className="p-3 bg-blue-50/60 dark:bg-blue-950/40 rounded-lg border border-blue-100 dark:border-blue-900/40">
          <div className="text-[10px] font-bold text-blue-700 dark:text-blue-300 uppercase font-mono">
            НЕОБХОДИМАЯ ВЫРУЧКА
          </div>
          <div className="text-base font-black text-blue-900 dark:text-blue-200 mt-1">
            {formatCurrency(requiredRevenue)}
          </div>
          <div className="text-[10px] text-blue-600 dark:text-blue-400 mt-0.5">При марже {marginPercent}%</div>
        </div>
      </div>
    </div>
  );
};
