import React, { useState, useEffect } from 'react';
import { X, Play, BookOpen, CheckCircle2, Youtube, AlertCircle, FileText, Check } from 'lucide-react';

interface VideoGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'video' | 'methodology';
}

export const VideoGuideModal: React.FC<VideoGuideModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'methodology',
}) => {
  const [activeTab, setActiveTab] = useState<'video' | 'methodology'>(defaultTab);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(defaultTab);
    }
  }, [isOpen, defaultTab]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 md:p-8 bg-slate-950/85 backdrop-blur-md overflow-y-auto overscroll-contain animate-in fade-in duration-150"
    >
      <div className="relative bg-slate-900 text-white rounded-2xl sm:rounded-3xl max-w-3xl w-full my-auto flex flex-col border border-slate-800 shadow-2xl max-h-[calc(100vh-1.5rem)] sm:max-h-[calc(100vh-3rem)] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-6 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 flex items-center justify-between gap-4 z-20 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg font-brand">Инструкция & Методология ТБ</h3>
              <p className="text-xs text-slate-400">Правила расчёта Точки Безубыточности и финансовой модели</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 cursor-pointer transition-colors shrink-0"
            title="Закрыть (Esc)"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body content */}
        <div className="overflow-y-auto p-5 sm:p-8 flex-1 space-y-6">
          {/* Tab Switcher */}
          <div className="flex items-center gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('methodology')}
              className={`flex-1 py-2 rounded-lg font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'methodology'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Методология ТБ (Документация)</span>
            </button>
            <button
              onClick={() => setActiveTab('video')}
              className={`flex-1 py-2 rounded-lg font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'video'
                  ? 'bg-red-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Youtube className="w-4 h-4" />
              <span>Видеообзор и разбор</span>
            </button>
          </div>

        {/* Tab Content: Video */}
        {activeTab === 'video' && (
          <div className="space-y-4">
            <div className="relative aspect-video rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div className="w-16 h-16 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-lg hover:scale-105 transition-transform cursor-pointer">
                <Play className="w-8 h-8 ml-1 fill-current" />
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Видеоинструкция по калькулятору ТБ</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Наглядный видеоурок: заполнение 27 статей расходов, связка с unit-экономикой маркетплейсов и сценарный анализ «Что если».
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-400 text-center font-mono">
              ⏱ Длительность разбора: ~7 минут &bull; Автор: PROFIT SYSTEM
            </p>
          </div>
        )}

        {/* Tab Content: Methodology */}
        {activeTab === 'methodology' && (
          <div className="space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
            {/* Core definition */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h4 className="font-bold text-white text-sm flex items-center gap-2 text-blue-400">
                <BookOpen className="w-4 h-4" />
                Что такое Точка Безубыточности (ТБ)?
              </h4>
              <p className="text-slate-300 text-xs">
                Точка Безубыточности — это объём выручки, при котором чистая прибыль бизнеса равна строго нулю (0 ₽). При достижении ТБ компания полностью окупает все фиксированные ежемесячные расходы (аренду, ФОТ, связь, сервисы), но ещё не получает чистой прибыли.
              </p>
            </div>

            {/* 3 Core Blocks */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 font-mono">
                3 Основных Блока Расчёта в Системе
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Block 1 */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="px-2 py-0.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded text-[10px] font-mono font-bold w-fit">
                    01. ТОЧКА БЕЗУБЫТОЧНОСТИ
                  </div>
                  <h4 className="font-bold text-white text-xs">Минимальная выручка</h4>
                  <p className="text-[11px] text-slate-400">
                    Рассчитывает абсолютный финансовый порог выживаемости бизнеса.
                  </p>
                  <div className="p-2 bg-slate-900 rounded border border-slate-800 text-[10px] font-mono text-blue-300">
                    Постоянные расходы ÷ Маржинальность %
                  </div>
                </div>

                {/* Block 2 */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="px-2 py-0.5 bg-purple-500/20 text-purple-400 border border-purple-500/30 rounded text-[10px] font-mono font-bold w-fit">
                    02. ПЛАНОВЫЕ ПОКАЗАТЕЛИ
                  </div>
                  <h4 className="font-bold text-white text-xs">Целевая выручка</h4>
                  <p className="text-[11px] text-slate-400">
                    Показывает выручку под заданный ориентир желаемой чистой прибыли.
                  </p>
                  <div className="p-2 bg-slate-900 rounded border border-slate-800 text-[10px] font-mono text-purple-300">
                    (Расходы + Прибыль) ÷ Маржинальность %
                  </div>
                </div>

                {/* Block 3 */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="px-2 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded text-[10px] font-mono font-bold w-fit">
                    03. АНАЛИЗ «ЧТО ЕСЛИ»
                  </div>
                  <h4 className="font-bold text-white text-xs">Сценарный анализ</h4>
                  <p className="text-[11px] text-slate-400">
                    Стресс-тест при падении маржинальности или росте комиссии WB/Ozon.
                  </p>
                  <div className="p-2 bg-slate-900 rounded border border-slate-800 text-[10px] font-mono text-amber-300">
                    Моделирование новой ТБ
                  </div>
                </div>
              </div>
            </div>

            {/* CRITICAL TAX METHODOLOGY EXPLANATION */}
            <div className="p-4 bg-amber-950/40 rounded-xl border border-amber-500/40 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs sm:text-sm">
                <AlertCircle className="w-5 h-5 shrink-0 text-amber-400" />
                <span>ВАЖНО: ПОЧЕМУ В ТБ НЕТ ОТДЕЛЬНОЙ СТРОКИ «НАЛОГИ» (ЭТО НЕ ОШИБКА)</span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">
                В постоянных расходах отдельная статья «Налоги» не предусмотрена, потому что налог уже учитывается в unit-экономике на листе «Расчёт ВБ». Маржинальность, используемая в ТБ, берётся из этой экономики. Повторное добавление налогов в постоянные расходы может привести к двойному учёту налоговой нагрузки и исказить расчёт точки безубыточности.
              </p>
              <div className="p-3 bg-slate-950/80 rounded border border-amber-500/30 text-[11px] font-mono text-amber-200">
                Логика системы: «Расчёт ВБ» учитывает налог в структуре расходов → формируется маржинальность → ТБ использует эту маржинальность вместе с постоянными расходами → рассчитывается финансовый порог.
              </div>
            </div>

            {/* 5 Steps to work */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 font-mono">
                Как работать с ТБ (5 простых шагов)
              </h3>
              <ol className="space-y-2 text-xs text-slate-300 list-decimal list-inside">
                <li><strong>Введите постоянные расходы:</strong> Укажите ежемесячные суммы по 27 статьям расходов.</li>
                <li><strong>Проверьте маржинальность:</strong> Укажите маржинальность бизнеса (% от выручки).</li>
                <li><strong>Рассчитайте ТБ:</strong> Нажмите «РАССЧИТАТЬ» для получения точки безубыточности.</li>
                <li><strong>Сформируйте план:</strong> Задайте желаемую прибыль и узнайте необходимую плановую выручку.</li>
                <li><strong>Проведите сценарный анализ:</strong> Задайте альтернативную маржинальность в блоке «Что если».</li>
              </ol>
            </div>

            {/* What TB gives manager */}
            <div className="p-4 bg-gradient-to-br from-blue-950/60 to-slate-950 rounded-xl border border-blue-500/30 space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 font-mono">
                Что даёт ТБ руководителю
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-blue-100">
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400 shrink-0" /> Понимание минимальной выручки для выхода в ноль</div>
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400 shrink-0" /> Планирование выручки под конкретную цель по прибыли</div>
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400 shrink-0" /> Оценка чувствительности бизнеса к изменению маржинальности</div>
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400 shrink-0" /> Быстрое сравнение базового и альтернативного сценария</div>
              </div>
            </div>

            {/* Product 04 note */}
            <div className="p-3 bg-blue-950/40 rounded-xl border border-blue-500/30 text-xs text-blue-200 text-center font-medium">
              💡 <strong>Обратите внимание:</strong> Полный бессрочный функционал ТБ без ежемесячной подписки навсегда входит в комплексный <strong>Продукт 04 (Система управления прибылью)</strong>.
            </div>
          </div>
        )}
        </div>

        {/* Footer Button */}
        <div className="p-4 sm:p-5 bg-slate-900 border-t border-slate-800 flex justify-end z-20 shrink-0">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
          >
            Понятно, к расчёту
          </button>
        </div>
      </div>
    </div>
  );
};
