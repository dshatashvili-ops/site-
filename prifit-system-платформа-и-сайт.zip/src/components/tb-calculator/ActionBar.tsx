import React from 'react';
import {
  Calculator,
  RotateCcw,
  Trash2,
  FileSpreadsheet,
  FileText,
  Lock,
} from 'lucide-react';
import { TbAccessMode } from '../../types';

interface ActionBarProps {
  accessMode: TbAccessMode;
  onCalculate: () => void;
  onClear: () => void;
  onClearAll: () => void;
  onExportExcel: () => void;
  onGenerateReport: () => void;
  onRequestPromo: () => void;
}

export const ActionBar: React.FC<ActionBarProps> = ({
  accessMode,
  onCalculate,
  onClear,
  onClearAll,
  onExportExcel,
  onGenerateReport,
  onRequestPromo,
}) => {
  const isDemo = accessMode === 'demo';

  const handleExportClick = () => {
    if (isDemo) {
      onRequestPromo();
      return;
    }
    onExportExcel();
  };

  const handleReportClick = () => {
    if (isDemo) {
      onRequestPromo();
      return;
    }
    onGenerateReport();
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-3 sm:p-4 shadow-sm border border-slate-200 dark:border-slate-800">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Left Group: Data Reset Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={onClear}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs transition-colors inline-flex items-center gap-1.5 cursor-pointer"
            title="Восстановить исходные данные"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Сбросить</span>
          </button>

          <button
            onClick={onClearAll}
            className="px-3 py-2 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 hover:bg-red-100 border border-red-200 dark:border-red-900/50 font-bold text-xs transition-colors inline-flex items-center gap-1.5 cursor-pointer"
            title="Обнулить все статьи расходов"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Очистить все</span>
          </button>
        </div>

        {/* Right Group: Export & Calculate */}
        <div className="flex flex-wrap items-center gap-2 ml-auto">
          {/* Excel Export */}
          <button
            onClick={handleExportClick}
            className={`px-3.5 py-2 rounded-xl font-bold text-xs transition-all inline-flex items-center gap-2 cursor-pointer ${
              isDemo
                ? 'bg-slate-100 dark:bg-slate-800 text-slate-500 border border-dashed border-slate-300 dark:border-slate-700'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Скачать Excel (.xlsx)</span>
            {isDemo && <Lock className="w-3.5 h-3.5 text-amber-500" />}
          </button>

          {/* Printable Report Modal */}
          <button
            onClick={handleReportClick}
            className={`px-3.5 py-2 rounded-xl font-bold text-xs transition-all inline-flex items-center gap-2 cursor-pointer ${
              isDemo
                ? 'bg-slate-100 dark:bg-slate-800 text-slate-500 border border-dashed border-slate-300 dark:border-slate-700'
                : 'bg-purple-600 hover:bg-purple-500 text-white shadow-md shadow-purple-600/20'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Печать PDF отчёта</span>
            {isDemo && <Lock className="w-3.5 h-3.5 text-amber-500" />}
          </button>

          {/* Primary Calculate Button */}
          <button
            onClick={onCalculate}
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-black text-xs sm:text-sm shadow-md shadow-blue-500/20 transition-all inline-flex items-center gap-2 cursor-pointer uppercase tracking-wider font-brand hover:scale-105 active:scale-95"
          >
            <Calculator className="w-4 h-4" />
            <span>Рассчитать</span>
          </button>
        </div>
      </div>
    </div>
  );
};

