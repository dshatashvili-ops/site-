import React, { useState, useMemo } from 'react';
import { Building2, Search, Plus, Trash2, Info, Lock } from 'lucide-react';
import { ExpenseItem, ExpenseCategory, TbAccessMode } from '../../types';
import { CATEGORIES } from '../../data/initialData';
import { formatCurrency } from '../../utils/formatters';

interface FixedExpensesTableProps {
  expenses: ExpenseItem[];
  totalExpenses: number;
  accessMode: TbAccessMode;
  onUpdateExpense: (id: string, field: keyof ExpenseItem, value: any) => void;
  onAddExpense: (partial: Partial<ExpenseItem>) => void;
  onDeleteExpense: (id: string) => void;
  onRequestPromo: () => void;
}

// Initial 5 article IDs allowed in demo mode
const DEMO_ALLOWED_IDS = ['1', '2', '3', '4', '5'];

export const FixedExpensesTable: React.FC<FixedExpensesTableProps> = ({
  expenses,
  totalExpenses,
  accessMode,
  onUpdateExpense,
  onAddExpense,
  onDeleteExpense,
  onRequestPromo,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const isDemo = accessMode === 'demo';

  // In demo mode, only show expenses whose ID was in the initial 5 set
  const visibleExpenses = useMemo(() => {
    if (isDemo) {
      return expenses.filter((item) => DEMO_ALLOWED_IDS.includes(item.id));
    }
    return expenses;
  }, [expenses, isDemo]);

  const hiddenCount = expenses.length - visibleExpenses.length;

  const filteredExpenses = visibleExpenses.filter(
    (item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.comment.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddNewRow = () => {
    if (isDemo) {
      onRequestPromo();
      return;
    }
    onAddExpense({
      name: 'Новая статья расходов',
      amount: 10000,
      comment: 'Примечание',
      category: 'other',
    });
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full">
      {/* Table Header Section */}
      <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-500/10 flex items-center justify-center text-blue-700 dark:text-blue-400">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base tracking-tight uppercase font-brand">
              ПОСТОЯННЫЕ РАСХОДЫ <span className="text-slate-500 font-normal text-xs font-sans">(ежемесячные)</span>
            </h2>
            {isDemo && (
              <span className="text-[11px] text-amber-600 dark:text-amber-400 font-mono font-medium flex items-center gap-1">
                <Lock className="w-3 h-3" /> Демо-режим: отображаются первые 5 статей ({visibleExpenses.length} из 27)
              </span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-400 uppercase font-mono">
            Итого расходов:
          </span>
          <span className="text-lg sm:text-xl font-black text-blue-900 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-3 py-1 rounded-md border border-blue-200 dark:border-blue-800 font-mono">
            {formatCurrency(totalExpenses)}
          </span>
        </div>
      </div>

      {/* Control Tools Bar */}
      <div className="px-4 py-2.5 bg-slate-50/80 dark:bg-slate-950/50 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-xs">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Поиск по расходам..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-800 dark:text-slate-200"
          />
        </div>
        <button
          onClick={handleAddNewRow}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-md font-bold text-xs transition-colors shadow-sm cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Добавить позицию</span>
        </button>
      </div>

      {/* Table Container */}
      <div className="overflow-x-auto flex-1 overflow-y-auto max-h-[1200px] min-h-[400px]">
        <table className="w-full text-left text-xs sm:text-sm border-collapse">
          <thead className="sticky top-0 bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-semibold border-b border-slate-200 dark:border-slate-700 z-10">
            <tr>
              <th className="py-2.5 px-3 w-12 text-center border-r border-slate-200 dark:border-slate-700 font-bold font-mono">№</th>
              <th className="py-2.5 px-3 min-w-[180px] border-r border-slate-200 dark:border-slate-700 font-bold">Статья расходов</th>
              <th className="py-2.5 px-3 w-36 text-right border-r border-slate-200 dark:border-slate-700 font-bold">Сумма, руб</th>
              <th className="py-2.5 px-3 min-w-[180px] border-r border-slate-200 dark:border-slate-700 font-bold">Комментарий</th>
              <th className="py-2.5 px-3 w-10 text-center font-bold"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredExpenses.map((item, idx) => (
              <tr
                key={item.id}
                className={`${
                  idx % 2 === 0 ? 'bg-white dark:bg-slate-900' : 'bg-slate-50/50 dark:bg-slate-950/40'
                } hover:bg-blue-50/40 dark:hover:bg-blue-950/40 transition-colors group`}
              >
                {/* Index */}
                <td className="py-2 px-3 text-center text-slate-500 dark:text-slate-400 font-mono text-xs border-r border-slate-100 dark:border-slate-800">
                  {item.number}
                </td>
                {/* Name */}
                <td className="py-1.5 px-3 border-r border-slate-100 dark:border-slate-800">
                  <input
                    type="text"
                    value={item.name}
                    onChange={(e) => onUpdateExpense(item.id, 'name', e.target.value)}
                    className="w-full bg-transparent px-2 py-1 rounded-sm border border-transparent hover:border-slate-300 dark:hover:border-slate-700 focus:border-blue-500 focus:bg-white dark:focus:bg-slate-800 text-slate-900 dark:text-white font-medium focus:outline-none transition-all"
                  />
                </td>
                {/* Amount */}
                <td className="py-1.5 px-3 border-r border-slate-100 dark:border-slate-800 text-right">
                  <input
                    type="number"
                    min={0}
                    step={500}
                    value={item.amount || ''}
                    onChange={(e) =>
                      onUpdateExpense(item.id, 'amount', parseFloat(e.target.value) || 0)
                    }
                    className="w-full text-right font-bold text-slate-900 dark:text-white bg-transparent px-2 py-1 rounded-sm border border-transparent hover:border-slate-300 dark:hover:border-slate-700 focus:border-blue-500 focus:bg-white dark:focus:bg-slate-800 focus:outline-none transition-all"
                  />
                </td>
                {/* Comment */}
                <td className="py-1.5 px-3 border-r border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={item.comment}
                      onChange={(e) => onUpdateExpense(item.id, 'comment', e.target.value)}
                      className="w-full bg-transparent px-2 py-1 rounded-sm border border-transparent hover:border-slate-300 dark:hover:border-slate-700 focus:border-blue-500 focus:bg-white dark:focus:bg-slate-800 text-slate-600 dark:text-slate-300 focus:outline-none transition-all"
                    />
                    <select
                      value={item.category}
                      onChange={(e) =>
                        onUpdateExpense(item.id, 'category', e.target.value as ExpenseCategory)
                      }
                      title="Категория расходов"
                      className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700 cursor-pointer focus:outline-none shrink-0"
                    >
                      {Object.values(CATEGORIES).map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </td>
                {/* Actions */}
                <td className="py-1.5 px-2 text-center">
                  <button
                    onClick={() => onDeleteExpense(item.id)}
                    title="Удалить статью"
                    className="p-1 text-slate-400 hover:text-red-600 rounded transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}

            {isDemo && hiddenCount > 0 && (
              <tr className="bg-amber-50/60 dark:bg-amber-950/30">
                <td colSpan={5} className="py-3 px-4 text-center">
                  <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-amber-800 dark:text-amber-300 font-medium">
                    <span className="flex items-center gap-1.5">
                      <Lock className="w-4 h-4 text-amber-600 shrink-0" />
                      Скрыто ещё {hiddenCount} статей расходов
                    </span>
                    <button
                      onClick={onRequestPromo}
                      className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-xs cursor-pointer transition-all hover:scale-105"
                    >
                      Разблокировать все 27 статей (Промо 24ч)
                    </button>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Info Notice Footer */}
      <div className="p-3 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
            <Info className="w-3.5 h-3.5" />
          </div>
          <span>Редактируйте суммы. Итог пересчитывается мгновенно.</span>
        </div>
      </div>
    </div>
  );
};
