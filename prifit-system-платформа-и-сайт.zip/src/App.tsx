import { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MarketplaceSelector } from './components/MarketplaceSelector';
import { TaskQuestionSelector } from './components/TaskQuestionSelector';
import { ProductLevels } from './components/ProductLevels';
import { BusinessEconomyChain } from './components/BusinessEconomyChain';
import { ResultsOutcomeSection } from './components/ResultsOutcomeSection';
import { InteractiveCalculator } from './components/InteractiveCalculator';
import { HowItWorks } from './components/HowItWorks';
import { ExpensesBreakdown } from './components/ExpensesBreakdown';
import { ComparisonTable } from './components/ComparisonTable';
import { ExcelSystemAdvantages } from './components/ExcelSystemAdvantages';
import { DemoBlock } from './components/DemoBlock';
import { KnowledgeBaseMedia } from './components/KnowledgeBaseMedia';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';

import { QuizModal } from './components/QuizModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { DemoDownloadModal } from './components/DemoDownloadModal';
import { CheckoutModal } from './components/CheckoutModal';

import { WildberriesLanding } from './components/WildberriesLanding';
import { OzonLanding } from './components/OzonLanding';
import { TbCalculatorApp } from './components/tb-calculator/TbCalculatorApp';

import { Marketplace, ProductLevel, ProductLevelId } from './types';
import { PRODUCT_LEVELS } from './data/content';

export default function App() {
  const [currentMarketplace, setCurrentMarketplace] = useState<Marketplace>('all');
  const [selectedProductDetail, setSelectedProductDetail] = useState<ProductLevel | null>(null);

  const [quizOpen, setQuizOpen] = useState(false);
  const [demoOpen, setDemoOpen] = useState(false);
  const [buyOpen, setBuyOpen] = useState(false);
  const [checkoutInitialProductId, setCheckoutInitialProductId] = useState('calc');
  const [isTbCalculatorOpen, setIsTbCalculatorOpen] = useState(false);

  const handleNavigateToSection = (sectionId: string) => {
    if (sectionId === 'hero' || sectionId === 'top' || !sectionId) {
      if (currentMarketplace !== 'all') {
        setCurrentMarketplace('all');
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenBuy = (productId?: string) => {
    if (productId) {
      setCheckoutInitialProductId(productId);
    }
    setBuyOpen(true);
  };

  const handleQuizSelectProduct = (productId: ProductLevelId) => {
    const prod = PRODUCT_LEVELS.find((p) => p.id === productId || p.levelCode === productId);
    if (prod) {
      setSelectedProductDetail(prod);
    } else {
      handleNavigateToSection('products');
    }
  };

  const handleSelectLevelCode = (levelCode: string) => {
    const prod = PRODUCT_LEVELS.find((p) => p.levelCode === levelCode);
    if (prod) {
      setSelectedProductDetail(prod);
    } else {
      handleNavigateToSection('products');
    }
  };

  // If TB Calculator active
  if (isTbCalculatorOpen) {
    return (
      <TbCalculatorApp
        onBackToLanding={() => setIsTbCalculatorOpen(false)}
        onNavigateToProduct04={() => {
          setIsTbCalculatorOpen(false);
          handleSelectLevelCode('04');
        }}
      />
    );
  }

  // Dedicated landing views for Wildberries or Ozon if specifically filtered
  if (currentMarketplace === 'wildberries') {
    return (
      <>
        <WildberriesLanding
          onBack={() => setCurrentMarketplace('all')}
          onOpenBuy={(pId) => handleOpenBuy(pId)}
          onOpenDemo={() => setDemoOpen(true)}
        />
        <DemoDownloadModal isOpen={demoOpen} onClose={() => setDemoOpen(false)} />
        <CheckoutModal
          isOpen={buyOpen}
          initialProductId={checkoutInitialProductId}
          onClose={() => setBuyOpen(false)}
        />
      </>
    );
  }

  if (currentMarketplace === 'ozon') {
    return (
      <>
        <OzonLanding
          onBack={() => setCurrentMarketplace('all')}
          onOpenBuy={(pId) => handleOpenBuy(pId)}
          onOpenDemo={() => setDemoOpen(true)}
        />
        <DemoDownloadModal isOpen={demoOpen} onClose={() => setDemoOpen(false)} />
        <CheckoutModal
          isOpen={buyOpen}
          initialProductId={checkoutInitialProductId}
          onClose={() => setBuyOpen(false)}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-blue-500 selection:text-white transition-colors duration-200">
      {/* Top Header */}
      <Header
        currentMarketplace={currentMarketplace}
        onSelectMarketplace={(m) => setCurrentMarketplace(m)}
        onOpenQuiz={() => setQuizOpen(true)}
        onOpenDemo={() => setDemoOpen(true)}
        onOpenBuy={(pId) => handleOpenBuy(pId)}
        onNavigateToSection={handleNavigateToSection}
        onOpenTbCalculator={() => setIsTbCalculatorOpen(true)}
      />

      {/* Hero Section */}
      <Hero
        onOpenDemo={() => setDemoOpen(true)}
        onOpenBuy={() => handleOpenBuy()}
        onNavigateToProducts={() => handleNavigateToSection('products')}
        onOpenTbCalculator={() => setIsTbCalculatorOpen(true)}
      />

      {/* Select Marketplace Section */}
      <MarketplaceSelector
        currentMarketplace={currentMarketplace}
        onSelectMarketplace={(m) => setCurrentMarketplace(m)}
        onNavigateToProducts={() => handleNavigateToSection('products')}
      />

      {/* Task Question Selector: "Какой вопрос вы хотите решить?" */}
      <TaskQuestionSelector
        onSelectLevel={handleSelectLevelCode}
        onOpenQuiz={() => setQuizOpen(true)}
        onOpenTbCalculator={() => setIsTbCalculatorOpen(true)}
      />

      {/* What Entrepreneurs Get Outcome Section */}
      <ResultsOutcomeSection
        onNavigateToProducts={() => handleNavigateToSection('products')}
      />

      {/* 4 Levels of Profit System */}
      <ProductLevels
        currentMarketplace={currentMarketplace}
        onSelectProduct={(p) => setSelectedProductDetail(p)}
        onOpenBuy={(pId) => handleOpenBuy(pId)}
        onOpenTbCalculator={() => setIsTbCalculatorOpen(true)}
      />

      {/* Visual Chain: "От цены товара к экономике всего бизнеса" */}
      <BusinessEconomyChain
        onGoToSimulator={() => handleNavigateToSection('simulator')}
        onGoToProducts={() => handleNavigateToSection('products')}
      />

      {/* Live Interactive "What If" Calculator */}
      <InteractiveCalculator
        onNavigateToProducts={() => handleNavigateToSection('products')}
      />

      {/* How it Works Step-by-Step Scenario */}
      <HowItWorks />

      {/* Expenses Breakdown Diagram */}
      <ExpensesBreakdown />

      {/* Comparison Matrix Table */}
      <ComparisonTable
        onOpenQuiz={() => setQuizOpen(true)}
        onOpenBuy={(pId) => handleOpenBuy(pId)}
      />

      {/* Excel Advantages */}
      <ExcelSystemAdvantages />

      {/* Free Demo Banner */}
      <DemoBlock
        onOpenDemo={() => setDemoOpen(true)}
        onOpenTbCalculator={() => setIsTbCalculatorOpen(true)}
      />

      {/* Knowledge Base, Telegram & YouTube */}
      <KnowledgeBaseMedia />

      {/* FAQ Accordion Section */}
      <FaqSection />

      {/* Footer */}
      <Footer
        onSelectMarketplace={(m) => setCurrentMarketplace(m)}
        onOpenDemo={() => setDemoOpen(true)}
        onOpenBuy={() => handleOpenBuy()}
        onNavigateToSection={handleNavigateToSection}
      />

      {/* Interactive Overlays */}
      <QuizModal
        isOpen={quizOpen}
        onClose={() => setQuizOpen(false)}
        onSelectProduct={handleQuizSelectProduct}
        onCompareAll={() => handleNavigateToSection('comparison')}
      />

      <ProductDetailModal
        product={selectedProductDetail}
        currentMarketplace={currentMarketplace}
        onClose={() => setSelectedProductDetail(null)}
        onOpenBuy={(pId) => handleOpenBuy(pId)}
        onOpenDemo={() => setDemoOpen(true)}
      />

      <DemoDownloadModal
        isOpen={demoOpen}
        onClose={() => setDemoOpen(false)}
      />

      <CheckoutModal
        isOpen={buyOpen}
        initialProductId={checkoutInitialProductId}
        onClose={() => setBuyOpen(false)}
      />
    </div>
  );
}
