import { ExpenseItem, CategoryInfo, ExpenseCategory } from '../types';

export const CATEGORIES: Record<ExpenseCategory, CategoryInfo> = {
  rent_utilities: {
    id: 'rent_utilities',
    label: 'Аренда и коммунальные',
    color: '#2563eb', // Blue
  },
  payroll: {
    id: 'payroll',
    label: 'Зарплата и персонал',
    color: '#38bdf8', // Light Blue
  },
  marketing: {
    id: 'marketing',
    label: 'Реклама и маркетинг',
    color: '#f59e0b', // Amber / Orange
  },
  transport: {
    id: 'transport',
    label: 'Транспорт и авто',
    color: '#0d9488', // Teal
  },
  subscriptions: {
    id: 'subscriptions',
    label: 'Сервисы и подписки',
    color: '#a855f7', // Purple
  },
  other: {
    id: 'other',
    label: 'Прочие расходы',
    color: '#7c3aed', // Darker Purple
  },
};

export const INITIAL_EXPENSES: ExpenseItem[] = [
  { id: '1', number: 1, name: 'Аренда офиса/склада', amount: 150000, comment: 'Аренда склада и офиса', category: 'rent_utilities' },
  { id: '2', number: 2, name: 'Коммунальные платежи', amount: 40000, comment: 'Электричество, вода, отопление', category: 'rent_utilities' },
  { id: '3', number: 3, name: 'Интернет и телефония', amount: 15000, comment: 'Интернет, связь', category: 'rent_utilities' },
  { id: '4', number: 4, name: 'Охрана', amount: 25000, comment: 'Охрана помещения', category: 'rent_utilities' },
  { id: '5', number: 5, name: 'Уборка/клининг', amount: 15000, comment: 'Клининг офиса и склада', category: 'rent_utilities' },
  { id: '6', number: 6, name: 'Зарплата сотрудников', amount: 90000, comment: 'ФОТ основного персонала', category: 'payroll' },
  { id: '7', number: 7, name: 'Бухгалтерское обслуживание', amount: 15000, comment: 'Бухгалтерия', category: 'other' },
  { id: '8', number: 8, name: 'Юридическое сопровождение', amount: 10000, comment: 'Юридические услуги', category: 'other' },
  { id: '9', number: 9, name: 'Аутсорсинг/фрилансеры', amount: 20000, comment: 'Внешние специалисты', category: 'payroll' },
  { id: '10', number: 10, name: 'Реклама (фиксированная)', amount: 12000, comment: 'Рекламные размещения', category: 'marketing' },
  { id: '11', number: 11, name: 'Продвижение в соцсетях', amount: 8000, comment: 'Продвижение и таргет', category: 'marketing' },
  { id: '12', number: 12, name: 'Контент-менеджер/фотограф', amount: 10000, comment: 'Создание контента', category: 'marketing' },
  { id: '13', number: 13, name: 'Транспортные расходы', amount: 20000, comment: 'Логистика и транспорт', category: 'transport' },
  { id: '14', number: 14, name: 'ГСМ', amount: 10000, comment: 'Топливо', category: 'transport' },
  { id: '15', number: 15, name: 'Техобслуживание авто', amount: 8000, comment: 'Обслуживание автомобиля', category: 'transport' },
  { id: '16', number: 16, name: 'Страхование авто', amount: 5000, comment: 'Страхование', category: 'transport' },
  { id: '17', number: 17, name: 'Парковка', amount: 2000, comment: 'Парковочные расходы', category: 'transport' },
  { id: '18', number: 18, name: 'Сервисы/подписки', amount: 6000, comment: 'Сервисы и подписки', category: 'subscriptions' },
  { id: '19', number: 19, name: 'Хостинг/домен', amount: 1500, comment: 'Хостинг, домены', category: 'subscriptions' },
  { id: '20', number: 20, name: 'Товарно-учетная система', amount: 3000, comment: 'Программа учета', category: 'subscriptions' },
  { id: '21', number: 21, name: 'Канцелярские товары', amount: 1500, comment: 'Канцелярия', category: 'other' },
  { id: '22', number: 22, name: 'Упаковочные материалы', amount: 3000, comment: 'Упаковка', category: 'other' },
  { id: '23', number: 23, name: 'Представительские расходы', amount: 5000, comment: 'Встречи, мероприятия', category: 'other' },
  { id: '24', number: 24, name: 'Обучение/курсы', amount: 5000, comment: 'Обучение сотрудников', category: 'other' },
  { id: '25', number: 25, name: 'Амортизация оборудования', amount: 8000, comment: 'Амортизация техники', category: 'other' },
  { id: '26', number: 26, name: 'Прочие расходы', amount: 6000, comment: 'Прочие операционные', category: 'other' },
  { id: '27', number: 27, name: 'Резервный фонд', amount: 10000, comment: 'Фонд непредвиденных расходов', category: 'other' },
];

export const PRESETS = [
  {
    id: 'default',
    name: 'Стандартный (Торговля & Селлеры)',
    expenses: INITIAL_EXPENSES,
    margin: 25,
    desiredProfit: 500000,
  },
  {
    id: 'retail',
    name: 'Розничный магазин',
    expenses: [
      { id: '1', number: 1, name: 'Аренда торговой точки', amount: 120000, comment: 'ТЦ / Стрит-ритейл', category: 'rent_utilities' },
      { id: '2', number: 2, name: 'Коммунальные и э/э', amount: 25000, comment: 'Свет, тепло', category: 'rent_utilities' },
      { id: '3', number: 3, name: 'Зарплата продавцов', amount: 110000, comment: 'ФОТ 3 смены', category: 'payroll' },
      { id: '4', number: 4, name: 'Эквайринг и касса', amount: 15000, comment: 'Обслуживание POS', category: 'subscriptions' },
      { id: '5', number: 5, name: 'Маркетинг и вывеска', amount: 30000, comment: 'Локальная реклама', category: 'marketing' },
    ],
    margin: 40,
    desiredProfit: 300000,
  },
  {
    id: 'it_agency',
    name: 'IT / Digital агентство',
    expenses: [
      { id: '1', number: 1, name: 'ФОТ ключевой команды', amount: 450000, comment: 'Senior Devs & PM', category: 'payroll' },
      { id: '2', number: 2, name: 'Аренда коворкинга', amount: 60000, comment: 'Гибкие рабочие места', category: 'rent_utilities' },
      { id: '3', number: 3, name: 'SaaS и лицензии ПО', amount: 45000, comment: 'Figma, Jira, OpenAI API, GitHub', category: 'subscriptions' },
      { id: '4', number: 4, name: 'Лидогенерация и PR', amount: 80000, comment: 'Таргет и статьи', category: 'marketing' },
    ],
    margin: 60,
    desiredProfit: 800000,
  },
];
