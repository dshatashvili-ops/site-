import * as XLSX from 'xlsx';
import { ExpenseItem } from '../types';

export function exportToExcel(
  expenses: ExpenseItem[],
  desiredProfit: number,
  marginPercent: number,
  whatIfMarginPercent: number
) {
  const wb = XLSX.utils.book_new();

  // 1. Sheet 1: Summary Dashboard & Calculations
  const totalExpenses = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const breakEvenPoint = marginPercent > 0 ? totalExpenses / (marginPercent / 100) : 0;
  const requiredRevenue = marginPercent > 0 ? (totalExpenses + desiredProfit) / (marginPercent / 100) : 0;
  const whatIfBreakEven = whatIfMarginPercent > 0 ? totalExpenses / (whatIfMarginPercent / 100) : 0;

  const dashboardData = [
    ['РАСЧЕТ ТОЧКИ БЕЗУБЫТОЧНОСТИ И ФИНАНСОВЫЕ ПОКАЗАТЕЛИ'],
    [],
    ['Показатель', 'Значение (руб / %)', 'Описание'],
    ['Итого постоянных расходов в месяц', totalExpenses, 'Сумма всех фикс. затрат'],
    ['Текущая маржинальность (%)', `${marginPercent}%`, 'Доля маржи в выручке'],
    ['ТОЧКА БЕЗУБЫТОЧНОСТИ (в месяц)', Math.round(breakEvenPoint), 'Выручка для покрытия расходов в 0'],
    ['Желаемая прибыль в месяц', desiredProfit, 'Целевая чистая прибыль'],
    ['Необходимая выручка', Math.round(requiredRevenue), 'Выручка для достижения желаемой прибыли'],
    ['Необходимая маржа', totalExpenses + desiredProfit, 'Маржинальный доход для покрытия затрат и прибыли'],
    [],
    ['АНАЛИЗ «ЧТО ЕСЛИ»'],
    ['Альтернативная маржинальность (%)', `${whatIfMarginPercent}%`, 'Сценарий изменения маржи'],
    ['Новая точка безубыточности', Math.round(whatIfBreakEven), 'ТБ при альтернативной марже'],
  ];

  const wsDashboard = XLSX.utils.aoa_to_sheet(dashboardData);

  wsDashboard['!cols'] = [
    { wch: 40 },
    { wch: 25 },
    { wch: 45 },
  ];

  XLSX.utils.book_append_sheet(wb, wsDashboard, 'Сводный дешборд');

  // 2. Sheet 2: Fixed Expenses List with Formulas
  const expenseRows: any[][] = [
    ['№', 'Статья расходов', 'Сумма, руб', 'Комментарий', 'Категория'],
  ];

  expenses.forEach((item) => {
    expenseRows.push([
      item.number,
      item.name,
      item.amount,
      item.comment,
      item.category,
    ]);
  });

  const totalRowIndex = expenseRows.length + 1;
  expenseRows.push(['', 'ИТОГО ПОСТОЯННЫХ РАСХОДОВ:', { f: `SUM(C2:C${totalRowIndex - 1})` }, '', '']);

  const wsExpenses = XLSX.utils.aoa_to_sheet(expenseRows);

  wsExpenses['!cols'] = [
    { wch: 6 },
    { wch: 32 },
    { wch: 18 },
    { wch: 35 },
    { wch: 20 },
  ];

  XLSX.utils.book_append_sheet(wb, wsExpenses, 'Постоянные расходы');

  XLSX.writeFile(wb, 'Точка_безубыточности_расчет.xlsx');
}

export function downloadExcelTemplate() {
  const wb = XLSX.utils.book_new();
  const templateRows = [
    ['№', 'Статья расходов', 'Сумма, руб', 'Комментарий'],
    [1, 'Аренда офиса/склада', 150000, 'Аренда склада и офиса'],
    [2, 'Коммунальные платежи', 40000, 'Электричество, вода, отопление'],
    [3, 'Интернет и телефония', 15000, 'Интернет, связь'],
    [4, 'Зарплата сотрудников', 90000, 'ФОТ основного персонала'],
    [5, 'Реклама и маркетинг', 20000, 'Рекламные кампании'],
    [6, 'Прочие расходы', 10000, 'Амортизация и канцелярские расходы'],
    ['', 'ИТОГО:', { f: 'SUM(C2:C7)' }, ''],
  ];

  const ws = XLSX.utils.aoa_to_sheet(templateRows);
  ws['!cols'] = [{ wch: 6 }, { wch: 30 }, { wch: 18 }, { wch: 35 }];
  XLSX.utils.book_append_sheet(wb, ws, 'Расходы');

  XLSX.writeFile(wb, 'Шаблон_расходов_безубыточность.xlsx');
}

export function parseExcelOrCsvFile(
  file: File,
  onSuccess: (items: Partial<ExpenseItem>[]) => void,
  onError: (errorMsg: string) => void
) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = new Uint8Array(e.target?.result as ArrayBuffer);
      const workbook = XLSX.read(data, { type: 'array' });

      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];

      const rows: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

      if (!rows || rows.length < 2) {
        onError('Файл пуст или не содержит данных таблицы.');
        return;
      }

      const parsedItems: Partial<ExpenseItem>[] = [];

      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (!row || row.length === 0) continue;

        const col0 = String(row[0] || '').toLowerCase();
        const col1 = String(row[1] || '').toLowerCase();
        if (col0.includes('итого') || col1.includes('итого')) continue;

        const name = String(row[1] || row[0] || '').trim();
        const amountNum = parseFloat(String(row[2] || row[1] || '0').replace(/\s+/g, '').replace(',', '.'));
        const comment = String(row[3] || '').trim();

        if (name && !isNaN(amountNum) && amountNum > 0) {
          parsedItems.push({
            name,
            amount: amountNum,
            comment: comment || name,
            category: 'other',
          });
        }
      }

      if (parsedItems.length === 0) {
        onError('Не удалось извлечь статьи расходов. Проверьте формат файла.');
        return;
      }

      onSuccess(parsedItems);
    } catch (err: any) {
      onError('Ошибка при чтении файла: ' + (err.message || 'Неверный формат'));
    }
  };
  reader.readAsArrayBuffer(file);
}
