export function formatCurrency(value: number): string {
  if (isNaN(value) || !isFinite(value)) return '0 ₽';
  const rounded = Math.round(value);
  return new Intl.NumberFormat('ru-RU').format(rounded) + ' ₽';
}

export function formatPercent(value: number, decimals: number = 0): string {
  if (isNaN(value) || !isFinite(value)) return '0 %';
  if (decimals === 0) {
    return `${Math.round(value)} %`;
  }
  return `${value.toFixed(decimals).replace('.', ',')} %`;
}

export function parseFormattedNumber(input: string): number {
  if (!input) return 0;
  const clean = input.replace(/\s+/g, '').replace(/,/g, '.').replace(/[^0-9.-]/g, '');
  const num = parseFloat(clean);
  return isNaN(num) ? 0 : num;
}
